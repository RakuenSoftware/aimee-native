from pathlib import Path
import hashlib,json,zipfile
r=Path('/opt/aimee-native-serving');release=r/'releases/model-plugins-20261004-r1';artifacts=r/'model-plugins-r3/release';proof=json.loads((artifacts/'finalization.json').read_bytes());checked=[]
for plugin in proof['plugins']:
 for member,expected in plugin['code_member_sha256'].items():
  p=release/'plugins'/member
  if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise RuntimeError('installed code mismatch '+member)
 checked.append({'wheel':plugin['wheel'],'sha256':plugin['sha256'],'verified_executable_members':len(plugin['code_member_sha256'])})
sources={}
for folder in ('distribution/vllm/aimee_vllm','distribution/vllm/deployment','benchmarks/native_addressing'):
 for p in sorted((release/folder).rglob('*')):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and 'evidence' not in p.parts and p.suffix in ('.py','.json','.md','.service','.mount'):sources[str(p.relative_to(release))]=hashlib.sha256(p.read_bytes()).hexdigest()
rust={str(p.relative_to(r/'adapter-build')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((r/'adapter-build/src').rglob('*.rs'))}
for name in ('Cargo.toml','Cargo.lock','build.rs'):rust[name]=hashlib.sha256((r/'adapter-build'/name).read_bytes()).hexdigest()
report={'status':'passed','release':str(release),'plugins':checked,'release_source_sha256':sources,'private_build_source_sha256':rust,'final_source_tar_sha256':hashlib.sha256((r/'model-plugin-final-source.tar').read_bytes()).hexdigest()}
(r/'model-plugin-installed-release-integrity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','plugins':checked,'source_files':len(sources),'rust_files':len(rust)}))
