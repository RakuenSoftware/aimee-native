from pathlib import Path
import hashlib,json,time
r=Path('/opt/aimee-native-serving'); source=Path('/proc/113675/root/opt/aimee-memory-lab/gemma4-moe'); old=Path('/proc/113675/root/opt/aimee-memory-lab/gemma26-release-20260928/source-integrity.json')
def digest(p,algorithm='sha256'):
 h=hashlib.new('sha1' if algorithm=='git-blob-sha1' else algorithm)
 if algorithm=='git-blob-sha1':h.update(('blob '+str(p.stat().st_size)+'\0').encode())
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
checks=[]
for entry in json.loads(old.read_text())['files']:
 p=source/entry['file']; actual=digest(p,entry['algorithm']); checks.append({**{k:v for k,v in entry.items() if k!="seconds"},'actual':actual,'matches_cached_download_metadata':actual==entry['expected']})
 if actual!=entry['expected']:raise RuntimeError('original source changed: '+entry['file'])
converter=Path('/proc/113675/root/opt/aimee-memory-lab/llama-native-distribution'); weight=Path('/mnt/pve/backup/aimee-experiments/native-serving-20261004/gemma26-q3/gemma26-q3_k_m.gguf')
report={'status':'passed','model':'Gemma4 26B A4B','source_scope':'Original local BF16 download checked against cached download metadata, not independent remote provenance verification','source_files':checks,'source_integrity_record_sha256':digest(old),'conversion':'original BF16 -> streamed F16 GGUF -> Q3_K_M; no Q8 requantization','weight':{'bytes':weight.stat().st_size,'sha256':digest(weight),'profile':'Q3_K_M','mixed_bits_per_weight':4.21,'fallback_tensors':60,'total_tensors':658},'tools':{str(p.relative_to(converter)):digest(p) for p in [converter/'convert_hf_to_gguf.py',converter/'build/bin/llama-quantize']},'execution':{'cuda_used_for_conversion':False,'memory_max_bytes':8*1024**3,'swap_max_bytes':0,'quantizer_max_buffer_mib':1024},'recipe_sha256':digest(r/'prepare_gemma26_q3.sh')}
(r/'gemma26-q3-weight-provenance.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'sha256':report['weight']['sha256'],'bytes':weight.stat().st_size}))
