"""Check all three installed plugins against their own and the other model configs."""
from importlib import import_module,metadata
import json,os
from pathlib import Path
import tempfile
models={'gemma4-12b':'aimee_gemma4_12b','gemma4-26b':'aimee_gemma4_26b','qwen3-8-27b':'aimee_qwen3_8_27b'}
root=Path('/opt/aimee-native-serving');configs=root/'adapter-build/distribution/vllm/tests/model_configs';checks=[]
for name,package in models.items():
 module=import_module(package+'.model_adapter')
 for other in models:
  with tempfile.TemporaryDirectory() as directory:
   model=Path(directory);(model/'config.json').write_bytes((configs/(other+'.json')).read_bytes())
   config={'model':str(model),'adapter':name,'library':str(root/'installed-model-plugins-final'/package/'native/libaimee_native.so')}
   try:adapter=module.ModelAdapter(config)
   except RuntimeError:
    if other==name:raise
    checks.append({'plugin':name,'config':other,'result':'rejected'});continue
   if other!=name:raise RuntimeError('cross-model config admitted')
   result=adapter.call('positions',positions=[[0,1,10]],ranges=[[0,2,82],[2,3,0]])
   assert result==[[82,83,10]]
   checks.append({'plugin':name,'config':other,'result':'admitted','positions':result})
   config.update(catalog='/public/catalog',recipient='public-fixture',host_memory_budget=1024**3)
   if name=='qwen3-8-27b':config.update(enable_hybrid_native=True,model_revision='a'*40)
   path=model/'serve.json';path.write_text(json.dumps(config))
   args,env=import_module(package+'.cli').command(path)
   assert env['VLLM_PLUGINS']==package
   assert args[args.index('--worker-cls')+1]==package+'.worker.AimeeWorker'
   assert args[args.index('--middleware')+1]==package+'.admission.NativeAdmission'
   wrong=dict(config,adapter=next(n for n in models if n!=name));path.write_text(json.dumps(wrong))
   try:import_module(package+'.cli').command(path)
   except ValueError:pass
   else:raise RuntimeError('console accepted another model adapter')
entries={entry.name:entry.value for entry in metadata.entry_points(group='vllm.general_plugins') if entry.name in models.values()}
assert entries=={p:p+':register' for p in models.values()}
report={'status':'passed','scope':__doc__,'checks':checks,'entry_points':entries}
(root/'installed-model-plugin-probe-final.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','model_config_bindings':len(checks),'plugins':len(entries)}))
