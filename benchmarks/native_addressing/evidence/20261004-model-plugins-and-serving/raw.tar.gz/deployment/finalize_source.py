import json,shutil,subprocess
from pathlib import Path
r=Path('/opt/aimee-native-serving');release=r/'releases/fp8-20261004-r5'
shutil.copytree(r/'current',release);subprocess.run(['tar','-xf',str(r/'final-source-r5.tar'),'-C',str(release)],check=True)
(r/'serving-18g-pinned-before-sync-fix.json').write_bytes((r/'serving.json').read_bytes())
c=json.loads((r/'serving.json').read_text());c['library']=str(release/'lib/libaimee_qwen.so');(r/'serving.json').write_text(json.dumps(c,indent=2)+'\n')
(r/'current').unlink();(r/'current').symlink_to(release,target_is_directory=True)
