"""Read credentials only into memory; print/save only public probe results."""
import json,subprocess,urllib.request,urllib.error
from pathlib import Path
ssh=['ssh','-F','/dev/null','-o','UserKnownHostsFile=/tmp/aimee-proxmox-known-hosts','-o','BatchMode=yes','root@192.168.1.253']
secret=subprocess.check_output(ssh+['cat /opt/aimee-native-serving/credentials.env'],text=True).split('=',1)[1].strip()
config=json.loads(subprocess.check_output(ssh+['cat /opt/aimee-native-serving/serving.json'],text=True))
canary=config['canary']
body={'model':config['model'],'messages':[{'role':'system','content':canary['system']},{'role':'user','content':canary['query']}],'temperature':0,'max_tokens':32,'chat_template_kwargs':{'enable_thinking':False},'vllm_xargs':{'aimee_publication':canary['publication']}}
url='http://192.168.1.253:18950'
request=urllib.request.Request(url+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+secret,'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=180) as response:
 output=json.load(response);status=response.status
answer=output['choices'][0]['message']['content'].strip().rstrip('.');assert answer==canary['expected'],answer
try:urllib.request.urlopen(urllib.request.Request(url+'/v1/models'),timeout=30)
except urllib.error.HTTPError as error:unauthorized=error.code
else:raise RuntimeError('Unauthenticated endpoint unexpectedly admitted')
assert unauthorized==401
report={'status':'passed','endpoint':url,'authenticated_status':status,'native_answer':answer,'unauthenticated_status':unauthorized}
Path('/tmp/aimee-model-adapters/network-probe-final.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
