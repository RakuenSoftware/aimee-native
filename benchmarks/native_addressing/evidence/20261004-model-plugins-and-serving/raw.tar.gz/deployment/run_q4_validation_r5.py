"""Owned-GPU Q4 follow-up; restore the primary service on exit."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,urllib.request
r=Path('/opt/aimee-native-serving');release=r/'releases/model-adapters-20261004-r1';source=release/'benchmarks/native_addressing';python=r/'env/bin/python'
if not release.exists():
 shutil.copytree(r/'releases/fp8-20261004-r8',release)
 subprocess.run(['tar','-xf',str(r/'model-adapter-repair-source-r5.tar'),'-C',str(release)],check=True)
report={'status':'running','phases':[]}
env={'CUDA_VISIBLE_DEVICES':'0','PYTHONPATH':str(r/'installed-model-plugins-r2'),'AIMEE_STORE_LIBRARY':str(release/'lib/libaimee_qwen.so'),'OMP_NUM_THREADS':'8','VLLM_NO_USAGE_STATS':'1','VLLM_CONFIG_ROOT':str(r/'jit-runtime/config'),'HF_HOME':str(r/'jit-runtime/huggingface'),'TMPDIR':str(r/'jit-runtime/tmp'),'XDG_CACHE_HOME':str(r/'jit-runtime/cache'),'TRITON_CACHE_DIR':str(r/'jit-runtime/triton')}
def save():(r/'q4-pipeline-report-r5.json').write_text(json.dumps(report,indent=2)+'\n')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def run(name,args,memory):
 log=r/(name+'.log')
 cmd=['systemd-run','--unit=aimee-native-'+name,'--wait','--collect','--property=MemoryMax='+memory,'--property=MemorySwapMax=0','--property=OOMPolicy=stop','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),*['--setenv='+k+'='+v for k,v in env.items()],str(python),*map(str,args)]
 result=subprocess.run(cmd,capture_output=True,text=True);report['phases'].append({'name':name,'returncode':result.returncode,'controller_output':result.stdout+result.stderr,'log':str(log)});save()
 if result.returncode:raise RuntimeError(name+' failed; inspect preserved log')
def idle():
 deadline=time.monotonic()+1800
 while subprocess.check_output(['nvidia-smi','--id=0','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip():
  if time.monotonic()>deadline:raise RuntimeError('RTX 5080 occupied; no other workload was stopped')
  time.sleep(10)
stopped=False
try:
 save()
 weights=Path('/mnt/pve/backup/aimee-experiments/native-serving-20261004/gemma12-q4/gemma12-q4_k_m.gguf')
 if subprocess.run(['systemctl','is-active','--quiet','aimee-native-gemma-q4-weights']).returncode==0:raise RuntimeError('Q4 serialization is still running')
 if not weights.exists():raise RuntimeError('Q4 checkpoint is absent')
 base=r/'q4-empty-catalog-r5.json';model='/var/lib/aimee-large-release-validation/cuda-5080-20260930/models';checksum=sha(weights)
 provenance={'q4_sha256':checksum,'q4_bytes':weights.stat().st_size,'original_safetensors_sha256':json.loads((r/'gemma-q4-weight-provenance.json').read_text())['original_safetensors_sha256'],'source':'original BF16 to streamed F16 GGUF to Q4_K_M; no Q8 requantization','quantizer_max_buffer_mib':1024,'preparation_memory_limit_bytes':8*1024**3}
 (r/'gemma-q4-weight-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 base.write_text(json.dumps({'recipient':'public-attention-family-canary','model_config_sha256':sha(Path(model)/'config.json'),'publications':{}},indent=2)+'\n')
 config={'adapter':'gemma4-12b','plugin':'aimee_gemma4_12b','python_module':'aimee_gemma4_12b','model':model,'gguf_weights':str(weights),'gguf_weights_sha256':checksum,'gguf_weight_profile':'Q4_K_M','library':str(r/'installed-model-plugins-r2/aimee_gemma4_12b/native/libaimee_native.so'),'catalog':str(base),'recipient':'public-attention-family-canary','host_memory_budget':1024**3,'device_memory_budget':128*1024**2,'native_stage_telemetry':True,'lossless_transport':False,'offline_prefix_capture':True,'control_socket':str(r/'q4-capture-control.sock'),'serve':{'host':'127.0.0.1','port':18952,'max_model_len':2048,'max_num_seqs':1,'max_num_batched_tokens':128,'gpu_memory_utilization':.58,'num_gpu_blocks_override':512,'flashinfer_sampler':False}}
 (r/'q4-capture-config-r5.json').write_text(json.dumps(config,indent=2)+'\n')
 subprocess.run(['systemctl','stop','aimee-native-serving'],check=True);stopped=True;idle()
 report['capture']={'reused_successful_capture':'attention-q4-prepared-r4','source_report':'q4-pipeline-report-r4.json','reason':'same installed wheel/config/weights; service launch entry point only was corrected'};save()
 config.pop('offline_prefix_capture');config['catalog']=str(r/'attention-q4-prepared-r4/catalog.json');config['control_socket']=str(r/'q4-service-control.sock')
 (r/'q4-serving-config-r5.json').write_text(json.dumps(config,indent=2)+'\n')
 idle();log=r/'attention-q4-service-r5.log'
 subprocess.run(['systemd-run','--unit=aimee-native-attention-q4-service-r5','--property=MemoryMax=12G','--property=MemorySwapMax=0','--property=OOMPolicy=stop','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),*['--setenv='+k+'='+v for k,v in env.items()],str(python),'-c','from aimee_gemma4_12b.cli import main; main()','--config',str(r/'q4-serving-config-r5.json')],check=True)
 deadline=time.monotonic()+1200
 while True:
  try:
   with urllib.request.urlopen('http://127.0.0.1:18952/v1/models',timeout=5) as response:assert json.load(response)['data']
   break
  except OSError:
   if subprocess.run(['systemctl','is-active','--quiet','aimee-native-attention-q4-service-r5']).returncode:raise RuntimeError('Q4 service exited')
   if time.monotonic()>deadline:raise RuntimeError('Q4 readiness timeout')
   time.sleep(3)
 run('attention-family-q4-36-r5',[source/'live_attention_family_validation.py','--config',r/'q4-serving-config-r5.json','--preparation',r/'attention-q4-prepared-r4/preparation.json','--cases',source/'attention_family_cases.json','--output',r/'attention-family-q4-36-r5'],'2G')
 run('attention-family-q4-audit-r5',[source/'audit_attention_family.py','--root',r/'attention-family-q4-36-r5','--output',r/'attention-family-q4-audit-r5.json'],'1G')
 import socket
 with socket.socket(socket.AF_UNIX) as sock:
  sock.settimeout(30);sock.connect(config['control_socket']);sock.sendall(b'{"op":"metrics"}\n');metrics=json.loads(sock.makefile('rb').readline())
 footprint={'status':'measured','metrics':metrics,'service':subprocess.check_output(['systemctl','show','aimee-native-attention-q4-service-r5','--property=MemoryCurrent,MemoryPeak,MemoryMax'],text=True)}
 (r/'attention-q4-footprint-r5.json').write_text(json.dumps(footprint,indent=2)+'\n')
 if sha(weights)!=checksum:raise RuntimeError('Q4 checkpoint changed during serving')
 details=json.loads((r/'attention-family-q4-36-r5/report.json').read_text())
 report['status']='passed' if details['status']=='passed' else 'quality_failed';save()
except BaseException as error:
 report['status']='failed';report['error']=str(error);save();raise
finally:
 subprocess.run(['systemctl','stop','aimee-native-attention-q4-service-r5'],capture_output=True)
 if stopped:
  subprocess.run(['systemctl','reset-failed','aimee-native-serving'],check=False)
  subprocess.run(['systemctl','start','aimee-native-serving'],check=False)
