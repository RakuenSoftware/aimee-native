import json,os,subprocess,time
from pathlib import Path
r=Path('/opt/aimee-native-serving');source=r/'current/benchmarks/native_addressing';python=r/'env/bin/python';report={'status':'incomplete','phases':[]}
def save():(r/'final-pipeline-report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,output):
    log=r/(name+'.log')
    with log.open('xb') as stream:result=subprocess.run([str(python),str(source/argv[0]),*argv[1:]],stdout=stream,stderr=subprocess.STDOUT,env=os.environ)
    phase={'name':name,'returncode':result.returncode,'output':str(output),'log':str(log)}
    if (output/'report.json').exists():
        details=json.loads((output/'report.json').read_text());phase.update(status=details['status'],n=details.get('n'),correct=details.get('correct'))
    report['phases'].append(phase);save()
    if result.returncode:raise RuntimeError(name+' failed; inspect preserved log')
    return phase
try:
    common=['--config',str(r/'serving.json'),'--selections','/opt/aimee-native-context-5080/entity-resolution-selections.json']
    latency=r/'latency-final-sync';phase=run('latency-final-sync',['profile_serving_latency.py',*common,'--output',str(latency)],latency)
    if phase.get('status')!='passed':raise RuntimeError('final performance quality check failed')
    quality=r/'fp8-native-full324';phase=run('fp8-native-full324',['live_native_extension_validation.py',*common,'--tasks',str(source/'native_context_suite.json'),'--heldout',str(source/'heldout_aliases.json'),'--output',str(quality)],quality)
    audit=subprocess.run([str(python),str(source/'audit_live_native_extension.py'),'--root',str(quality),'--output',str(r/'fp8-native-independent-audit.json')],check=True)
    operations=r/'fp8-native-operations';run('fp8-native-operations',['live_native_operational_validation.py',*common,'--output',str(operations)],operations)
    report['status']='passed' if all(p.get('status')=='passed' for p in report['phases']) else 'quality_failed';save()
except BaseException as error:
    report['error']=str(error);save();raise
