"""Public serving evidence: allowlisted text only; exclude weights, tensors and credentials."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path('/opt/aimee-native-serving');target=r/'public-model-plugin-evidence-final.tar.gz';members={}
secret=(r/'credentials.env').read_text().split('=',1)[1].strip().encode()
def add(path,name):
 if path.is_symlink():return
 raw=path.read_bytes()
 if secret and secret in raw:raise RuntimeError('credential detected in '+name+'; archive refused')
 members[name]=raw
for p in sorted(r.iterdir()):
 if p.is_file() and (p.suffix in ('.json','.log','.txt','.service') or p.name.startswith(('run_','prepare_','finalize_','installed_plugins_probe','gemma26_provenance','deployment_probe','archive_model_plugin','verify_installed_release','network_probe')) and p.suffix in ('.py','.sh')):add(p,'deployment/'+p.name)
runs=('latency-22g','latency-18g','latency-18g-pinned','latency-final-sync','fp8-native-full324','fp8-native-operations','attention-family-36','repeat-prefix','model-plugin-qwen-full324','model-plugin-qwen-operations')
for d in sorted(r.iterdir()):
 if d.is_dir() and (d.name in runs or d.name.startswith(('attention-family-q4-36','attention-q4-prepared','attention-family-prepared'))):
  for p in sorted(d.rglob('*')):
   if p.is_file() and p.suffix in ('.json','.jsonl','.log'):add(p,'runs/'+d.name+'/'+str(p.relative_to(d)))
for d in sorted((r/'releases').iterdir()):
 for folder in ('distribution/release','distribution/service','distribution/vllm/aimee_vllm','distribution/vllm/tests','distribution/vllm/deployment','benchmarks/native_addressing','src/model_adapters'):
  for p in sorted((d/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and 'evidence' not in p.parts and p.suffix in ('.py','.json','.md','.rs','.service','.mount'):add(p,'sources/'+d.name+'/'+str(p.relative_to(d)))
for folder in ('adapter-build/src','adapter-build/native','adapter-build/distribution/vllm/tests/model_configs','model-plugins-r3/release'):
 for p in sorted((r/folder).rglob('*')):
  if p.is_file() and p.suffix in ('.rs','.json','.cpp','.h','.hip'):add(p,'build/'+str(p.relative_to(r)))
for filename in ('Cargo.toml','Cargo.lock','build.rs'):add(r/'adapter-build'/filename,'build/adapter-build/'+filename)
model=Path('/mnt/pve/backup/aimee-experiments/native-serving-20261004/fp8-checkpoint')
for name in ('config.json','weight-provenance.json','model.safetensors.index.json'):add(model/name,'checkpoint-metadata/'+name)
prefix=Path('/mnt/pve/backup/aimee-experiments/native-serving-20261004/prefixes')
for p in sorted(prefix.rglob('*.json')):add(p,'prefix-metadata/'+str(p.relative_to(prefix)))
units=['aimee-native-serving.service','aimee-native-final-pipeline.service','aimee-native-followup-pipeline.service','aimee-native-gemma-q4-weights.service','aimee-native-gemma26-q3-weights.service','aimee-native-model-plugin-finalization.service','aimee-native-gemma26-provenance.service']
units.extend('aimee-native-'+name+'.service' for name in ('fp8-capture-r1','fp8-capture-r2','fp8-capture-r3','fp8-serialize-r1','fp8-serialize-r2','attention-family','attention-family-prepare','repeat-prefix'))
for family,versions in [('gemma-q4-pipeline',['','-r2','-r3','-r4','-r5','-r6']),('gemma26-plugin-pipeline',['-r1','-r2','-r3']),('attention-q4-capture',['','-r2','-r3','-r4','-g26-r2','-g26-r3']),('attention-q4-service',['','-r5','-r6','-g26-r3'])]:
 units.extend('aimee-native-'+family+v+'.service' for v in versions)
for unit in units:
 raw=subprocess.check_output(['journalctl','-u',unit,'--since','2026-10-04 00:00:00','--no-pager','-o','short-iso'])
 if secret and secret in raw:raise RuntimeError('credential in journal '+unit+'; archive refused')
 members['journal/'+unit+'.log']=raw
for unit in ('aimee-native-serving.service','opt-aimee\\x2dnative\\x2dserving-jit\\x2druntime.mount'):
 result=subprocess.run(['systemctl','cat',unit],capture_output=True)
 if result.returncode==0:
  if secret and secret in result.stdout:raise RuntimeError('credential in unit; archive refused')
  members['units/'+unit]=result.stdout
members['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in sorted(members.items())},indent=2)+'\n').encode()
with tarfile.open(target,'x:gz') as archive:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.mode=0o600;info.size=len(raw);archive.addfile(info,io.BytesIO(raw))
report={'archive':str(target),'members':len(members),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(r/'model-plugin-evidence-archive.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
