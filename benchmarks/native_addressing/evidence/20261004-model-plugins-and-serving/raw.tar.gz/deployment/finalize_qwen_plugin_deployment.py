"""Validate the installed Qwen plugin, rollback, and leave the owned service enabled."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path('/opt/aimee-native-serving');release=r/'releases/model-plugins-20261004-r1';python=r/'env/bin/python'
report={'status':'running','phases':[]}
def save():(r/'model-plugin-deployment-report.json').write_text(json.dumps(report,indent=2)+'\n')
def command(args):return subprocess.run(list(map(str,args)),check=True)
def probe(label,refresh=False):
 args=[str(python),str(r/'deployment_probe.py'),'--config',str(r/'serving.json'),'--output',str(r/('model-plugin-'+label+'.json'))]
 if refresh:args.append('--refresh')
 command(args);report['phases'].append({'phase':label,'status':'passed'});save()
def tests(name,args):
 with (r/(name+'.log')).open('xb') as log:
  subprocess.run([str(python),*map(str,args)],stdout=log,stderr=subprocess.STDOUT,check=True,env=os.environ)
 report['phases'].append({'phase':name,'status':'passed'});save()
def start():
 command(['systemctl','reset-failed','aimee-native-serving'])
 command(['systemctl','start','aimee-native-serving'])
def pointer(path):
 (r/'current').unlink();(r/'current').symlink_to(path,target_is_directory=True)
def apply(unit,config,path):
 command(['systemctl','stop','aimee-native-serving'])
 Path('/etc/systemd/system/aimee-native-serving.service').write_bytes(unit)
 (r/'serving.json').write_bytes(config);pointer(path)
 command(['systemctl','daemon-reload']);start()
save()
# Sequential owned workloads only. Never stop another GPU owner.
for unit in ('aimee-native-gemma26-plugin-pipeline-r3','aimee-native-gemma-q4-pipeline-r6'):
 while subprocess.run(['systemctl','is-active','--quiet',unit]).returncode==0:time.sleep(5)
for name in ('q4-pipeline-report-r6.json','q4-pipeline-report-g26-r3.json'):
 if json.loads((r/name).read_text())['status']!='passed':raise RuntimeError('required model validation failed: '+name)
old=r/'current';previous=old.resolve();old_unit=Path('/etc/systemd/system/aimee-native-serving.service').read_bytes();old_config=(r/'serving.json').read_bytes()
(r/'model-plugin-previous-unit.service').write_bytes(old_unit);(r/'model-plugin-previous-config.json').write_bytes(old_config)
shutil.copytree(r/'releases/fp8-20261004-r8',release)
command(['tar','-xf',r/'model-plugin-final-source.tar','-C',release])
shutil.copytree(r/'installed-model-plugins-final',release/'plugins')
config=json.loads(old_config);config.update(adapter='qwen3-8-27b',python_module='aimee_qwen3_8_27b',plugin='aimee_qwen3_8_27b',library=str(release/'plugins/aimee_qwen3_8_27b/native/libaimee_native.so'))
new_config=(json.dumps(config,indent=2)+'\n').encode();new_unit=(release/'distribution/vllm/deployment/aimee-native-serving.service').read_bytes()
(r/'model-plugin-final-config.json').write_bytes(new_config);(r/'model-plugin-final-unit.service').write_bytes(new_unit)
try:
 apply(new_unit,new_config,release)
 probe('initial',True)
 source=release/'benchmarks/native_addressing'
 common=['--config',r/'serving.json','--selections','/opt/aimee-native-context-5080/entity-resolution-selections.json']
 tests('model-plugin-qwen-full324',[source/'live_native_extension_validation.py',*common,'--tasks',source/'native_context_suite.json','--heldout',source/'heldout_aliases.json','--output',r/'model-plugin-qwen-full324'])
 tests('model-plugin-qwen-audit',[source/'audit_live_native_extension.py','--root',r/'model-plugin-qwen-full324','--output',r/'model-plugin-qwen-audit.json'])
 quality=json.loads((r/'model-plugin-qwen-full324/report.json').read_text())
 if quality['status']!='passed':raise RuntimeError('installed Qwen quality validation failed')
 tests('model-plugin-qwen-operations',[source/'live_native_operational_validation.py',*common,'--output',r/'model-plugin-qwen-operations'])
 apply(old_unit,old_config,previous);probe('rollback')
 apply(new_unit,new_config,release)
 Path('/etc/systemd/system/aimee-native-serving.service.d/validation.conf').unlink(missing_ok=True)
 command(['systemctl','daemon-reload'])
 mount=subprocess.check_output(['systemd-escape','--path','--suffix=mount',str(r/'jit-runtime')],text=True).strip()
 command(['systemctl','enable',mount,'aimee-native-serving'])
 probe('final',True)
 report.update(status='passed',release=str(release),quality=quality)
 save()
except BaseException as error:
 report.update(status='failed',error=str(error));save()
 # Recovery uses the immutable known-good deployment if validation failed.
 apply(old_unit,old_config,previous)
 raise
