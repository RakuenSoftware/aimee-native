#!/bin/bash
set -euo pipefail
task_root=/mnt/pve/backup/aimee-experiments/native-serving-20261004/gemma12-q4
converter_root=/proc/113675/root/opt/aimee-memory-lab/llama-native-distribution
mkdir -p "$task_root/scratch"
export TMPDIR="$task_root/scratch"
export OMP_NUM_THREADS=4
export LD_LIBRARY_PATH="$converter_root/build/bin"
if [ ! -f "$task_root/gemma12-f16.gguf" ]; then
 /opt/aimee-native-serving/env/bin/python "$converter_root/convert_hf_to_gguf.py" /proc/113675/root/opt/aimee-memory-lab/gemma4 --outtype f16 --outfile "$task_root/gemma12-f16.gguf" --use-temp-file
fi
"$converter_root/build/bin/llama-quantize" --max-buffer-size 1024 "$task_root/gemma12-f16.gguf" "$task_root/gemma12-q4_k_m.gguf" Q4_K_M 4
