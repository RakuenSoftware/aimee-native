"""Sequential owned-GPU follow-up; restores the owned serving instance on error."""
import hashlib,json,os,subprocess,time,urllib.request
from pathlib import Path
r=Path('/opt/aimee-native-serving');release=r/'releases/fp8-20261004-r6';source=release/'benchmarks/native_addressing';python=r/'env/bin/python'
report={'status':'waiting_for_primary_gates','phases':[]};env={'CUDA_VISIBLE_DEVICES':'0','PYTHONPATH':str(release/'distribution/vllm'),'OMP_NUM_THREADS':'8','VLLM_NO_USAGE_STATS':'1','VLLM_CONFIG_ROOT':str(r/'jit-runtime/config'),'HF_HOME':str(r/'jit-runtime/huggingface'),'TMPDIR':str(r/'jit-runtime/tmp'),'XDG_CACHE_HOME':str(r/'jit-runtime/cache'),'TRITON_CACHE_DIR':str(r/'jit-runtime/triton')}
def save():(r/'followup-pipeline-report.json').write_text(json.dumps(report,indent=2)+'\n')
def idle_gpu():
 deadline=time.monotonic()+1800
 while True:
  output=subprocess.check_output(['nvidia-smi','--id=0','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True).strip()
  if not output:return
  if time.monotonic()>deadline:raise RuntimeError('RTX 5080 remains occupied; no other workload was stopped')
  time.sleep(10)
def run(name,args,memory):
 log=r/(name+'.log');command=['systemd-run','--unit=aimee-native-'+name,'--wait','--collect','--property=MemoryMax='+memory,'--property=MemorySwapMax=0','--property=OOMPolicy=stop','--property=TimeoutStartSec=3600','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),*["--setenv="+key+'='+value for key,value in env.items()],str(python),*map(str,args)]
 result=subprocess.run(command,capture_output=True,text=True);phase={'name':name,'returncode':result.returncode,'log':str(log),'controller_output':result.stdout+result.stderr};report['phases'].append(phase);save()
 if result.returncode:raise RuntimeError(name+' failed; preserved log '+str(log))
try:
 save()
 while True:
  primary=json.loads((r/'final-pipeline-report.json').read_text())
  active=subprocess.run(['systemctl','is-active','--quiet','aimee-native-final-pipeline']).returncode==0
  if not active:
   if primary['status']!='passed':raise RuntimeError('primary gates did not pass; no GPU handover')
   break
  time.sleep(20)
 report['status']='running';save();subprocess.run(['systemctl','stop','aimee-native-serving'],check=True)
 idle_gpu()
 run('unit-final-r6',['-m','unittest','discover','-s',release/'distribution/vllm/tests'],'4G')
 c=json.loads((r/'serving.json').read_text());publication=c['canary']['publication']
 idle_gpu()
 run('cuda-attention-final',[source/'cuda_native_attention_timing.py','--config',r/'serving.json','--publication',publication,'--output',r/'cuda-attention-final.json'],'4G')
 family=r/'attention-family-prepared'
 run('attention-family-prepare',[source/'prepare_attention_family.py','--model','/proc/113675/root/opt/aimee-memory-lab/gemma4','--output',family],'48G')
 cfg={'model':'/var/lib/aimee-large-release-validation/cuda-5080-20260930/models','gguf_weights':'/var/lib/aimee-large-release-validation/cuda-5080-20260930/models/model.gguf','library':str(release/'lib/libaimee_qwen.so'),'catalog':str(family/'catalog.json'),'recipient':'public-attention-family-canary','host_memory_budget':1024**3,'device_memory_budget':512*1024**2,'native_stage_telemetry':True,'lossless_transport':False,'control_socket':str(r/'attention-family-control.sock'),'serve':{'host':'127.0.0.1','port':18951,'max_model_len':2048,'max_num_seqs':1,'max_num_batched_tokens':128,'gpu_memory_utilization':.92,'flashinfer_sampler':False}}
 (r/'attention-family-config.json').write_text(json.dumps(cfg,indent=2)+'\n')
 idle_gpu()
 log=r/'attention-family-service.log';subprocess.run(['systemd-run','--unit=aimee-native-attention-family','--property=MemoryMax=32G','--property=MemorySwapMax=0','--property=OOMPolicy=stop','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),*["--setenv="+key+'='+value for key,value in env.items()],str(python),'-m','aimee_vllm.cli','--config',str(r/'attention-family-config.json')],check=True)
 deadline=time.monotonic()+1200
 while True:
  try:
   with urllib.request.urlopen('http://127.0.0.1:18951/v1/models',timeout=5) as response:
    if not json.load(response)['data']:raise RuntimeError('family has no model')
   break
  except OSError:
   if subprocess.run(['systemctl','is-active','--quiet','aimee-native-attention-family']).returncode:raise RuntimeError('second family service exited')
   if time.monotonic()>deadline:raise RuntimeError('second family readiness timeout')
   time.sleep(3)
 run('attention-family-36',[source/'live_attention_family_validation.py','--config',r/'attention-family-config.json','--preparation',family/'preparation.json','--cases',source/'attention_family_cases.json','--output',r/'attention-family-36'],'4G')
 run('attention-family-audit',[source/'audit_attention_family.py','--root',r/'attention-family-36','--output',r/'attention-family-audit.json'],'1G')
 subprocess.run(['systemctl','stop','aimee-native-attention-family'],check=True)
 idle_gpu()
 repeat=json.loads((r/'capture-config.json').read_text());repeat['serve']=c['serve'];repeat['library']=str(release/'lib/libaimee_qwen.so');repeat['control_socket']=str(r/'repeat-control.sock')
 (r/'repeat-config.json').write_text(json.dumps(repeat,indent=2)+'\n');requests=json.loads((r/'capture-requests.json').read_text());(r/'repeat-requests.json').write_text(json.dumps({publication:requests[publication]},indent=2)+'\n')
 run('repeat-prefix',[source/'capture_engine_prefixes.py','--config',r/'repeat-config.json','--requests',r/'repeat-requests.json','--output',r/'repeat-prefix'],'56G')
 catalog=json.loads((r/'catalog.json').read_text());old=Path(catalog['publications'][publication]['root']);new=r/'repeat-prefix'/publication
 comparisons={name:{'old_sha256':hashlib.sha256((old/name).read_bytes()).hexdigest(),'new_sha256':hashlib.sha256((new/name).read_bytes()).hexdigest()} for name in ('index.json','hybrid.json','compact.pack')}
 for record in comparisons.values():record['equal']=record['old_sha256']==record['new_sha256']
 a=json.loads((old/'hybrid.json').read_text());b=json.loads((new/'hybrid.json').read_text());comparisons['recurrent']={'old_sha256':hashlib.sha256((old/a['recurrent']['payload']).read_bytes()).hexdigest(),'new_sha256':hashlib.sha256((new/b['recurrent']['payload']).read_bytes()).hexdigest()};comparisons['recurrent']['equal']=comparisons['recurrent']['old_sha256']==comparisons['recurrent']['new_sha256']
 (r/'repeat-prefix-comparison.json').write_text(json.dumps({'status':'passed' if all(x['equal'] for x in comparisons.values()) else 'different','comparisons':comparisons},indent=2)+'\n')
 if not all(x['equal'] for x in comparisons.values()):raise RuntimeError('fresh prefix differs; review retained comparison')
 report['status']='passed';save()
except BaseException as error:
 report['status']='failed';report['error']=str(error);save();raise
finally:
 subprocess.run(['systemctl','stop','aimee-native-attention-family'],capture_output=True)
 if report['status']!='waiting_for_primary_gates':
  subprocess.run(['systemctl','reset-failed','aimee-native-serving'],check=False)
  subprocess.run(['systemctl','start','aimee-native-serving'],check=False)
