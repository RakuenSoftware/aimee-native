"""Readiness and process-lifetime telemetry probe; credentials stay in memory."""
import argparse,hashlib,json,os,socket,subprocess,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',required=True);p.add_argument('--refresh',action='store_true');a=p.parse_args()
c=json.loads(Path(a.config).read_text());endpoint='http://'+c['serve']['host']+':'+str(c['serve']['port'])
def control(op):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(300);s.connect(c['control_socket']);s.sendall(json.dumps({'op':op}).encode()+b'\n');return json.loads(s.makefile('rb').readline())
def canary():
 x=c['canary'];body={'model':c['model'],'messages':[{'role':'system','content':x['system']},{'role':'user','content':x['query']}],'temperature':0,'max_tokens':32,'chat_template_kwargs':{'enable_thinking':False},'vllm_xargs':{'aimee_publication':x['publication']}}
 req=urllib.request.Request(endpoint+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+os.environ['VLLM_API_KEY']})
 start=time.perf_counter()
 with urllib.request.urlopen(req,timeout=300) as response:result=json.load(response)
 answer=result['choices'][0]['message']['content'].strip().rstrip('.')
 if answer!=x['expected']:raise RuntimeError('native deployment canary failed')
 return {'answer':answer,'usage':result['usage'],'elapsed_seconds':time.perf_counter()-start}
def counts(metrics):
 return [w.get('host_stages') for w in metrics['workers']]
before=control('metrics');first=canary();populated=control('metrics');refresh=None
if a.refresh:
 refresh=control('refresh')
 if refresh.get('state')!='active':raise RuntimeError('final refresh failed')
 refreshed=control('metrics')
 for old,new in zip(populated['workers'],refreshed['workers']):
  # Require populated counters so the preservation check cannot pass vacuously.
  if not old.get('host_stages',{}).get('stages'):raise RuntimeError('missing populated host counters')
  if old.get('host_stages')!=new.get('host_stages'):raise RuntimeError('process-lifetime counters changed across refresh')
 second=canary()
else:refreshed=None;second=None
report={'status':'passed','config_sha256':hashlib.sha256(Path(a.config).read_bytes()).hexdigest(),'release':str(Path('/opt/aimee-native-serving/current').resolve()),'before':before,'after_canary':populated,'refresh':refresh,'after_refresh':refreshed,'first_canary':first,'second_canary':second,'state':control('status'),'service':subprocess.check_output(['systemctl','show','aimee-native-serving','--property=ActiveState,SubState,MainPID,NRestarts,Restart,MemoryMax,MemorySwapMax,UnitFileState'],text=True)}
Path(a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'release':report['release'],'answer':first['answer']}))
