"""Prepare complete native prefixes with the exact serving engine arithmetic."""
import argparse
import json
import os
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--requests',required=True);p.add_argument('--output',required=True)
    args=p.parse_args();config=json.loads(Path(args.config).read_text());serve=config['serve']
    if config.get('offline_prefix_capture') is not True:raise ValueError('offline capture configuration required')
    output=Path(args.output);output.mkdir(mode=0o700)
    os.environ.update(AIMEE_VLLM_CONFIG=str(Path(args.config).resolve()),VLLM_PLUGINS='aimee_native',
                      VLLM_USE_V2_MODEL_RUNNER='0',VLLM_USE_FLASHINFER_SAMPLER='0',
                      VLLM_WEIGHT_OFFLOADING_DISABLE_PIN_MEMORY='1',VLLM_WEIGHT_OFFLOADING_DISABLE_UVA='1')
    from vllm import LLM,SamplingParams
    from tokenizers import Tokenizer
    llm=LLM(model=config['model'],dtype='bfloat16',quantization=config.get('quantization'),enforce_eager=True,
            enable_prefix_caching=False,async_scheduling=False,worker_cls='aimee_vllm.worker.AimeeWorker',
            attention_config={'backend':'CUSTOM'},limit_mm_per_prompt={'image':0,'audio':0,'video':0},
            mamba_ssm_cache_dtype='float32',additional_config={'gdn_prefill_backend':'triton'},
            cpu_offload_gb=serve['cpu_offload_gb'],cpu_offload_params=serve['cpu_offload_params'],
            max_model_len=serve['max_model_len'],max_num_seqs=1,max_num_batched_tokens=serve['max_num_batched_tokens'],
            gpu_memory_utilization=serve['gpu_memory_utilization'],num_gpu_blocks_override=serve.get('num_gpu_blocks_override'))
    tokenizer=Tokenizer.from_file(str(Path(config['model'])/'tokenizer.json'))
    requests=json.loads(Path(args.requests).read_text());publications={}
    for name,request in requests.items():
        text='<|im_start|>system\n'+request['context'].strip()+'\n\nAuthoritative memory:\n'+request['facts']+'<|im_end|>\n'
        tokens=tokenizer.encode(text,add_special_tokens=False).ids
        llm.llm_engine.collective_rpc('aimee_capture_begin',args=(tokens,request['context'],str(output/name)))
        llm.generate([{'prompt_token_ids':tokens}],SamplingParams(temperature=0,max_tokens=1),use_tqdm=False)
        result=llm.llm_engine.collective_rpc('aimee_capture_finish')
        if len(result)!=1:raise RuntimeError('capture rank coverage mismatch')
        publications[name]=result[0]
        (output/'progress.json').write_text(json.dumps(publications,indent=2)+'\n')
        print(json.dumps({'captured':name,'tokens':len(tokens)}),flush=True)
    catalogue={'recipient':config['recipient'],'model_config_sha256':__import__('hashlib').sha256((Path(config['model'])/'config.json').read_bytes()).hexdigest(),'publications':publications}
    (output/'catalog.json').write_text(json.dumps(catalogue,indent=2)+'\n')

if __name__=='__main__':main()
