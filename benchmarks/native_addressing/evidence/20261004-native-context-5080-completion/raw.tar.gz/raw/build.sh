#!/bin/bash
set -eu
cd /opt/aimee-native-context-5080/build-runtime/source
export CARGO_HOME=/opt/aimee-native-context-5080/build-runtime/cargo
export RUSTUP_HOME=/opt/aimee-native-context-5080/build-runtime/rustup
export PATH=/opt/aimee-native-context-5080/build-runtime/cargo/bin:$PATH
export CARGO_TARGET_DIR=/opt/aimee-native-context-5080/build-runtime/target
export LIBTORCH=/opt/aimee-sidecar-5080/venv/lib/python3.13/site-packages/torch
export LIBTORCH_BYPASS_VERSION_CHECK=1
export LIBTORCH_CXX11_ABI=1
export LD_LIBRARY_PATH=$LIBTORCH/lib
export AIMEE_TEST_TOKENIZER=/opt/aimee-native-context-5080/model/tokenizer.json
export CXXFLAGS="-std=c++20 -include $PWD/native/torch_214_compat.h"
cargo test --lib --bin aimee-qwen -- --test-threads=1
cargo test --lib cuda_host_matrix_offload -- --ignored --test-threads=1
cargo build --release --bin aimee-qwen --bin native-checkpoint-validation
