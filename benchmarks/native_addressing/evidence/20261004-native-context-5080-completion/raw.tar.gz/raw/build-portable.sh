#!/bin/bash
set -eu
cd /opt/aimee-native-context-5080/build-runtime/source
export CARGO_HOME=/opt/aimee-native-context-5080/build-runtime/cargo
export RUSTUP_HOME=/opt/aimee-native-context-5080/build-runtime/rustup
export PATH=$CARGO_HOME/bin:$PATH
export CARGO_TARGET_DIR=/opt/aimee-native-context-5080/build-runtime/portable-target
export PYTHON_INCLUDE=/root/.local/share/uv/python/cpython-3.12.14-linux-x86_64-gnu/include/python3.12
cargo build --release --lib --no-default-features --features vllm-portable
