#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/opt/aimee-sidecar-5080/venv/lib/python3.13/site-packages/torch/lib
/opt/aimee-native-context-5080/build-runtime/target/release/native-checkpoint-validation --model /opt/aimee-native-context-5080/model --placement /opt/aimee-native-context-5080/placement-int8-cuda-head.json --facts /opt/aimee-native-context-5080/checkpoint-facts.json
