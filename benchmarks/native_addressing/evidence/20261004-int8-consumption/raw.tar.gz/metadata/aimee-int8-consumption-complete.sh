#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/opt/aimee-sidecar-5080/venv/lib/python3.13/site-packages/torch/lib
export CUDA_VISIBLE_DEVICES=0
export OMP_NUM_THREADS=8
/opt/aimee-sidecar-5080/venv/bin/python /opt/aimee-native-context-5080/build-runtime/source/benchmarks/native_addressing/int8_consumption_validation.py --resume /opt/aimee-native-context-5080/build-runtime/int8-consumption-20261004 --output /opt/aimee-native-context-5080/build-runtime/int8-consumption-complete-20261004 --binary /opt/aimee-native-context-5080/build-runtime/target/release/aimee-qwen --model /opt/aimee-native-context-5080/model --placement /opt/aimee-native-context-5080/placement-int8-cuda-headroom.json --reader /opt/aimee-native-context-5080/native-context-reader --archive /opt/aimee-native-context-5080/build-runtime/framing-fixture/published --tasks /opt/aimee-native-context-5080/build-runtime/source/benchmarks/native_addressing/native_context_suite.json
