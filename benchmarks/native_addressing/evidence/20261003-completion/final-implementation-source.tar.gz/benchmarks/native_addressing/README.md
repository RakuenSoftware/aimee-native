# Native addressing baseline audit

This offline tool joins existing native traces with explicit experiment conditions
and externally scored outcomes. It requires only the Python standard library.
It does not launch inference or modify memory, selection, scheduling or source traces.

```sh
python3 benchmarks/native_addressing/audit.py /private/experiment/manifest.json \
  --output /private/experiment/new-audit.json
python3 -m unittest discover -s benchmarks/native_addressing -v
```

The output must be new. Files created by the tool use mode 0600. Reports exclude
queries, answers and source memory content; task labels and condition labels are
still caller-supplied, so store reports according to the experiment's data policy.

## Manifest

```json
{
  "schema": "native-addressing-v1",
  "samples": [{
    "task_id": "composition-001",
    "replicate": 0,
    "trace": "traces/request-001.json",
    "correct": true,
    "selection_correct": true,
    "condition": {
      "model": "checkpoint-and-runtime-revision",
      "selector": "attention-spans",
      "schedule": "decode",
      "archive_records": 249105,
      "context_tokens": 64,
      "position_budget": 2048,
      "cache_state": "warm-record-cache",
      "encoding_granularity": "record"
    }
  }]
}
```

Trace paths are relative to the manifest directory, or absolute. All eight condition
fields are required; numeric dimensions are nonnegative integers. Include checkpoint,
quantization and runtime revision in `model`; keep positional/layer/router variants
distinct in `selector`. `context_tokens` describes the declared task input context,
not the final generated conversation length. Task/condition/replicate must be unique.

`correct` and `selection_correct` are independently supplied boolean scores or null.
Selection scoring must use external expected canonical identities/revisions and an
explicit criterion (for example, all necessary records discovered before answering).
Correct selection with a wrong answer identifies a consumption **or execution**
failure; the auditor cannot identify its exact cause. Runtime failures take precedence.
An unscored request stays unscored. Failed traces cannot be labelled correct.

## Trace compatibility and coverage

The tool reads the existing request `elapsed_ms`, `native_reads`,
`memory_encoding_passes`, `native_ready_ns`, `native_bank_application_cpu_ns` and
`recall_events` fields. Recall events expose `source_selection_ns`,
`encoding_elapsed_ms`, `recall_elapsed_ns`, `memory_encoding_tokens` and `status` where available.
Nanosecond fields convert to milliseconds. Encoding timing includes cache and
assembly bookkeeping; it is not isolated neural encoder time.
Tokenization/serialization before the encoding/cache timer is outside that substage;
the new complete recall timer includes it.
The existing source-selection timer can also include response validation and merge
bookkeeping; it is not an isolated database-query timer.

The instrumented research runtime supplies `native_addressing_ns` and a
`native_memory_metrics` object on both successful and failed requests. Addressing
is wall time including bank preparation, scoring, host readback and lexical
translation, excluding the subsequent source recall. No new GPU synchronization
is added. It is not isolated GPU kernel time and overlaps bank-application timing.
Attempts include empty addresses and failed translations.

The versioned metrics object carries current and peak active positions, records
and logical encoded K/V bytes across native layers, plus addressing attempt/failure
counts. These peaks observe post-recall working sets and survive cleanup on failure.
Logical bytes exclude cache-owned banks, prepared/device copies, staging, allocator
overhead and the ordinary conversation cache. They are not physical GPU residency.
Record mode sums all record/layer K/V tensors; bank mode sums all bank layers.
The auditor validates the schema, measurement scopes and peak/current consistency.

`native_activation_ns` and `native_attention_gpu_ns` remain future per-request
producer contracts and are unknown when absent. Separate GPU consumption
measurements and serving-plugin host aggregates are now available (below); the
auditor never invents those missing per-request measurements from aggregate data.

An event stage gets a request total only if **every** recall event supplies it.
The report includes observed/total event counts. An unchanged bank in old evidence
may lack an encoding measurement; that is missing coverage, not proof of zero work.
New unchanged-bank events measure equality/cache bookkeeping. Empty or rejected
source reads explicitly record zero encoding with `encoding_outcome=not_started`.
Later admission/encoding failures retain a failed recall event with total duration;
unavailable substage costs remain absent. Prepared loading has its own existing
timers and is not relabelled neural encoding. No events
means no stage measurement. Success and failed-request distributions are separate.
Nearest-rank p95 includes its sample count and is not a production tail guarantee.

For historical traces, recorded encoding-position peaks remain partial observations.
The report labels their coverage separately from the new post-recall working-set
peaks. Missing position telemetry stays unknown. Timings can nest or overlap: do
not add them or subtract them from request
time to infer attention cost. CPU application timings are not GPU consumption cost.
`bank_unchanged` counts potential scheduling opportunities; skipping those calls can
change future generated states and requires a new full-model evaluation.

The report hashes the exact manifest and source trace bytes, keeps conditions
separate, and identifies repeated tasks. It does not establish causal speedups,
retrieval scaling or quality from unmatched archives or self-scored runtime events.

See the [programme proposal](../../docs/proposals/pending/native-memory-addressing-and-working-set.md).

## Research controls and evaluation tools

See [results and gate decisions](RESULTS.md) for the completed first cycle.

Server options (research runtime; defaults preserve existing cadence):

```sh
# No attention-driven recall; latest-message preload still uses the memory owner.
... serve --native-schedule preload-only
# Periodic addressing; source-call budget includes preload and failed recalls.
... serve --native-schedule bounded-refresh --native-refresh-interval 4 \
  --native-max-reads 8 --max-active-records 6 --max-memory-tokens 2048
```

`decode_recall=false` may reduce work further; a request cannot increase server
limits. A bounded refresh requires a finite call limit. Budget exhaustion skips
further scheduled reads and records exhausted steps; an explicit extra recall
fails visibly. The generation check is independent of the schedule. The active
record limit checks the merged, canonical set before encoding. No fact eviction
or record truncation is introduced. Native position and cache/device-byte budgets
remain separate. `source_reads` means recall attempts, excluding publication,
retention and generation-check protocol calls.

Versioned traces include the schedule and source-read/skip/exhaustion counters.
The auditor validates finite read budgets and keeps absent legacy counters unknown.
With existing diagnostic enablement and a bounded `memory_diagnostics` request,
`routing_trace` exports query-state features. These diagnostics require protected
trace storage and introduce host readback; they are excluded from timed tasks.

`router.py` fits a development-only partition centroid model and evaluates a
family-disjoint holdout. Contracts bind checkpoint/representation/layer/pooling/
position/width. Results contain candidate partitions, not records or eligibility.
Current-view partitions must come from the trusted host. A mismatch or uncertainty
requires the memory owner to decide bounded fallback. A candidate hint can still
be confidently wrong; no fallback reliability is assumed. Fitted weights remain
research artifacts outside the production adapter.

```sh
python3 benchmarks/native_addressing/router.py /private/features.json \
  --budget 1 --output /private/new-routing-report.json \
  --router-output /private/new-research-router.json
# Requires Torch/Triton and this repository's serving package, plus a real GPU.
PYTHONPATH=distribution/vllm python3 benchmarks/native_addressing/attention_cost.py \
  --output /private/new-attention-cost.json
```

`campaign.py` creates a new, exclusive public synthetic experiment directory,
launches its own research server for paired schedules, scores exact answers and
expected record discovery independently, and separately collects address features.
`oracle_campaign.py` tests oracle-selected native banks against native-disabled
controls. `fixture_reader.py` is exclusively a synthetic read fixture; it must
never serve real memory or stand in for an authorization implementation.
`analyze_campaign.py` applies the predeclared primary routing and scheduling gates.

```sh
python3 benchmarks/native_addressing/campaign.py --binary /research/aimee-qwen \
  --model /research/checkpoint --placement /research/placement.json \
  --output /private/new-campaign
python3 benchmarks/native_addressing/analyze_campaign.py /private/new-campaign \
  --output /private/new-campaign/new-decision.json
```

Production serving configuration accepts `native_stage_telemetry: true` (boolean,
default false). Existing publisher-only `metrics` returns frontend selection-RPC
counters and per-worker activation/cache counters, separated by success/failure.
These are bounded process-lifetime count/total/max host-wall aggregates, not
per-request percentiles or completed GPU kernel times. RPC validation/admission,
preparation on the selection service, and nested activation costs must not be
summed or inferred from these aggregates. Missing stages remain unmeasured.

## Owner-approved candidate bundles

The published-reader protocol now accepts `native_recall` with an `address`:

```json
{"op":"native_recall","query":"Which access code is downstream of Neris?","limit":6,"authority":"public-research","address":{"schema":1,"view":"<pinned immutable view>","representation":"text-query-v1","step":0,"partitions":[]}}
```

Supported representations are `text-query-v1` and `attention-token-spans-v1`.
These are lexical addresses, not hidden-state embeddings. `limit` bounds the
complete candidate/record set (1–32); `partitions` supplies at most 32 optional
hints. Hints narrow cue matches and confer no eligibility. Wrong publication or
invalid representation is terminal. A cue miss performs one legacy local fallback;
remote fallback retains its independent authority boundary. Initializing routing
indexes and fallback search can scale with the archive.

The trusted publisher supplies `CandidateRoute` entries with an authority,
partition, explicit cues and exact canonical references. Use signed authorization
metadata or `Store.CompileReleasedRoutes` after the existing authoritative release
decision. Raw aliases, graph edges and metadata are never automatically admitted.
Routes are tip-publication data and must be explicitly republished after updates.
Ambiguous cues, unavailable revisions and complete-bundle overflow return no partial
payload. Canonical source records are resolved at read time with temporal checks.

The research adapter enables the envelope with `--native-candidate-routing`.
Existing preparation reads also use bundles when explicitly published. Legacy
images have no route metadata and preserve their previous retrieval path. The
learned prototype remains offline and is not enabled by this flag.

```sh
go build -o /private/published-fixture benchmarks/native_addressing/published_fixture.go
/private/published-fixture --root /private/new-archive --distractors 1000000
# Also vary the size of the cue catalog, independently of returned record count.
/private/published-fixture --root /private/new-catalog --distractors 100000 --route-distractors
python3 benchmarks/native_addressing/published_campaign.py \
  --binary /research/aimee-qwen --model /research/checkpoint \
  --placement /research/placement.json --reader /research/aimee-memory-image \
  --archive /private/new-archive/published --output /private/new-model-campaign
```

`serving_probe.py` tests the current serving package and a library built with
`--no-default-features --features vllm-portable`, using explicitly synthetic,
previously prepared banks. It tests BF16/Q8 weights, conversation growth, text
controls and actual per-worker telemetry. Its scope excludes fresh authorization
and encoding; it does not select bundles or certify learned routing.
