// Owner-side semantic intake diagnostic. Never dispatches model proposals.
package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
	"os"
	"time"
)

func main() {
	endpoint := os.Getenv("AIMEE_RESOLVER_ENDPOINT")
	model := os.Getenv("AIMEE_RESOLVER_MODEL")
	scan := bufio.NewScanner(os.Stdin)
	scan.Buffer(make([]byte, 4096), 262144)
	for scan.Scan() {
		var row struct {
			ID   string   `json:"id"`
			Task nt.Task  `json:"task"`
			Text string   `json:"text"`
			View *nt.View `json:"view,omitempty"`
		}
		if err := json.Unmarshal(scan.Bytes(), &row); err != nil {
			panic(err)
		}
		var observations []map[string]any
		r := &nt.HTTPResolver{Endpoint: endpoint, Model: model, MaxTokens: 512, ConstrainJSON: os.Getenv("AIMEE_RESOLVER_SCHEMA") == "1", DisableThinking: os.Getenv("AIMEE_RESOLVER_DISABLE_THINKING") == "1", Observe: func(req, res []byte, e error) {
			x := map[string]any{"request": json.RawMessage(req), "response": string(res)}
			if e != nil {
				x["error"] = e.Error()
			}
			observations = append(observations, x)
		}}
		started := time.Now()
		result, err := nt.Interpret(context.Background(), r, row.Task, row.Text)
		out := map[string]any{"id": row.ID, "intake": result, "observations": observations, "seconds": time.Since(started).Seconds()}
		if err != nil {
			out["error"] = err.Error()
		} else if row.View != nil {
			compiled, e := nt.Compile(*row.View, result)
			if e != nil {
				out["compile_error"] = e.Error()
			} else {
				out["compiled"] = compiled
			}
		}
		b, _ := json.Marshal(out)
		fmt.Println(string(b))
	}
	if scan.Err() != nil {
		panic(scan.Err())
	}
}
