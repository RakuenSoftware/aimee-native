-- Durable inference/publication association belongs to Aimee, never the adapter.
CREATE TABLE native_tooling_sessions (
 principal TEXT NOT NULL,
 session_id TEXT NOT NULL,
 journal TEXT NOT NULL DEFAULT '' CHECK(octet_length(journal)<=4194304),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 PRIMARY KEY(principal,session_id)
);
