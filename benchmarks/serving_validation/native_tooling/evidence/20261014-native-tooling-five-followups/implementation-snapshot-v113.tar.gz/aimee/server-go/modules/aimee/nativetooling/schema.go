package nativetooling

import (
	"bytes"
	"encoding/json"
	"sort"
)

// ResolverSchema constrains owner-side response structure, not permission or
// semantic accuracy. Every actionable alternative binds a registered capability
// and its required literal fields; abstentions cannot carry action arguments.
func ResolverSchema(task Task) map[string]any {
	variants := []any{}
	common := func(kinds []string) resolverProperties {
		return resolverProperties{"kind": map[string]any{"type": "string", "enum": kinds}, "unsupported_claims": map[string]any{"type": "array", "items": map[string]any{"type": "string"}}, "reason": map[string]any{"type": "string"}}
	}
	for _, cap := range task.Capabilities {
		fields := map[string]any{}
		required := []string{}
		for name, field := range cap.Fields {
			fields[name] = map[string]any{"type": "string"}
			if field.Required {
				required = append(required, name)
			}
		}
		kinds := cap.Kinds
		if len(kinds) == 0 {
			kinds = []string{"content", "need"}
		}
		properties := common(kinds)
		properties["capability_id"] = map[string]any{"type": "string", "const": cap.ID}
		properties["quotes"] = map[string]any{"type": "object", "properties": fields, "required": required, "additionalProperties": false}
		variants = append(variants, map[string]any{"type": "object", "properties": properties, "required": []string{"kind", "capability_id", "quotes", "reason"}, "additionalProperties": false})
	}
	variants = append(variants, map[string]any{"type": "object", "properties": common([]string{"clarify", "refusal", "none"}), "required": []string{"kind", "reason"}, "additionalProperties": false})
	return map[string]any{"oneOf": variants}
}

// Structured decoding engines may preserve schema property order. Put the
// semantic discriminant first so selecting an action remains possible before
// selecting its capability. Ordinary JSON validation remains order independent.
type resolverProperties map[string]any

func (p resolverProperties) MarshalJSON() ([]byte, error) {
	keys := []string{}
	for key := range p {
		if key != "kind" {
			keys = append(keys, key)
		}
	}
	sort.Strings(keys)
	if _, ok := p["kind"]; ok {
		keys = append([]string{"kind"}, keys...)
	}
	var out bytes.Buffer
	out.WriteByte('{')
	for i, key := range keys {
		if i > 0 {
			out.WriteByte(',')
		}
		k, _ := json.Marshal(key)
		value, err := json.Marshal(p[key])
		if err != nil {
			return nil, err
		}
		out.Write(k)
		out.WriteByte(':')
		out.Write(value)
	}
	out.WriteByte('}')
	return out.Bytes(), nil
}
