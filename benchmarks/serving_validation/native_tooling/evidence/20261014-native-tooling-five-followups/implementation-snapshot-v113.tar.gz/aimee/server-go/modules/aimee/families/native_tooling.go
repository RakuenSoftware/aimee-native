package families

import (
	"context"
	"encoding/json"
	"errors"
	store "github.com/JBailes/aimee/server-go/modules/aimee"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
	"time"
)

// Only the authenticated host may supply resolved publications and terminal
// engine observations. Public clients cannot select a principal or issue pins.
func nativeToolingApply(ctx context.Context, q store.Queryer, f []string) (uint32, []string, error) {
	principal, sid, body := f[0], f[1], f[2]
	if principal == "" || sid == "" || len(principal) > 128 || len(sid) > 128 || len(body) > 262144 {
		return store.StatusInvalid, nil, nil
	}
	var req nt.Request
	if json.Unmarshal([]byte(body), &req) != nil {
		return store.StatusInvalid, nil, nil
	}
	var owner string
	if err := q.QueryRow(ctx, `SELECT principal FROM server_sessions WHERE id=$1 FOR UPDATE`, sid).Scan(&owner); store.IsNoRows(err) {
		return store.StatusMissing, nil, nil
	} else if err != nil {
		return 0, nil, err
	}
	if owner != principal {
		return store.StatusInvalid, nil, nil
	}
	if _, err := q.Exec(ctx, `INSERT INTO native_tooling_sessions(principal,session_id,journal) VALUES($1,$2,'') ON CONFLICT DO NOTHING`, principal, sid); err != nil {
		return 0, nil, err
	}
	var raw string
	var micros int64
	if err := q.QueryRow(ctx, `SELECT journal,floor(extract(epoch FROM clock_timestamp())*1000000)::bigint FROM native_tooling_sessions WHERE principal=$1 AND session_id=$2 FOR UPDATE`, principal, sid).Scan(&raw, &micros); err != nil {
		return 0, nil, err
	}
	if req.Operation == "action" {
		next, response, err := nativeToolingAction(ctx, q, principal, sid, raw, req, time.UnixMicro(micros).UTC())
		if errors.Is(err, errNativeActionInvalid) {
			return store.StatusInvalid, nil, nil
		}
		if err != nil {
			return 0, nil, err
		}
		if next != raw {
			if _, err = q.Exec(ctx, `UPDATE native_tooling_sessions SET journal=$3,updated_at=now() WHERE principal=$1 AND session_id=$2`, principal, sid, next); err != nil {
				return 0, nil, err
			}
		}
		return store.StatusOK, []string{string(response)}, nil
	}
	next, reply, err := nt.Apply(principal, sid, []byte(raw), req, time.UnixMicro(micros).UTC())
	if err != nil {
		return store.StatusInvalid, nil, nil
	}
	if string(next) != raw {
		if _, err := q.Exec(ctx, `UPDATE native_tooling_sessions SET journal=$3,updated_at=now() WHERE principal=$1 AND session_id=$2`, principal, sid, string(next)); err != nil {
			return 0, nil, err
		}
	}
	encoded, err := json.Marshal(reply)
	return store.StatusOK, []string{string(encoded)}, err
}
