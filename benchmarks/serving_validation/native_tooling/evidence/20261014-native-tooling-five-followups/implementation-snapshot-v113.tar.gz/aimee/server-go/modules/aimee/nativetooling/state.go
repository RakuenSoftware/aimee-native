package nativetooling

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"time"
)

const MaxJournalBytes = 4 << 20
const MaxPins = 256

// View is selected by Aimee. Revision is opaque; no revision sorting occurs.
type View struct {
	Task              Task      `json:"task"`
	Bindings          []Binding `json:"bindings,omitempty"`
	Revision          string    `json:"revision"`
	PublicationSHA256 string    `json:"publication_sha256"`
	SourceRelease     string    `json:"source_release"`
	Expires           time.Time `json:"expires"`
}
type Pin struct {
	ID          string    `json:"id"`
	InferenceID string    `json:"inference_id"`
	InputSHA256 string    `json:"input_sha256"`
	View        View      `json:"view"`
	Created     time.Time `json:"created"`
}
type Contribution struct {
	Pin    Pin     `json:"pin"`
	Text   string  `json:"text"`
	Finish string  `json:"finish"`
	SHA256 string  `json:"sha256"`
	Intake *Intake `json:"intake,omitempty"`
}
type ActionBinding struct {
	ActionID        string `json:"action_id"`
	ArgumentsSHA256 string `json:"arguments_sha256"`
	Tool            string `json:"tool"`
}

type Journal struct {
	Version       int                      `json:"version"`
	Principal     string                   `json:"principal"`
	Session       string                   `json:"session"`
	Current       *View                    `json:"current,omitempty"`
	Active        bool                     `json:"active"`
	Pins          map[string]Pin           `json:"pins"`
	Contributions map[string]Contribution  `json:"contributions"`
	Actions       map[string]ActionBinding `json:"actions,omitempty"`
}
type Request struct {
	Action      json.RawMessage `json:"action,omitempty"`
	Operation   string          `json:"operation"`
	View        *View           `json:"view,omitempty"`
	InferenceID string          `json:"inference_id,omitempty"`
	InputSHA256 string          `json:"input_sha256,omitempty"`
	PinID       string          `json:"pin_id,omitempty"`
	Text        string          `json:"text,omitempty"`
	Finish      string          `json:"finish,omitempty"`
	Intake      *Intake         `json:"intake,omitempty"`
}
type Reply struct {
	Allowed           bool            `json:"allowed"`
	Reason            string          `json:"reason,omitempty"`
	Pin               *Pin            `json:"pin,omitempty"`
	Contribution      *Contribution   `json:"contribution,omitempty"`
	Current           *View           `json:"current,omitempty"`
	Replay            bool            `json:"replay,omitempty"`
	CurrentApplicable bool            `json:"current_applicable"`
	Authority         string          `json:"authority"`
	Compiled          *CompiledAction `json:"compiled,omitempty"`
}

func sameView(a, b *View) bool {
	if a == nil || b == nil {
		return false
	}
	x, _ := json.Marshal(a)
	y, _ := json.Marshal(b)
	return string(x) == string(y)
}
func applicable(j Journal, p Pin, now time.Time) bool {
	return j.Active && sameView(j.Current, &p.View) && now.Before(j.Current.Expires)
}
func hexDigest(s string) bool {
	if len(s) != 64 {
		return false
	}
	_, err := hex.DecodeString(s)
	return err == nil
}
func nonce() (string, error) {
	var raw [32]byte
	_, err := rand.Read(raw[:])
	return hex.EncodeToString(raw[:]), err
}
func Apply(principal, session string, raw []byte, req Request, now time.Time) ([]byte, Reply, error) {
	reply := Reply{Authority: "owner_transport_state_only"}
	if principal == "" || session == "" || len(principal) > 128 || len(session) > 128 || len(raw) > MaxJournalBytes {
		return nil, reply, errors.New("invalid owner binding")
	}
	j := Journal{Version: 1, Principal: principal, Session: session, Pins: map[string]Pin{}, Contributions: map[string]Contribution{}}
	if len(raw) > 0 {
		if json.Unmarshal(raw, &j) != nil || j.Version != 1 || j.Principal != principal || j.Session != session || j.Pins == nil || j.Contributions == nil {
			return nil, reply, errors.New("invalid durable owner state")
		}
	}
	denied := func(reason string) ([]byte, Reply, error) { reply.Reason = reason; return raw, reply, nil }
	switch req.Operation {
	case "publish":
		v := req.View
		if v == nil || validTask(v.Task) != nil || v.Revision == "" || len(v.Revision) > 128 || !hexDigest(v.PublicationSHA256) || v.SourceRelease == "" || len(v.SourceRelease) > 4096 || !now.Before(v.Expires) || v.Expires.After(now.Add(15*time.Minute)) {
			return denied("invalid_owner_publication")
		}
		if j.Current != nil && v.Revision == j.Current.Revision {
			a, _ := json.Marshal(j.Current)
			b, _ := json.Marshal(v)
			if string(a) != string(b) {
				return denied("same_revision_different_view")
			}
		}
		copyView := *v
		j.Current = &copyView
		j.Active = true
		reply.Current = j.Current
		reply.Allowed = true
	case "withdraw":
		j.Active = false
		reply.Allowed = true
	case "inspect":
		reply.Current = j.Current
		reply.Allowed = true
	case "pin":
		if req.InferenceID == "" || len(req.InferenceID) > 128 || !hexDigest(req.InputSHA256) {
			return denied("invalid_inference_binding")
		}
		// Replay an original pin without rebinding it to the current publication.
		for _, p := range j.Pins {
			if p.InferenceID == req.InferenceID {
				if p.InputSHA256 != req.InputSHA256 {
					return denied("inference_input_conflict")
				}
				reply.Pin = &p
				reply.Allowed = true
				reply.Replay = true
				reply.CurrentApplicable = applicable(j, p, now)
				return raw, reply, nil
			}
		}
		if !j.Active || j.Current == nil || !now.Before(j.Current.Expires) {
			return denied("current_publication_unavailable")
		}
		if len(j.Pins) >= MaxPins {
			return denied("owner_pin_capacity")
		}
		id, err := nonce()
		if err != nil {
			return nil, reply, err
		}
		p := Pin{ID: id, InferenceID: req.InferenceID, InputSHA256: req.InputSHA256, View: *j.Current, Created: now}
		j.Pins[id] = p
		reply.Pin = &p
		reply.Allowed = true
		reply.CurrentApplicable = true
	case "deliver":
		p, ok := j.Pins[req.PinID]
		if !ok {
			return denied("unknown_inference_pin")
		}
		if req.InferenceID != p.InferenceID || req.InputSHA256 != p.InputSHA256 || req.Text == "" || len(req.Text) > MaxContributionBytes || (req.Finish != "stop" && req.Finish != "length") {
			return denied("nonterminal_or_conflicting_delivery")
		}
		hash := Digest([]byte(req.Text))
		if old, ok := j.Contributions[p.ID]; ok {
			if old.SHA256 != hash || old.Finish != req.Finish {
				return denied("conflicting_replay")
			}
			reply.Contribution = &old
			reply.Allowed = true
			reply.Replay = true
			reply.CurrentApplicable = applicable(j, p, now)
			return raw, reply, nil
		}
		c := Contribution{Pin: p, Text: req.Text, Finish: req.Finish, SHA256: hash}
		j.Contributions[p.ID] = c
		reply.Contribution = &c
		reply.Allowed = true
		reply.CurrentApplicable = applicable(j, p, now)
	case "ready":
		c, ok := j.Contributions[req.PinID]
		if !ok || c.Intake == nil {
			return denied("native_intake_unavailable")
		}
		reply.Contribution = &c
		if len(c.Pin.View.Bindings) > 0 {
			reply.Compiled, _ = Compile(c.Pin.View, *c.Intake)
		}
		reply.Allowed = true
		reply.CurrentApplicable = applicable(j, c.Pin, now)
	case "resolve":
		c, ok := j.Contributions[req.PinID]
		if !ok || req.Intake == nil || c.Finish != "stop" {
			return denied("missing_terminal_contribution")
		}
		accepted, err := Validate(c.Pin.View.Task, c.Text, req.Intake.Decision)
		if err != nil {
			return denied("invalid_semantic_intake")
		}
		a, _ := json.Marshal(accepted)
		b, _ := json.Marshal(req.Intake)
		if string(a) != string(b) {
			return denied("intake_original_binding_conflict")
		}
		if c.Intake != nil {
			prior, _ := json.Marshal(c.Intake)
			if string(prior) != string(b) {
				return denied("conflicting_semantic_replay")
			}
			reply.Replay = true
		} else {
			c.Intake = &accepted
			j.Contributions[req.PinID] = c
		}
		reply.Contribution = &c
		reply.Allowed = true
		reply.CurrentApplicable = applicable(j, c.Pin, now)
	default:
		return denied("unsupported_owner_operation")
	}
	out, err := json.Marshal(j)
	if err != nil {
		return nil, reply, err
	}
	if len(out) > MaxJournalBytes {
		return denied("owner_journal_capacity")
	}
	return out, reply, nil
}
