package main

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestModuleRegistryMatchesProcessContracts(t *testing.T) {
	tests := []struct {
		name      string
		principal uint32
		events    []uint32
	}{
		{"memory", 7, []uint32{5889, 5890, 5891, 5892, 5893, 5894, 5895, 5896, 6143}},
		{"learning", 8, []uint32{6145, 6146}},
		{"routing", 9, []uint32{6401, 6402}},
		{"providers", 33, []uint32{12545, 12546, 12547}},
		{"delegates", 10, []uint32{6657, 6658, 6659, 6660, 6661, 6662, 6663, 6664, 6665, 6666, 6667, 6668, 6669, 6670, 6671, 6672, 6673, 6674, 6675, 6676, 6677, 6678}},
		{"tools", 11, []uint32{6913, 6914}},
		{"workspace", 12, []uint32{7169, 7170, 7171}},
		{"git", 13, []uint32{7425, 7426, 7427, 7428, 7429, 7430}},
		{"skills", 14, []uint32{7681, 7682}},
		{"response-composition", 15, []uint32{7937}},
		{"governance", 19, []uint32{8961}},
		{"roundtable", 21, []uint32{9473, 9475}},
		{"kb-synthesis", 22, []uint32{9729}},
		{"runtime-web", 23, []uint32{9985}},
		{"control-web", 24, []uint32{10241}},
		{"benchmarks", 25, []uint32{10497, 10498}},
		{"sandbox", 26, []uint32{10753, 10754, 10755, 10756}},
		{"economizer", 27, []uint32{11009, 11010, 11011, 11012, 11013, 11014, 11015, 11016, 11017}},
		// Health, typed SQL, and the native host session transport. Store calls
		// lands on. 11266 is not conditional -- the handler opens its pool on
		// first use and answers with the reason when it cannot, so the stage is
		// servable whether or not a database is reachable.
		{"postgres", 28, []uint32{11265, 11266, 11267}},
		{"egress", 32, []uint32{12289, 12290, 12291, 12292, 12293, 12294, 12295}},
		// `aimee` is deliberately absent. It is the one module here whose
		// config depends on the environment: it refuses to serve without a
		// store backend, so in this test's process it has no stage table to
		// compare. Its twenty-three stages are checked against the same
		// contract file by TestModuleStagesMatchContract in the module itself,
		// where the table is built rather than resolved.
	}
	for _, test := range tests {
		config, ok := moduleConfig("/usr/local/libexec/aimee-modules/aimee-module-" + test.name)
		if !ok || config.ModuleName != test.name || config.PrincipalClass != 1 ||
			config.PrincipalRef != test.principal || len(config.Stages) != len(test.events) ||
			config.Handler == nil {
			t.Fatalf("%s config = %#v, ok=%v", test.name, config, ok)
		}
		wantIdle := time.Duration(0)
		if test.name == "economizer" {
			wantIdle = time.Millisecond
		}
		if config.MaxIdlePollInterval != wantIdle {
			t.Fatalf("%s idle poll ceiling = %v, want %v", test.name, config.MaxIdlePollInterval, wantIdle)
		}
		// The stage id is derived from the event kind rather than the position:
		// a module may declare a non-contiguous set when one of its stages is
		// registered conditionally. roundtable serves 1 and 3 here because review
		// (stage 2) is only declared when this process can convene one.
		for index, event := range test.events {
			wantStage := event - (4096 + test.principal*256)
			if config.Stages[index].EventKind != event || config.Stages[index].StageID != wantStage {
				t.Fatalf("%s stage %d = %#v, want event %d / stage %d", test.name, index,
					config.Stages[index], event, wantStage)
			}
		}
	}
}

// THE TABLE ABOVE IS HAND-WRITTEN, so on its own it proves only that the code
// matches a second copy of itself. It did exactly that: git shipped for weeks
// advertising 7425,7426,7427,7430 while process-contracts.json declared
// git-forge-request (7428) and git-credential-resolve (7429) as well, and this
// test — despite its name — agreed with the code because someone updated the
// list to match rather than the contract.
//
// Nothing noticed until callers moved onto those stages: the module HANDLES
// both (Handle routes them) and the grant PERMITS both (serve=7425..7430), but a
// stage that is never advertised is never available, so every call returned
// CAPABILITY_ABSENT in ~40ms. That reads as "the module is down" while the
// module is plainly running, and it silently disabled git credential injection
// (pushes asked for a username) and every forge operation.
//
// So compare against the CONTRACT FILE itself. A stage added to the contract and
// not advertised — or advertised and not declared — now fails here.
func TestAdvertisedStagesMatchTheContractFile(t *testing.T) {
	raw, err := os.ReadFile(filepath.Join("..", "..", "..", "src", "modules", "process-contracts.json"))
	if err != nil {
		t.Fatalf("read process-contracts.json: %v", err)
	}
	var contracts struct {
		Components []struct {
			ID        string `json:"id"`
			Execution string `json:"execution"`
			Runtime   string `json:"runtime"`
			HostedBy  string `json:"hosted_by"`
			Stages    []struct {
				EventKind uint32 `json:"event_kind"`
				Name      string `json:"name"`
			} `json:"stages"`
		} `json:"components"`
	}
	if err := json.Unmarshal(raw, &contracts); err != nil {
		t.Fatalf("parse process-contracts.json: %v", err)
	}
	if len(contracts.Components) == 0 {
		t.Fatal("no components parsed — the schema moved and this test would pass vacuously")
	}

	checked := 0
	for _, declared := range contracts.Components {
		if declared.Execution != "process" || len(declared.Stages) == 0 {
			continue // not a module process; nothing to advertise
		}
		config, ok := moduleConfig("/usr/local/libexec/aimee-modules/aimee-module-" + declared.ID)
		if !ok {
			// UNRECOGNISED is not the same as COULD NOT START, and only the
			// first is a defect here. main.go already draws that line: a
			// recognised module sets ModuleName before giving up, so an empty
			// one means the name matched no case at all.
			//
			// Several modules legitimately return !ok under test -- the store
			// needs a bus socket to reach the postgres module, and there is none
			// here -- but they still name themselves. A module that does not is
			// one the contract says this binary hosts and the registry has never
			// heard of, which is what a rename produces when only one of the two
			// moves.
			//
			// Checking this at all is the point: the loop used to `continue`
			// silently, so the module whose name just changed would be the one
			// nobody compared, while `checked` stayed comfortably non-zero from
			// the other nineteen.
			// AND ONLY FOR A COMPONENT THIS REPOSITORY IMPLEMENTS. A Go
			// component whose descriptor declares no go_sources here is built
			// elsewhere -- config is aimee-module-config, its own program from
			// github.com/RakuenSoftware/aimee-module-config -- so it can never
			// have a case in this binary, and demanding one asks a question
			// with no answer.
			//
			// Found by the guard firing on `config` after a merge brought it in.
			// The guard was right that the name matched nothing; it was wrong
			// that the name was supposed to.
			if declared.Runtime == "go" && declared.HostedBy == "" &&
				config.ModuleName == "" && implementedHere(declared.ID) {
				t.Errorf("%s is declared runtime=go in process-contracts.json but "+
					"aimee-module-%s matches no case in the module registry: the "+
					"contract and the registry disagree about its name",
					declared.ID, declared.ID)
			}
			continue
		}
		checked++
		advertised := map[uint32]bool{}
		for _, s := range config.Stages {
			advertised[s.EventKind] = true
		}
		for _, s := range declared.Stages {
			// roundtable-review is registered ONLY when this process can convene a
			// panel (roundtableReviewer() succeeds), which it cannot under test.
			// That conditionality is deliberate and documented above; every other
			// declared stage is unconditional and must be advertised.
			if s.EventKind == 9474 {
				continue
			}
			if !advertised[s.EventKind] {
				t.Errorf("%s declares %s (event %d) in process-contracts.json but never "+
					"advertises it: calls fail CAPABILITY_ABSENT though the module is running",
					declared.ID, s.Name, s.EventKind)
			}
		}
	}
	// Guard the guard: if nothing was compared, this test proves nothing.
	if checked == 0 {
		t.Fatal("no module was actually compared against the contract")
	}
}

func TestModuleRegistryRejectsUnknownAndBadArguments(t *testing.T) {
	if _, ok := moduleConfig("aimee-module-unknown"); ok {
		t.Fatal("unknown module appeared in Go registry")
	}
	if err := run(context.Background(), []string{"aimee-module-routing"}); !errors.Is(err, errUsage) {
		t.Fatalf("bad arguments error = %v", err)
	}
	if err := run(context.Background(), []string{"aimee-module-unknown", "/unused"}); err == nil {
		t.Fatal("unknown module executable was accepted")
	}
}

// implementedHere reports whether this repository builds the component's Go
// module, by asking its descriptor for go_sources.
//
// A component can be declared in process-contracts.json and implemented in
// another repository; the contract describes the FLEET, not this binary's
// contents. Without this distinction the check above cannot tell "the registry
// forgot a module" from "the module was never ours".
func implementedHere(id string) bool {
	body, err := os.ReadFile(filepath.Join("..", "..", "..", "src", "modules", id, "module.yaml"))
	if err != nil {
		// No descriptor at all: nothing claims it here.
		return false
	}
	var descriptor struct {
		GoSources []string `json:"go_sources"`
	}
	if err := json.Unmarshal(body, &descriptor); err != nil {
		return false
	}
	return len(descriptor.GoSources) > 0
}
