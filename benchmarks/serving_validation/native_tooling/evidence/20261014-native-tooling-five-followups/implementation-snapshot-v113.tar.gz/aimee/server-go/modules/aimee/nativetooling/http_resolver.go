package nativetooling

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
	"unicode/utf8"
)

// HTTPResolver is an owner-configured interpretation backend. Its output must
// still pass exact-excerpt validation and current action-owner authorization.
type HTTPResolver struct {
	Endpoint        string
	Model           string
	Client          *http.Client
	Token           string
	ConstrainJSON   bool
	DisableThinking bool
	MaxTokens       int
	Observe         func(request, response []byte, err error)
}

func (r *HTTPResolver) Resolve(ctx context.Context, task Task, text string) (Decision, error) {
	messages, err := ResolverPrompt(task, text)
	if err != nil {
		return Decision{}, err
	}
	target, err := url.Parse(r.Endpoint)
	if err != nil || target.Host == "" || (target.Scheme != "https" && !(target.Scheme == "http" && (target.Hostname() == "127.0.0.1" || target.Hostname() == "localhost" || target.Hostname() == "::1"))) {
		return Decision{}, errors.New("resolver requires HTTPS or explicit loopback HTTP")
	}
	if r.Model == "" {
		return Decision{}, errors.New("resolver model unavailable")
	}
	max := r.MaxTokens
	if max == 0 {
		max = 512
	}
	if max < 32 || max > 4096 {
		return Decision{}, errors.New("invalid resolver budget")
	}
	payloadFields := map[string]any{"model": r.Model, "messages": messages, "max_tokens": max, "temperature": 0, "stream": false}
	if r.DisableThinking {
		payloadFields["chat_template_kwargs"] = map[string]any{"enable_thinking": false}
	}
	if r.ConstrainJSON {
		payloadFields["response_format"] = map[string]any{"type": "json_schema", "json_schema": map[string]any{"name": "aimee_semantic_intake", "schema": ResolverSchema(task), "strict": true}}
	}
	payload, _ := json.Marshal(payloadFields)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, r.Endpoint, bytes.NewReader(payload))
	if err != nil {
		return Decision{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	if r.Token != "" {
		req.Header.Set("Authorization", "Bearer "+r.Token)
	}
	client := r.Client
	if client == nil {
		client = &http.Client{Timeout: 180 * time.Second}
	}
	res, err := client.Do(req)
	if err != nil {
		if r.Observe != nil {
			r.Observe(payload, nil, err)
		}
		return Decision{}, err
	}
	defer res.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(res.Body, MaxContributionBytes+1))
	if r.Observe != nil {
		r.Observe(payload, raw, err)
	}
	if err != nil {
		return Decision{}, err
	}
	if res.StatusCode != http.StatusOK || len(raw) > MaxContributionBytes {
		return Decision{}, fmt.Errorf("resolver response rejected: HTTP %d", res.StatusCode)
	}
	var envelope struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
			Finish string `json:"finish_reason"`
		} `json:"choices"`
	}
	if json.Unmarshal(raw, &envelope) != nil || len(envelope.Choices) != 1 || envelope.Choices[0].Finish != "stop" {
		return Decision{}, errors.New("resolver output not terminal complete")
	}
	return DecodeDecision([]byte(envelope.Choices[0].Message.Content))
}

// rejectDuplicateKeys preserves an unambiguous interpretation of JSON. Go's
// default decoder otherwise silently overwrites a repeated object key.
func rejectDuplicateKeys(raw []byte) error {
	if !utf8.Valid(raw) {
		return errors.New("invalid resolver UTF-8")
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	var walk func() error
	walk = func() error {
		token, err := d.Token()
		if err != nil {
			return err
		}
		opening, ok := token.(json.Delim)
		if !ok {
			return nil
		}
		switch opening {
		case '{':
			seen := map[string]bool{}
			for d.More() {
				key, err := d.Token()
				if err != nil {
					return err
				}
				name, ok := key.(string)
				if !ok || seen[name] {
					return errors.New("duplicate or invalid resolver key")
				}
				seen[name] = true
				if err := walk(); err != nil {
					return err
				}
			}
		case '[':
			for d.More() {
				if err := walk(); err != nil {
					return err
				}
			}
		default:
			return errors.New("invalid JSON delimiter")
		}
		_, err = d.Token()
		return err
	}
	if !strings.HasPrefix(strings.TrimSpace(string(raw)), "{") {
		return errors.New("resolver must return an object")
	}
	if err := walk(); err != nil {
		return err
	}
	if _, err := d.Token(); err != io.EOF {
		return errors.New("extra resolver JSON")
	}
	return nil
}
