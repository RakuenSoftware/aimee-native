package nativetooling

import (
	"errors"
	"strconv"
	"strings"
)

// Scalar is a declared owner contribution contract, not a semantic fallback.
// It cannot select a capability, extract a number from prose, repair a value,
// infer a subject, or authorize execution. Rich contributions use owner intake.
func ResolveScalar(task Task, text string) (Decision, error) {
	if task.Format != "scalar_integer" || validTask(task) != nil {
		return Decision{}, errors.New("scalar owner contract unavailable")
	}
	value := strings.TrimSpace(text)
	if _, err := strconv.ParseInt(value, 10, 64); err != nil {
		return Decision{}, errors.New("contribution is not one literal integer")
	}
	cap := task.Capabilities[0]
	field := ""
	for name := range cap.Fields {
		field = name
	}
	return Decision{Kind: "content", CapabilityID: cap.ID, Quotes: map[string]string{field: value}, Reason: "owner-declared scalar contribution"}, nil
}
