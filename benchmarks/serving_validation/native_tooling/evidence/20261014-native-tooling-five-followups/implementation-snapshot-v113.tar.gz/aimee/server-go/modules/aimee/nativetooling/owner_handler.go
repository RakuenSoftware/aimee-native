package nativetooling

import (
	"bytes"
	"context"
	"encoding/json"
	"github.com/JBailes/aimee/server-go/bus"
	"io"
	"sync"
	"time"
)

const StageInterpret uint32 = 24
const EventInterpret uint32 = 4096 + 30*256 + StageInterpret

// The Aimee module never holds a bus handler while inference is running.
// A bounded owner queue returns opaque jobs; authenticated host polling collects
// the untrusted interpretation. Database and other owner stages remain usable.
type interpretationJob struct {
	principal string
	deadline  time.Time
	done      bool
	body      any
	cancel    context.CancelFunc
}

func NewOwnerHandler(resolver Resolver) bus.ModuleHandler {
	var mu sync.Mutex
	jobs := map[string]*interpretationJob{}
	slots := make(chan struct{}, 2)
	frame := func(value any) ([]byte, bus.ModuleStatus) {
		raw, err := json.Marshal(value)
		if err != nil {
			return nil, bus.ModuleStatusInternal
		}
		out, err := bus.EncodeCommandResult(raw)
		if err != nil {
			return nil, bus.ModuleStatusInternal
		}
		return out, bus.ModuleStatusOK
	}
	return func(inv bus.ModuleInvocation, raw []byte) ([]byte, bus.ModuleStatus) {
		if inv.StageID != StageInterpret || inv.PrincipalRef != 0 || len(raw) > 262144 {
			return nil, bus.ModuleStatusInvalidRequest
		}
		verb, args, caller, err := bus.DecodeCommandWithContext(raw)
		if err != nil || caller == nil || !caller.Authenticated || caller.Principal == "" {
			return nil, bus.ModuleStatusInvalidRequest
		}
		if inv.Cancelled() {
			return nil, bus.ModuleStatusCancelled
		}
		var request struct {
			Task Task   `json:"task"`
			Text string `json:"text"`
			Job  string `json:"job,omitempty"`
		}
		decoder := json.NewDecoder(bytes.NewReader(args))
		decoder.DisallowUnknownFields()
		if decoder.Decode(&request) != nil || decoder.Decode(new(any)) != io.EOF {
			return nil, bus.ModuleStatusInvalidRequest
		}
		mu.Lock()
		for id, job := range jobs {
			if time.Now().After(job.deadline) {
				job.cancel()
				delete(jobs, id)
			}
		}
		if verb == "poll" || verb == "cancel" {
			job := jobs[request.Job]
			if job == nil || job.principal != caller.Principal {
				mu.Unlock()
				return nil, bus.ModuleStatusInvalidRequest
			}
			if verb == "cancel" {
				job.cancel()
				delete(jobs, request.Job)
				mu.Unlock()
				return frame(map[string]any{"status": "cancelled"})
			}
			if !job.done {
				mu.Unlock()
				return frame(map[string]any{"status": "pending", "job": request.Job})
			}
			body := job.body
			delete(jobs, request.Job)
			mu.Unlock()
			return frame(body)
		}
		if verb != "interpret" || validTask(request.Task) != nil || request.Text == "" || len(request.Text) > MaxContributionBytes {
			mu.Unlock()
			return nil, bus.ModuleStatusInvalidRequest
		}

		if request.Task.Format == "scalar_integer" {
			mu.Unlock()
			intake, err := Interpret(context.Background(), nil, request.Task, request.Text)
			if err != nil {
				return frame(map[string]any{"status": "unresolved", "reason": "scalar_contribution_invalid", "authority": "none"})
			}
			return frame(map[string]any{"status": "interpreted", "intake": intake, "authority": "untrusted_proposed_content"})
		}
		if resolver == nil {
			mu.Unlock()
			return frame(map[string]any{"status": "unresolved", "reason": "semantic_backend_unavailable", "authority": "none"})
		}
		if len(jobs) >= 16 {
			mu.Unlock()
			return frame(map[string]any{"status": "unresolved", "reason": "semantic_owner_capacity", "authority": "none"})
		}
		id, err := nonce()
		if err != nil {
			mu.Unlock()
			return nil, bus.ModuleStatusInternal
		}
		ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
		job := &interpretationJob{principal: caller.Principal, deadline: time.Now().Add(5 * time.Minute), cancel: cancel}
		jobs[id] = job
		mu.Unlock()
		go func() {
			defer cancel()
			var intake Intake
			var err error
			select {
			case slots <- struct{}{}:
				intake, err = Interpret(ctx, resolver, request.Task, request.Text)
				<-slots
			case <-ctx.Done():
				err = ctx.Err()
			}
			body := any(map[string]any{"status": "unresolved", "reason": "semantic_intake_unavailable_or_invalid", "authority": "none"})
			if err == nil {
				body = map[string]any{"status": "interpreted", "intake": intake, "authority": "untrusted_proposed_content"}
			}
			mu.Lock()
			if jobs[id] == job {
				job.body = body
				job.done = true
			}
			mu.Unlock()
		}()
		return frame(map[string]any{"status": "pending", "job": id})
	}
}
