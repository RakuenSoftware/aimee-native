package families

import (
	"context"
	"encoding/json"
	"errors"
	store "github.com/JBailes/aimee/server-go/modules/aimee"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
	"time"
)

var errNativeActionInvalid = errors.New("native action request refused")

func invalidNativeAction(reason string) error {
	return errors.Join(errNativeActionInvalid, errors.New(reason))
}

// Native intake/action association and the canonical action transition commit
// in the same DB1 transaction. The authenticated host still supplies current
// memory guards and owner-compiled effective arguments; the model supplies neither.
func nativeToolingAction(ctx context.Context, q store.Queryer, principal, sid, raw string, req nt.Request, now time.Time) (string, []byte, error) {
	var journal nt.Journal
	if json.Unmarshal([]byte(raw), &journal) != nil || journal.Principal != principal || journal.Session != sid {
		return raw, nil, invalidNativeAction("native owner journal unavailable")
	}
	contribution, ok := journal.Contributions[req.PinID]
	if !ok || contribution.Intake == nil || (contribution.Intake.Decision.Kind != "content" && contribution.Intake.Decision.Kind != "need") {
		return raw, nil, invalidNativeAction("no actionable native intake")
	}
	var action governedActionRequest
	if len(req.Action) == 0 || json.Unmarshal(req.Action, &action) != nil {
		return raw, nil, invalidNativeAction("invalid native action request")
	}
	switch action.Operation {
	case "issue", "admit", "dispatch", "cancel", "outcome", "reconcile", "inspect":
	default:
		return raw, nil, invalidNativeAction("unsupported native action operation")
	}
	if action.Operation == "issue" || action.Operation == "admit" || action.Operation == "dispatch" {
		current, _ := json.Marshal(journal.Current)
		original, _ := json.Marshal(contribution.Pin.View)
		if !journal.Active || journal.Current == nil || string(current) != string(original) || !now.Before(journal.Current.Expires) {
			return raw, nil, invalidNativeAction("native contribution no longer applicable")
		}
	}
	if journal.Actions == nil {
		journal.Actions = map[string]nt.ActionBinding{}
	}
	binding, exists := journal.Actions[req.PinID]
	if action.Operation == "issue" {
		if len(action.Arguments) == 0 {
			return raw, nil, invalidNativeAction("missing owner-compiled native arguments")
		}
		if len(contribution.Pin.View.Bindings) > 0 {
			compiled, err := nt.Compile(contribution.Pin.View, *contribution.Intake)
			if err != nil {
				return raw, nil, errors.Join(errNativeActionInvalid, err)
			}
			var supplied any
			if json.Unmarshal(action.Arguments, &supplied) != nil {
				return raw, nil, invalidNativeAction("invalid action arguments")
			}
			expected, _ := json.Marshal(compiled.Arguments)
			actual, _ := json.Marshal(supplied)
			if compiled.Tool != action.Intent.Tool || string(expected) != string(actual) {
				return raw, nil, invalidNativeAction("action differs from owner capability binding")
			}
		}
		argsSHA := nt.Digest(action.Arguments)
		if exists {
			if binding.ArgumentsSHA256 != argsSHA || binding.Tool != action.Intent.Tool {
				return raw, nil, invalidNativeAction("native action replay changed effective resource")
			}
			// Reuse the canonical receipt, not a new request identity after restart.
			action = governedActionRequest{Operation: "inspect", ActionID: binding.ActionID}
		} else {
			action.Intent.Request = contribution.Pin.InferenceID
			action.Intent.Task = contribution.Pin.View.Task.ID
			action.Intent.Attempt = contribution.Pin.ID
		}
	} else {
		if !exists {
			return raw, nil, invalidNativeAction("native action has no issued binding")
		}
		id := action.ActionID
		if id == "" {
			id = action.Intent.ID
		}
		if id != binding.ActionID {
			return raw, nil, invalidNativeAction("native action binding changed")
		}
		if (action.Operation == "admit" || action.Operation == "dispatch") && !action.Freshness.MemoryRequired {
			return raw, nil, invalidNativeAction("native action requires current memory-owner guard")
		}
	}
	body, err := json.Marshal(action)
	if err != nil {
		return raw, nil, err
	}
	code, cells, err := governedActionApply(ctx, q, []string{principal, sid, string(body)})
	if err != nil {
		return raw, nil, err
	}
	if code != store.StatusOK || len(cells) != 1 {
		return raw, nil, invalidNativeAction("canonical native action refused")
	}
	if !exists && action.Operation == "issue" {
		var reply struct {
			Allowed bool `json:"allowed"`
			Receipt struct {
				Intent struct {
					ActionID string `json:"action_id"`
				} `json:"intent"`
			} `json:"receipt"`
		}
		if json.Unmarshal([]byte(cells[0]), &reply) != nil || !reply.Allowed || reply.Receipt.Intent.ActionID == "" {
			return raw, nil, invalidNativeAction("canonical native action issue failed")
		}
		journal.Actions[req.PinID] = nt.ActionBinding{ActionID: reply.Receipt.Intent.ActionID, ArgumentsSHA256: nt.Digest(action.Arguments), Tool: action.Intent.Tool}
	}
	next, err := json.Marshal(journal)
	if err != nil {
		return raw, nil, err
	}
	if len(next) > nt.MaxJournalBytes {
		return raw, nil, invalidNativeAction("native journal capacity")
	}
	return string(next), []byte(cells[0]), nil
}
