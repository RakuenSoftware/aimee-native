package nativetooling

import (
	"encoding/json"
	"errors"
	"strconv"
)

// Binding is private owner state. It never enters ResolverPrompt. The owner
// selects the tool and fixed resource; model excerpts fill declared arguments.
type Binding struct {
	CapabilityID  string            `json:"capability_id"`
	Tool          string            `json:"tool"`
	Arguments     map[string]any    `json:"arguments"`
	Fields        map[string]string `json:"fields"`
	FieldEncoding map[string]string `json:"field_encoding,omitempty"`
}
type CompiledAction struct {
	Tool      string         `json:"tool"`
	Arguments map[string]any `json:"arguments"`
}

func Compile(view View, intake Intake) (*CompiledAction, error) {
	if intake.Decision.Kind != "content" && intake.Decision.Kind != "need" {
		return nil, errors.New("contribution not actionable")
	}
	validated, err := Validate(view.Task, intake.Original, intake.Decision)
	if err != nil {
		return nil, err
	}
	a, _ := json.Marshal(validated)
	b, _ := json.Marshal(intake)
	if string(a) != string(b) {
		return nil, errors.New("intake binding mismatch")
	}
	var binding *Binding
	for i := range view.Bindings {
		if view.Bindings[i].CapabilityID == intake.Decision.CapabilityID {
			if binding != nil {
				return nil, errors.New("ambiguous owner binding")
			}
			binding = &view.Bindings[i]
		}
	}
	if binding == nil || binding.Tool == "" {
		return nil, errors.New("owner binding unavailable")
	}
	raw, err := json.Marshal(binding.Arguments)
	if err != nil {
		return nil, err
	}
	args := map[string]any{}
	if json.Unmarshal(raw, &args) != nil || args == nil {
		return nil, errors.New("invalid owner arguments")
	}
	definitions := map[string]Field{}
	for _, capability := range view.Task.Capabilities {
		if capability.ID == binding.CapabilityID {
			definitions = capability.Fields
		}
	}
	for field, encoding := range binding.FieldEncoding {
		if _, ok := binding.Fields[field]; !ok || (encoding != "native" && encoding != "literal_text") {
			return nil, errors.New("invalid owner field encoding")
		}
	}
	seen := map[string]bool{}
	for field, target := range binding.Fields {
		value, ok := intake.Decision.Quotes[field]
		if !ok || target == "" || seen[target] {
			return nil, errors.New("missing or conflicting owner field")
		}
		if _, fixed := args[target]; fixed {
			return nil, errors.New("model excerpt cannot replace fixed resource")
		}
		seen[target] = true
		if definitions[field].Kind == "integer" {
			n, err := strconv.ParseInt(value, 10, 64)
			if err != nil {
				return nil, errors.New("literal is not an integer")
			}
			encoding := binding.FieldEncoding[field]
			if encoding == "literal_text" {
				args[target] = value
			} else if encoding == "" || encoding == "native" {
				args[target] = n
			} else {
				return nil, errors.New("unknown owner field encoding")
			}
		} else {
			args[target] = value
		}
	}
	if len(binding.Fields) != len(intake.Decision.Quotes) {
		return nil, errors.New("unmapped contribution fields")
	}
	return &CompiledAction{Tool: binding.Tool, Arguments: args}, nil
}
