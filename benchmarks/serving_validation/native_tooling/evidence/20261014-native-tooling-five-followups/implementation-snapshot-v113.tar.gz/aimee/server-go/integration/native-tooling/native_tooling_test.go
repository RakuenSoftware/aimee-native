package nativetoolingintegration

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	wire "github.com/JBailes/aimee/server-go/aimee"
	"github.com/JBailes/aimee/server-go/bus"
	store "github.com/JBailes/aimee/server-go/modules/aimee"
	"github.com/JBailes/aimee/server-go/modules/aimee/families"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
	ep "github.com/JBailes/aimee/server-go/modules/execution-policy"
	toolowner "github.com/JBailes/aimee/server-go/modules/tools"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func TestNativeToolingLiveOwnerPins(t *testing.T) {
	home := t.TempDir()
	root := livePool(t)
	ctx := context.Background()
	schema := fmt.Sprintf("native_tooling_%d", time.Now().UnixNano())
	if _, e := root.Exec(ctx, "CREATE SCHEMA "+schema); e != nil {
		t.Fatal(e)
	}
	defer root.Exec(ctx, "DROP SCHEMA "+schema+" CASCADE")
	cfg, e := pgxpool.ParseConfig(os.Getenv("AIMEE_TEST_PG_URL"))
	if e != nil {
		t.Fatal(e)
	}
	cfg.ConnConfig.RuntimeParams["search_path"] = schema
	pool, e := pgxpool.NewWithConfig(ctx, cfg)
	if e != nil {
		t.Fatal(e)
	}
	defer pool.Close()
	for _, name := range []string{"schema_sessions.sql", "schema_native_tooling.sql", "schema_governed_actions.sql"} {
		b, e := os.ReadFile(filepath.Join(schemaDirectory(), name))
		if e != nil {
			t.Fatal(e)
		}
		if _, e = pool.Exec(ctx, string(b)); e != nil {
			t.Fatal(e)
		}
	}
	if _, e = pool.Exec(ctx, `INSERT INTO server_sessions(id,principal) VALUES('session','alice'),('foreign','mallory')`); e != nil {
		t.Fatal(e)
	}
	handler := families.GuardrailState.Handler(explorationLiveDB{liveQueryer{pool}})
	call := func(principal, sid string, req nt.Request, ref uint32) (nt.Reply, uint32, bus.ModuleStatus) {
		b, _ := json.Marshal(req)
		frame, _ := wire.EncodeFields(11, []string{principal, sid, string(b)})
		raw, status := handler(bus.ModuleInvocation{StageID: families.StageGuardrailState, PrincipalRef: ref}, frame)
		if status != bus.ModuleStatusOK {
			return nt.Reply{}, 0, status
		}
		code, cells, e := wire.DecodeFields(raw)
		if e != nil {
			t.Fatal(e)
		}
		var reply nt.Reply
		if code == store.StatusOK && len(cells) == 1 && json.Unmarshal([]byte(cells[0]), &reply) != nil {
			t.Fatal("invalid reply")
		}
		return reply, code, status
	}
	task := nt.Task{ID: "task", Purpose: "propose a literal handoff", Capabilities: []nt.Capability{{ID: "record", Purpose: "record proposed text", Fields: map[string]nt.Field{"body": {Kind: "text", Required: true}}}}}
	view := nt.View{Task: task, Revision: "999", PublicationSHA256: nt.Digest([]byte("first")), SourceRelease: "explicit-research-guard-reference", Expires: time.Now().UTC().Add(5 * time.Minute)}
	if _, _, status := call("alice", "session", nt.Request{Operation: "publish", View: &view}, 73); status != bus.ModuleStatusInvalidRequest {
		t.Fatal("public host impersonation")
	}
	if r, code, _ := call("alice", "session", nt.Request{Operation: "publish", View: &view}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	req := nt.Request{Operation: "pin", InferenceID: "same-inference", InputSHA256: nt.Digest([]byte("input"))}
	ids := make(chan string, 24)
	var wg sync.WaitGroup
	for i := 0; i < 24; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r, code, status := call("alice", "session", req, 0)
			if code != store.StatusOK || status != bus.ModuleStatusOK || !r.Allowed || r.Pin == nil {
				t.Error(r, code, status)
				return
			}
			ids <- r.Pin.ID
		}()
	}
	wg.Wait()
	close(ids)
	pin := ""
	for id := range ids {
		if pin == "" {
			pin = id
		}
		if id != pin {
			t.Fatal("concurrent duplicate pin")
		}
	}
	if pin == "" {
		t.Fatal("no pin")
	}
	view.Revision = "001"
	view.PublicationSHA256 = nt.Digest([]byte("second"))
	if r, code, _ := call("alice", "session", nt.Request{Operation: "publish", View: &view}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	deliver := nt.Request{Operation: "deliver", PinID: pin, InferenceID: req.InferenceID, InputSHA256: req.InputSHA256, Text: "Delivery held.", Finish: "stop"}
	r, code, _ := call("alice", "session", deliver, 0)
	if code != store.StatusOK || !r.Allowed || r.CurrentApplicable || r.Contribution.Pin.View.Revision != "999" {
		t.Fatal(r, code)
	}
	if r, code, _ = call("alice", "session", deliver, 0); code != store.StatusOK || !r.Replay {
		t.Fatal(r, code)
	}
	if _, code, _ = call("mallory", "session", nt.Request{Operation: "inspect"}, 0); code != store.StatusInvalid {
		t.Fatal("foreign owner")
	}
	if _, code, _ = call("alice", "foreign", nt.Request{Operation: "inspect"}, 0); code != store.StatusInvalid {
		t.Fatal("foreign session")
	}
	if r, code, _ = call("alice", "session", nt.Request{Operation: "withdraw"}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	if r, code, _ = call("alice", "session", nt.Request{Operation: "pin", InferenceID: "new", InputSHA256: req.InputSHA256}, 0); code != store.StatusOK || r.Allowed {
		t.Fatal(r, code)
	}

	// A fresh current contribution is bound atomically to one canonical action.
	view.Task = nt.Task{ID: "scalar-task", Format: "scalar_integer", Purpose: "Record a proposed integer", Capabilities: []nt.Capability{{ID: "proposal", Kinds: []string{"content"}, Purpose: "Proposed value", Fields: map[string]nt.Field{"value": {Kind: "integer", Required: true}}}}}
	view.Bindings = []nt.Binding{{CapabilityID: "proposal", Tool: "write_file", Arguments: map[string]any{"path": filepath.Join(home, "proposal.txt")}, Fields: map[string]string{"value": "content"}, FieldEncoding: map[string]string{"value": "literal_text"}}}
	view.Revision = "action-view"
	view.PublicationSHA256 = nt.Digest([]byte("action-view"))
	if r, code, _ = call("alice", "session", nt.Request{Operation: "publish", View: &view}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	r, code, _ = call("alice", "session", nt.Request{Operation: "pin", InferenceID: "action-inference", InputSHA256: req.InputSHA256}, 0)
	if code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	actionPin := *r.Pin
	r, code, _ = call("alice", "session", nt.Request{Operation: "deliver", PinID: actionPin.ID, InferenceID: actionPin.InferenceID, InputSHA256: actionPin.InputSHA256, Text: "13", Finish: "stop"}, 0)
	if code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	intake, e := nt.Interpret(ctx, nil, view.Task, "13")
	if e != nil {
		t.Fatal(e)
	}
	if r, code, _ = call("alice", "session", nt.Request{Operation: "resolve", PinID: actionPin.ID, Intake: &intake}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	t.Setenv("AIMEE_HOME", home)
	if e = os.WriteFile(filepath.Join(home, "policy.json"), []byte(`{"actions":{"max_calls":2,"max_work_units":100000}}`), 0600); e != nil {
		t.Fatal(e)
	}
	args := json.RawMessage(`{"path":"proposal.txt","content":"13"}`)
	resource, e := toolowner.DescribeGovernedAction("write_file", args, home)
	if e != nil {
		t.Fatal(e)
	}
	intent := ep.ActionIntent{Tool: "write_file", Class: resource.Class, Destination: resource.Destination, PayloadDigest: resource.PayloadDigest, WorkUnits: resource.RequestBytes, Purpose: "record proposed content", EvidenceDigest: nt.Digest([]byte("explicit synthetic guard evidence")), ContextReceipt: nt.Digest([]byte("explicit-synthetic-receipt")), RevocationGeneration: "fixture-guard-epoch"}
	actionCall := func(a governedActionRequest) (ep.ActionDecision, uint32) {
		body, _ := json.Marshal(a)
		request := nt.Request{Operation: "action", PinID: actionPin.ID, Action: body}
		payload, _ := json.Marshal(request)
		frame, _ := wire.EncodeFields(11, []string{"alice", "session", string(payload)})
		raw, status := handler(bus.ModuleInvocation{StageID: families.StageGuardrailState}, frame)
		if status != bus.ModuleStatusOK {
			t.Fatal(status)
		}
		code, cells, e := wire.DecodeFields(raw)
		if e != nil {
			t.Fatal(e)
		}
		var d ep.ActionDecision
		if code == store.StatusOK && len(cells) == 1 {
			if e = json.Unmarshal([]byte(cells[0]), &d); e != nil {
				t.Fatal(e)
			}
		}
		return d, code
	}
	issued, code := actionCall(governedActionRequest{Operation: "issue", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class})
	if code != store.StatusOK || issued.Receipt == nil {
		t.Fatal(issued, code)
	}
	intent = issued.Receipt.Intent
	replay, code := actionCall(governedActionRequest{Operation: "issue", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class})
	if code != store.StatusOK || replay.Receipt == nil || replay.Receipt.Intent.ID != intent.ID {
		t.Fatal("issued duplicate action", replay, code)
	}

	changed := json.RawMessage(`{"path":"elsewhere.txt","content":"13"}`)
	if _, code := actionCall(governedActionRequest{Operation: "issue", Intent: intent, Arguments: changed, RegistryClass: resource.Class}); code != store.StatusInvalid {
		t.Fatal("changed owner resource accepted", code)
	}
	if _, code := actionCall(governedActionRequest{Operation: "admit", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class}); code != store.StatusInvalid {
		t.Fatal("missing memory guard accepted", code)
	}
	actionIDs := make(chan string, 12)
	for i := 0; i < 12; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			d, c := actionCall(governedActionRequest{Operation: "issue", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class})
			if c != store.StatusOK || d.Receipt == nil {
				t.Error("concurrent issue failed", c)
				return
			}
			actionIDs <- d.Receipt.Intent.ID
		}()
	}
	wg.Wait()
	close(actionIDs)
	for id := range actionIDs {
		if id != intent.ID {
			t.Fatal("concurrent replay minted action", id)
		}
	}
	freshness := ep.ActionFreshness{EvidenceDigest: intent.EvidenceDigest, ContextReceipt: intent.ContextReceipt, PolicyGeneration: intent.PolicyGeneration, RevocationGeneration: intent.RevocationGeneration, MemoryGuard: "explicit-synthetic-guard-not-enrolled", MemoryRequired: true, Checked: time.Now().UTC(), Expires: time.Now().UTC().Add(time.Second), Authorized: true}
	if admitted, code := actionCall(governedActionRequest{Operation: "admit", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class, Freshness: freshness}); code != store.StatusOK || !admitted.Allowed {
		t.Fatal(admitted, code)
	}
	dispatched, code := actionCall(governedActionRequest{Operation: "dispatch", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class, Freshness: freshness})
	if code != store.StatusOK || !dispatched.DispatchAllowed {
		t.Fatal(dispatched, code)
	}
	if replay, code := actionCall(governedActionRequest{Operation: "dispatch", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class, Freshness: freshness}); code != store.StatusOK || replay.DispatchAllowed {
		t.Fatal("repeat physical dispatch permitted", replay, code)
	}
	if e = os.WriteFile(filepath.Join(home, "proposal.txt"), []byte("13"), 0600); e != nil {
		t.Fatal(e)
	}
	proof, e := toolowner.VerifyGovernedAction("write_file", resource.Arguments, home, intent.Destination, intent.PayloadDigest)
	if e != nil {
		t.Fatal(e)
	}
	// The exact file observation is separately reconciled; generated text is not proof.
	outcome := ep.ActionOutcome{State: proof.State, EvidenceRef: "independent-exact-file-verifier", Destination: proof.Destination, PayloadDigest: proof.PayloadDigest, ObjectVersion: proof.ObjectVersion}
	if observed, code := actionCall(governedActionRequest{Operation: "reconcile", Intent: intent, RegistryClass: resource.Class, Outcome: &outcome}); code != store.StatusOK || observed.Receipt == nil || observed.Receipt.State != "effect_confirmed" {
		t.Fatal(observed, code)
	}

	if r, code, _ := call("alice", "session", nt.Request{Operation: "withdraw"}, 0); code != store.StatusOK || !r.Allowed {
		t.Fatal(r, code)
	}
	if _, code := actionCall(governedActionRequest{Operation: "dispatch", Intent: intent, Arguments: resource.Arguments, RegistryClass: resource.Class, Freshness: freshness}); code != store.StatusInvalid {
		t.Fatal("withdrawn native dispatch accepted", code)
	}
	if observed, code := actionCall(governedActionRequest{Operation: "inspect", ActionID: intent.ID}); code != store.StatusOK || observed.Receipt == nil || observed.Receipt.State != "effect_confirmed" {
		t.Fatal("withdrawal lost historical effect receipt", observed, code)
	}
	digest := sha256.Sum256([]byte("13"))
	t.Log("atomic native/canonical action binding, one dispatch and exact effect verified", hex.EncodeToString(digest[:]))
	t.Log("24-way one immutable pin; old publication retained; replay, host and foreign identity controls, withdrawal all passed (source-release reference remains a research fixture)")
}

func livePool(t *testing.T) *pgxpool.Pool {
	t.Helper()
	url := os.Getenv("AIMEE_TEST_PG_URL")
	if url == "" {
		t.Skip("AIMEE_TEST_PG_URL not set")
	}
	pool, err := pgxpool.New(context.Background(), url)
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	t.Cleanup(pool.Close)

	var encoding string
	if err := pool.QueryRow(context.Background(),
		`SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = current_database()`).
		Scan(&encoding); err != nil {
		t.Fatalf("read encoding: %v", err)
	}
	if encoding != "UTF8" {
		t.Fatalf("database encoding is %s, want UTF8: a byte-counted CHECK "+
			"cannot be distinguished from a character-counted one in SQL_ASCII", encoding)
	}
	return pool
}

// liveQueryer adapts a pgx pool to the interface families are written against.
// Production satisfies that interface with a bus client instead; here the point
// is to run the SQL, so the pool is the shortest path to a real planner.
type liveQueryer struct{ pool *pgxpool.Pool }

func (q liveQueryer) Exec(ctx context.Context, sql string, args ...any) (store.Tag, error) {
	tag, err := q.pool.Exec(ctx, sql, args...)
	if err != nil {
		return nil, err
	}
	return store.RowsAffected(tag.RowsAffected()), nil
}

func (q liveQueryer) Query(ctx context.Context, sql string, args ...any) (store.Rows, error) {
	rows, err := q.pool.Query(ctx, sql, args...)
	if err != nil {
		return nil, err
	}
	return liveRows{rows}, nil
}

func (q liveQueryer) QueryRow(ctx context.Context, sql string, args ...any) store.Row {
	return q.pool.QueryRow(ctx, sql, args...)
}

type liveRows struct {
	inner interface {
		Next() bool
		Scan(...any) error
		Err() error
		Close()
	}
}

func (r liveRows) Next() bool             { return r.inner.Next() }
func (r liveRows) Scan(dest ...any) error { return r.inner.Scan(dest...) }
func (r liveRows) Err() error             { return r.inner.Err() }
func (r liveRows) Close()                 { r.inner.Close() }

type explorationLiveDB struct{ liveQueryer }

func (d explorationLiveDB) Begin(ctx context.Context) (store.Tx, error) {
	tx, e := d.pool.Begin(ctx)
	if e != nil {
		return nil, e
	}
	return explorationLiveTx{tx}, nil
}

type explorationLiveTx struct{ pgx.Tx }

func (q explorationLiveTx) Exec(ctx context.Context, s string, a ...any) (store.Tag, error) {
	tag, e := q.Tx.Exec(ctx, s, a...)
	return store.RowsAffected(tag.RowsAffected()), e
}
func (q explorationLiveTx) Query(ctx context.Context, s string, a ...any) (store.Rows, error) {
	r, e := q.Tx.Query(ctx, s, a...)
	if e != nil {
		return nil, e
	}
	return liveRows{r}, nil
}
func (q explorationLiveTx) QueryRow(ctx context.Context, s string, a ...any) store.Row {
	return q.Tx.QueryRow(ctx, s, a...)
}

// Public wire shape consumed by the registered family; integration tests do
// not import one module's private implementation into another.
type governedActionRequest struct {
	ActionID      string             `json:"action_id,omitempty"`
	Arguments     json.RawMessage    `json:"arguments,omitempty"`
	Operation     string             `json:"operation"`
	Intent        ep.ActionIntent    `json:"intent"`
	RegistryClass string             `json:"registry_class"`
	Freshness     ep.ActionFreshness `json:"freshness"`
	Outcome       *ep.ActionOutcome  `json:"outcome,omitempty"`
}

func schemaDirectory() string {
	if path := os.Getenv("AIMEE_TEST_CORE_SCHEMA_DIR"); path != "" {
		return path
	}
	return "../../modules/aimee/families"
}
