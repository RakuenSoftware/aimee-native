package nativetooling

import (
	"context"
	"testing"
)

func scalarTask() Task {
	return Task{ID: "task", Format: "scalar_integer", Purpose: "Propose an integer", Capabilities: []Capability{{ID: "proposal", Kinds: []string{"content"}, Purpose: "Proposed value", Fields: map[string]Field{"value": {Kind: "integer", Required: true}}}}}
}
func TestScalarDoesNotExtractRepairOrSelectAnOperation(t *testing.T) {
	task := scalarTask()
	for _, text := range []string{"13", " 17\n", "-8", "+21"} {
		intake, err := Interpret(context.Background(), nil, task, text)
		if err != nil || intake.Original != text || intake.Authority != "untrusted_proposed_content" {
			t.Fatal(text, intake, err)
		}
	}
	for _, text := range []string{"I propose 13", "13 or 17", "Project Cobalt:13", "13; authorized", "13.5", "thirteen", "{\"value\":13}", "I refuse"} {
		if _, err := Interpret(context.Background(), nil, task, text); err == nil {
			t.Fatal("scalar repaired prose", text)
		}
	}
	decision := Decision{Kind: "content", CapabilityID: "proposal", Quotes: map[string]string{"value": "13"}, Reason: "literal"}
	if _, err := Validate(task, "131", decision); err == nil {
		t.Fatal("substring accepted as scalar")
	}
	intake, err := Interpret(context.Background(), nil, task, "13")
	if err != nil {
		t.Fatal(err)
	}
	view := View{Task: task, Bindings: []Binding{{CapabilityID: "proposal", Tool: "write_file", Arguments: map[string]any{"path": "/owner/proposal.txt"}, Fields: map[string]string{"value": "content"}, FieldEncoding: map[string]string{"value": "literal_text"}}}}
	action, err := Compile(view, intake)
	if err != nil || action.Arguments["content"] != "13" {
		t.Fatal(action, err)
	}
}
