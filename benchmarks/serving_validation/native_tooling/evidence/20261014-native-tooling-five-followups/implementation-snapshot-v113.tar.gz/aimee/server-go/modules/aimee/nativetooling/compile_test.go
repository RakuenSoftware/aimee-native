package nativetooling

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestOwnerBindingsPreventResourceReplacement(t *testing.T) {
	task := Task{ID: "t", Purpose: "Write a report", Capabilities: []Capability{{ID: "report", Purpose: "Authored report", Fields: map[string]Field{"body": {Kind: "text", Required: true}}}}}
	intake, err := Validate(task, "Delivery held.", Decision{Kind: "content", Reason: "authored body", CapabilityID: "report", Quotes: map[string]string{"body": "Delivery held."}})
	if err != nil {
		t.Fatal(err)
	}
	view := View{Task: task, Bindings: []Binding{{CapabilityID: "report", Tool: "write_file", Arguments: map[string]any{"path": "/owner/report.txt"}, Fields: map[string]string{"body": "content"}}}}
	action, err := Compile(view, intake)
	if err != nil || action.Arguments["path"] != "/owner/report.txt" || action.Arguments["content"] != "Delivery held." {
		t.Fatalf("%+v %v", action, err)
	}
	view.Bindings[0].Fields["body"] = "path"
	if _, err := Compile(view, intake); err == nil {
		t.Fatal("excerpt replaced fixed path")
	}
	view.Bindings[0].Fields["body"] = "content"
	view.Bindings = append(view.Bindings, view.Bindings[0])
	if _, err := Compile(view, intake); err == nil {
		t.Fatal("ambiguous owner mapping accepted")
	}
}
func TestSchemaDiscriminantPrecedesCapability(t *testing.T) {
	task := Task{ID: "t", Purpose: "Propose", Capabilities: []Capability{{ID: "propose", Purpose: "Candidate", Fields: map[string]Field{"value": {Kind: "integer", Required: true}}}}}
	raw, err := json.Marshal(ResolverSchema(task))
	if err != nil {
		t.Fatal(err)
	}
	text := string(raw)
	if !strings.Contains(text, `"properties":{"kind":`) {
		t.Fatalf("schema loses discriminant order: %s", text)
	}
}

func TestOwnerConstrainsSpeechActs(t *testing.T) {
	task := Task{ID: "t", Purpose: "Obtain a source", Capabilities: []Capability{{ID: "lookup", Kinds: []string{"need"}, Purpose: "Request source", Fields: map[string]Field{"source": {Kind: "text", Required: true}}}}}
	_, err := Validate(task, "capacity", Decision{Kind: "content", CapabilityID: "lookup", Quotes: map[string]string{"source": "capacity"}, Reason: "literal"})
	if err == nil {
		t.Fatal("authored content was accepted as a lookup request")
	}
}
