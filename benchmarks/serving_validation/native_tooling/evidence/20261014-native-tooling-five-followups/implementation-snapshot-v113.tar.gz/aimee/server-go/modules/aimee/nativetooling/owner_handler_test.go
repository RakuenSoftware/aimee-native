package nativetooling

import (
	"context"
	"encoding/json"
	"github.com/JBailes/aimee/server-go/bus"
	"testing"
	"time"
)

type pausedResolver struct{ release chan struct{} }

func (r pausedResolver) Resolve(ctx context.Context, task Task, text string) (Decision, error) {
	select {
	case <-r.release:
		return Decision{Kind: "content", CapabilityID: "record", Quotes: map[string]string{"body": text}, Reason: "authored body"}, nil
	case <-ctx.Done():
		return Decision{}, ctx.Err()
	}
}
func TestOwnerInterpretationDoesNotOccupyBusHandler(t *testing.T) {
	release := make(chan struct{})
	defer close(release)
	handler := NewOwnerHandler(pausedResolver{release})
	call := func(verb string, args any, principal string, ref uint32) (map[string]any, bus.ModuleStatus) {
		b, _ := json.Marshal(args)
		request, _ := bus.EncodeCommandWithContext(verb, b, bus.CommandContext{Authenticated: true, Principal: principal})
		raw, status := handler(bus.ModuleInvocation{StageID: StageInterpret, PrincipalRef: ref}, request)
		if status != bus.ModuleStatusOK {
			return nil, status
		}
		body, err := bus.DecodeCommandResult(raw)
		if err != nil {
			t.Fatal(err)
		}
		var reply map[string]any
		if json.Unmarshal(body, &reply) != nil {
			t.Fatal("bad reply")
		}
		return reply, status
	}
	task := Task{ID: "task", Purpose: "Report", Capabilities: []Capability{{ID: "record", Purpose: "Authored body", Fields: map[string]Field{"body": {Kind: "text", Required: true}}}}}
	args := map[string]any{"task": task, "text": "Delivery held."}
	if _, status := call("interpret", args, "alice", 73); status != bus.ModuleStatusInvalidRequest {
		t.Fatal("public host impersonation")
	}
	started := time.Now()
	reply, status := call("interpret", args, "alice", 0)
	if status != bus.ModuleStatusOK || reply["status"] != "pending" || time.Since(started) > time.Second {
		t.Fatal("bus blocked on inference", reply, status)
	}
	job := reply["job"].(string)
	if _, status := call("poll", map[string]any{"job": job}, "mallory", 0); status != bus.ModuleStatusInvalidRequest {
		t.Fatal("foreign job collection")
	}
	reply, _ = call("poll", map[string]any{"job": job}, "alice", 0)
	if reply["status"] != "pending" {
		t.Fatal(reply)
	}
	reply, _ = call("cancel", map[string]any{"job": job}, "alice", 0)
	if reply["status"] != "cancelled" {
		t.Fatal(reply)
	}
	if _, status := call("poll", map[string]any{"job": job}, "alice", 0); status != bus.ModuleStatusInvalidRequest {
		t.Fatal("cancelled job retained")
	}
}
