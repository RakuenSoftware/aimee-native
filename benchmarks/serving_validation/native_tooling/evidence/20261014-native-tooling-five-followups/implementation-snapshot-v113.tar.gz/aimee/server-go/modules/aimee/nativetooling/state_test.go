package nativetooling

import (
	"encoding/json"
	"testing"
	"time"
)

func TestOwnerPinsDoNotSortOrRebindPublications(t *testing.T) {
	now := time.Now().UTC()
	v := View{Task: task(), Revision: "999", PublicationSHA256: Digest([]byte("first")), SourceRelease: "owner-only-release", Expires: now.Add(time.Minute)}
	raw, r, e := Apply("alice", "s", nil, Request{Operation: "publish", View: &v}, now)
	if e != nil || !r.Allowed {
		t.Fatal(r, e)
	}
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "pin", InferenceID: "inference-1", InputSHA256: Digest([]byte("input"))}, now)
	if e != nil || !r.Allowed {
		t.Fatal(r, e)
	}
	pin := *r.Pin
	v.Revision = "001"
	v.PublicationSHA256 = Digest([]byte("second"))
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "publish", View: &v}, now)
	if e != nil || !r.Allowed {
		t.Fatal(r, e)
	}
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "deliver", PinID: pin.ID, InferenceID: pin.InferenceID, InputSHA256: pin.InputSHA256, Text: "held delivery", Finish: "stop"}, now)
	if e != nil || !r.Allowed || r.CurrentApplicable || r.Contribution.Pin.View.Revision != "999" {
		t.Fatal(r, e)
	}
	intake, e := Validate(pin.View.Task, "held delivery", Decision{Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "held delivery"}, Reason: "literal"})
	if e != nil {
		t.Fatal(e)
	}
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "resolve", PinID: pin.ID, Intake: &intake}, now)
	if e != nil || !r.Allowed || r.CurrentApplicable {
		t.Fatal(r, e)
	}
	before := string(raw)
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "deliver", PinID: pin.ID, InferenceID: pin.InferenceID, InputSHA256: pin.InputSHA256, Text: "held delivery", Finish: "stop"}, now)
	if e != nil || !r.Replay || string(raw) != before {
		t.Fatal(r, e)
	}
	// A recycled opaque label with different facts must not revive an old pin.
	v.Revision = "999"
	v.PublicationSHA256 = Digest([]byte("third"))
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "publish", View: &v}, now)
	raw, r, e = Apply("alice", "s", raw, Request{Operation: "pin", InferenceID: pin.InferenceID, InputSHA256: pin.InputSHA256}, now)
	if e != nil || !r.Replay || r.CurrentApplicable || r.Pin.View.PublicationSHA256 == v.PublicationSHA256 {
		t.Fatal(r, e)
	}
	_ = raw
}
func TestOwnerWithdrawalConflictingReplayAndForeignPrincipal(t *testing.T) {
	now := time.Now().UTC()
	v := View{Task: task(), Revision: "view", PublicationSHA256: Digest([]byte("view")), SourceRelease: "release", Expires: now.Add(time.Minute)}
	raw, _, _ := Apply("alice", "s", nil, Request{Operation: "publish", View: &v}, now)
	raw, r, _ := Apply("alice", "s", raw, Request{Operation: "pin", InferenceID: "i", InputSHA256: Digest([]byte("input"))}, now)
	pin := *r.Pin
	raw, _, _ = Apply("alice", "s", raw, Request{Operation: "withdraw"}, now)
	_, r, e := Apply("alice", "s", raw, Request{Operation: "pin", InferenceID: "new", InputSHA256: pin.InputSHA256}, now)
	if e != nil || r.Allowed {
		t.Fatal(r, e)
	}
	_, r, e = Apply("alice", "s", raw, Request{Operation: "deliver", PinID: pin.ID, InferenceID: pin.InferenceID, InputSHA256: Digest([]byte("changed")), Text: "draft", Finish: "stop"}, now)
	if e != nil || r.Allowed {
		t.Fatal(r, e)
	}
	if _, _, e = Apply("mallory", "s", raw, Request{Operation: "inspect"}, now); e == nil {
		t.Fatal("foreign principal accepted")
	}
	var j Journal
	if json.Unmarshal(raw, &j) != nil || j.Active {
		t.Fatal(j)
	}
}

func TestTruncatedContributionCannotBecomeAnAction(t *testing.T) {
	now := time.Now().UTC()
	v := View{Task: task(), Revision: "view", PublicationSHA256: Digest([]byte("v")), SourceRelease: "release", Expires: now.Add(time.Minute)}
	raw, _, _ := Apply("alice", "s", nil, Request{Operation: "publish", View: &v}, now)
	raw, r, _ := Apply("alice", "s", raw, Request{Operation: "pin", InferenceID: "i", InputSHA256: Digest([]byte("input"))}, now)
	pin := *r.Pin
	raw, r, _ = Apply("alice", "s", raw, Request{Operation: "deliver", PinID: pin.ID, InferenceID: pin.InferenceID, InputSHA256: pin.InputSHA256, Text: "held delivery", Finish: "length"}, now)
	if !r.Allowed {
		t.Fatal("truncated observation should remain durable", r)
	}
	intake, err := Validate(v.Task, "held delivery", Decision{Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "held delivery"}, Reason: "literal"})
	if err != nil {
		t.Fatal(err)
	}
	_, r, _ = Apply("alice", "s", raw, Request{Operation: "resolve", PinID: pin.ID, Intake: &intake}, now)
	if r.Allowed {
		t.Fatal("truncated contribution became actionable")
	}
}
