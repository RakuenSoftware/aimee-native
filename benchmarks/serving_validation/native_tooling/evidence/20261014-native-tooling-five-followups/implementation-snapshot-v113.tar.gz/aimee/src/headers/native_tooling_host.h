#ifndef AIMEE_NATIVE_TOOLING_HOST_H
#define AIMEE_NATIVE_TOOLING_HOST_H
#include "cJSON.h"
#define AIMEE_NATIVE_TOOLING_INTERPRET_STAGE 24u
#define AIMEE_NATIVE_TOOLING_INTERPRET_EVENT (4096u + 30u * 256u + AIMEE_NATIVE_TOOLING_INTERPRET_STAGE)
/* Internal authenticated-host transport. Neither operation is a public tool. */
cJSON *native_tooling_host_command(const char *session, const cJSON *request);
cJSON *native_tooling_owner_call(const char *session, cJSON *request);
cJSON *native_tooling_publish_view(const char *session, const cJSON *view);
cJSON *native_tooling_interpret_terminal(const char *session, const char *pin,
                                         const char *inference, const char *input_sha,
                                         const char *text, const char *finish);
/* Scope a trusted owner-compiled dispatch to the original native intake. */
int native_tooling_action_enter(const char *session, const char *pin);
void native_tooling_action_leave(void);
const char *native_tooling_current_action_pin(void);
#endif
