#ifndef DEC_AGENT_TOOLS_H
#define DEC_AGENT_TOOLS_H 1

#include "agent_protocol.h"
#include "agent_types.h"
#include "cJSON.h"
#include <stdint.h>

/* Tool execution (Unix only) */
char *tool_bash(const char *command, int timeout_ms);
char *tool_execute_script(const char *language, const char *body, int timeout_secs,
                          const char *workdir, const char *env_json);
/* Read a file. When raw==0, each line is prefixed with a "LINE:HASH| " anchor
 * and an immutable read snapshot is minted (its id echoed in a header line) so
 * edit_file can edit by anchor. raw==1 restores the un-anchored byte output for
 * grep pipelines / binary sniffing. */
char *tool_read_file(const char *path, int offset, int limit, int raw);
char *tool_write_file(const char *path, const char *content);
/* Surgical edit: replace old_string with new_string in an existing file.
 * old_string must occur exactly once unless replace_all is non-zero (then all
 * occurrences are replaced). Returns the same structured JSON result as
 * tool_write_file on success, or an "error: ..." string. */
char *tool_edit_file(const char *path, const char *old_string, const char *new_string,
                     int replace_all);
/* Anchored transactional edit: apply `edits` (JSON array of {op,at/from/to,text})
 * against the read snapshot `snapshot_id`, verifying each anchor's full digest
 * before an atomic write-back. Returns the tool_write_file diff payload on
 * success, a structured stale_anchor/conflict payload (carrying a fresh
 * snapshot_id) on rejection, or a dry_run preview (unified diff + blast radius)
 * when dry_run is non-zero. */
char *tool_edit_file_anchored(const char *path, const char *snapshot_id, cJSON *edits, int dry_run);
char *tool_list_files(const char *path, const char *pattern);
char *tool_verify(const char *check_type, const char *target, const char *expected);
char *tool_git_log(const char *repo_path, int count);
char *tool_grep(const char *path, const char *pattern, int max_results);
/* Part III anchored/agent-shaped tools (posix/agent_tools_anchored.c). */
char *tool_read_outline(const char *path);
char *tool_read_symbol(const char *symbol, const char *path);
char *tool_edit_symbol(const char *symbol, const char *path, const char *op, const char *text);
char *tool_grep_anchored(const char *path, const char *pattern, int max_results);
char *tool_run_tests(const char *command, int timeout_ms);
/* Token-lean extractive page reading (posix/web_read.c). ref = a search handle
 * ("r2") or a raw http(s) URL. query drives literal+lexical span extraction;
 * span>0 pulls one span; mode="full" spills the whole page by ref. */
char *tool_web_read(const char *ref, const char *query, int span, const char *mode);
/* Register rN->URL handles from a web_search result block (so web_read can take
 * "r2"). */
void web_handle_register_from_search(const char *search_output);
char *tool_git_diff(const char *repo_path, const char *ref);
char *tool_git_status(const char *repo_path);
char *tool_env_get(const char *name);
char *tool_test(const char *path, const char *check);
char *tool_request_input(const char *question);
char *tool_code_search(const char *query, const char *project, int max_results);
char *tool_find_symbol(const char *identifier);
char *tool_create_note(const char *title, const char *content, const char *tags);
char *tool_list_notes(const char *tag, int limit);
char *tool_search_notes(const char *query);
char *dispatch_tool_call(const char *name, const char *arguments_json, int timeout_ms);

/* Server registration seam for the separately supervised event-bus tool
 * classifier. classification values are the AIMEE_TOOL_CLASS_* constants.
 * There is no local classification fallback: an absent or failed provider
 * leaves the tool unclassified. */
typedef int (*agent_tool_classifier_fn)(const char *name, int *classification);
void agent_tools_register_classifier(agent_tool_classifier_fn classifier);
typedef int (*agent_tool_action_begin_fn)(const char *, struct cJSON **, const char *, const char *,
                                          int);
typedef char *(*agent_tool_action_finish_fn)(const char *, char *);
void agent_tools_register_action_owner(agent_tool_action_begin_fn begin,
                                       agent_tool_action_finish_fn finish);

/* Bind a successful execution-policy decision to the next dispatch on this
 * thread. External mutations and unknown remote tools refuse execution without
 * this trusted caller signal; model-provided arguments cannot set it. */
void agent_tools_set_effect_authorized(int authorized);
/* A native contribution must use a canonical owner adapter for every dispatch. */
void agent_tools_set_action_required(int required);

/* Tool definition builders */
struct cJSON *build_tools_array(void);
struct cJSON *build_tools_array_responses(void);
struct cJSON *build_tools_array_anthropic(void);
struct cJSON *delegate_respond_spec(void);
int agent_tools_append_delegate_respond_tool(struct cJSON *tools);
int agent_tools_strip_delegate_respond(parsed_response_t *parsed);
int agent_tools_tool_allowed_for_role(const char *role, const char *tool_name);
void agent_tools_filter_for_role(struct cJSON *tools, const char *role);

/* Look up a tool's parameter schema (the `function.parameters` object) by
 * tool name. Returns a borrowed pointer into a process-lifetime cache; the
 * caller MUST NOT cJSON_Delete it. Returns NULL if the tool is not in the
 * registry. The cache is built lazily on the first call from
 * build_tools_array() and is safe to call concurrently — first caller
 * wins; subsequent callers reuse the same pointer. */
struct cJSON *agent_tool_get_schema_cached(const char *tool_name);

/* Write up to `max` built-in tool names into `out`, returning how many.
 * The names are borrowed from the process-lifetime schema cache. */
int agent_tool_known_names(const char **out, int max);

/* Walk an OpenAI-format tools array (each element {type:"function",
 * function:{name, description, parameters}}) and rewrite each tool's
 * `function.parameters` schema in place via tool_schema_sanitize for
 * the given provider. No-op for providers that pass schemas through
 * unchanged (openai, openrouter, codex, gemini). Active for
 * llama_native, llama-eval, and ollama. The array is modified in place; ownership
 * unchanged. */
void agent_tools_sanitize_for_provider(struct cJSON *tools, const char *provider_name);
void agent_tools_sanitize_for_agent(struct cJSON *tools, const agent_t *agent);

char *dispatch_tool_call_ctx(const char *name, const char *arguments_json, int timeout_ms);
void agent_tools_set_dispatch_role(const char *role);

/* The toolset THIS THREAD's turn resolves against, overriding the role. Thread-local
 * because delegate turns run on pooled worker threads and overlap: the process-wide
 * AIMEE_ACTIVE_TOOLSET env var this replaces was set per turn with a save/restore
 * bracket, which looked scoped while a concurrent delegate's setenv changed what
 * this one resolved — a reviewer could resolve a coder's toolset. The env var is
 * still honoured (it is how the single-process CLI passes --toolset); this takes
 * precedence. Set NULL/"" to clear. */
void agent_tools_set_active_toolset(const char *toolset);
const char *agent_tools_active_toolset(void);
const char *agent_tools_dispatch_role(void);

/* Git-write seam (git_commit / git_push / git_branch / git_pr).
 *
 * Those tools are implemented in the SERVER tier (the MCP git dispatch, which owns
 * the worktree refusal, branch-ownership and verify rails), but the agent tool
 * surface lives in the agent tier and is linked by binaries and tests that carry no
 * server objects. Calling across that boundary directly would break their links and
 * invert the tier order, so the server REGISTERS its dispatcher here at startup and
 * the agent tier calls through the pointer — the same shape as wfe_set_forge_provider
 * and workspace_provider_active.
 *
 * Unregistered (thin client, unit tests) the git-write tools are neither ADVERTISED
 * nor dispatchable: an agent is never offered a tool that cannot work. Returns MCP
 * content blocks (caller owns), or NULL for an unknown tool. */
typedef struct cJSON *(*agent_git_write_fn)(const char *tool, struct cJSON *args, const char *sid);
void agent_tools_set_git_write_provider(agent_git_write_fn fn);
agent_git_write_fn agent_tools_git_write_provider(void);

/* 1 if `name` is one of the git-write tools that ride the seam above. */
int agent_tools_is_git_write(const char *name);

/* Validate that the built-in tool table and the egress declaration registry
 * (modules/workflows/tool_egress.c) cover EXACTLY the same set of tools.
 *
 * This is the invariant that makes the externalization gate fail closed: a tool
 * added to the table without a declaration, or a declaration naming a tool that
 * no longer exists, is a startup error rather than a silent gate bypass.
 *
 * Checks, in order:
 *   - every built-in has a declaration, and it is not TOOL_EGRESS_UNSET;
 *   - every non-alias declaration names a real built-in;
 *   - no built-in name appears twice in either set.
 *
 * Returns 0 when the invariant holds. On failure returns -1 and, when `err` is
 * non-NULL, writes a human-readable reason naming the offending tool. */
int agent_tools_validate_egress_table(char *err, size_t err_len);

/* MCP-derived tools ────────────────────────────────────────────────────────
 *
 * aimee's MCP dispatch table is the single source of truth for which tools exist.
 * Entries marked native are registered here at startup so aimee's OWN agents get
 * them too, deriving the advert, the schema and the dispatch from the one
 * declaration instead of restating each by hand in a separate registry.
 *
 * That restating is not a hypothetical cost. git_commit/git_push/git_pr were
 * MCP-only, so the implement delegate's only route to land work was shelling out
 * to git — the exact thing require_aimee_git forbids. index_find_callers was
 * MCP-only, so a review panel asked "is this still called?" had no tool that could
 * answer and hedged on a symbol with twelve callers one query away. Both shipped
 * green and were found by watching a delegate on real hardware.
 *
 * Reusing the MCP schema rather than writing a native one is deliberate: a second
 * hand-written schema is how git_commit came to advertise parameters (add_all,
 * set_upstream) that its handler had never accepted.
 *
 * `call` runs the tool; `advert` returns its MCP tools/list entry ({"description",
 * "inputSchema"}, caller owns) or NULL if unknown. Unregistered — thin client,
 * unit tests — no MCP-derived tool is advertised or dispatchable, so a binary
 * without the server tier links and behaves exactly as before. */
typedef struct cJSON *(*agent_mcp_call_fn)(const char *tool, struct cJSON *args, const char *sid);
typedef struct cJSON *(*agent_mcp_advert_fn)(const char *tool);
void agent_tools_set_mcp_provider(agent_mcp_call_fn call, agent_mcp_advert_fn advert);
agent_mcp_call_fn agent_tools_mcp_call_provider(void);

/* Declare an MCP tool as part of aimee's native surface. Idempotent. Must be
 * called before the first build_tools_array() so the schema cache sees it. */
void agent_tools_register_mcp_tool(const char *name);

/* 1 if `name` was registered above and so dispatches through the MCP provider. */
int agent_tools_is_mcp_derived(const char *name);

/* Shell-git gate seam: 1 if this shell command must be refused because git belongs
 * to aimee (require_aimee_git). Registered by the server for the same reason as the
 * git-write provider — the decision needs the config dial, the forge credential and
 * the command classifier, which live in tiers the agent surface cannot link.
 *
 * `cwd` is the directory the command would run in, and is REQUIRED for the decision
 * to be correct rather than merely safe: "can aimee do git here?" is answered per
 * repo (the credential ladder's per-host vault rung keys on the checkout's origin).
 * Passing no directory collapses the question to "does the server have its own
 * identity?", which most deployments never configure — the gate then concludes
 * aimee has no git and never fires, on exactly the boxes where it should.
 *
 * Unregistered, there is no gate — a rule with no working alternative is breakage,
 * not policy, so the absence of the alternative disables the rule by construction. */
typedef int (*agent_shell_git_gate_fn)(const char *command, const char *cwd);
void agent_tools_set_shell_git_gate(agent_shell_git_gate_fn fn);
agent_shell_git_gate_fn agent_tools_shell_git_gate(void);

/* Tool-call lifecycle hook. A streaming chat worker or a /v1/runs worker
 * installs a thread-local callback (NULL by default — every other caller is
 * unaffected) before running a turn; dispatch_tool_call_ctx fires it as each
 * tool starts and completes so the turn's tool activity can be surfaced to the
 * chat SSE / ACP session/update stream and to /v1/runs events. `phase` is
 * "started" or "completed". Mirrors the agent_tools_set_dispatch_role pattern. */
typedef void (*agent_tool_event_cb_t)(const char *phase, const char *tool_name, void *ud);
void agent_tools_set_tool_event_cb(agent_tool_event_cb_t cb, void *ud);

/* Tool-call COMPLETION audit hook. Distinct from the streaming tool-event hook
 * above: this is a PROCESS-GLOBAL, NULL-by-default hook (like the vault/sandbox
 * audit hooks) that the server installs ONCE at startup so a bridge can record
 * every completed tool dispatch's OUTCOME on the audit bus. It fires exactly once
 * per dispatch_tool_call_ctx, after execution, on every return path (success,
 * error, timeout, refused). It carries ONLY classified enums + the principal —
 * never argument or result content, and never the raw error text an MCP server
 * returned. A thin client that links the tools module but not the bus leaves the
 * hook NULL and is unaffected (D7). The pre-tool-check governed-action row already
 * records identity; this records the outcome the pre-check row cannot see. */
typedef struct
{
   const char *actor;       /* principal (session id / role), captured on the dispatch thread */
   const char *verdict;     /* "ok" | "error" | "timeout" | "refused" */
   const char *reason_code; /* "" | "guardrail" | "role" | "cancelled" | "tool_error" | */
                            /* "timeout" | "unknown_tool" | "bad_args" | "policy" |       */
                            /* "effect_contract" | "precondition" | "postcondition"        */
   const char *mode;        /* "internal" | "outbound" | "outbound:stdio" | */
                            /* "outbound:sse" | "served"                    */
} agent_tool_completion_t;
typedef void (*agent_tool_completion_cb_t)(const char *tool, const agent_tool_completion_t *outcome,
                                           void *ud);
void agent_tools_set_tool_completion_cb(agent_tool_completion_cb_t cb, void *ud);

/* Fire the completion hook (a no-op unless one is installed). Called by the
 * dispatcher at the end of every tool call; lives in the light
 * agent_tools_completion.c TU so the dispatcher's callers need not link the bus. */
void agent_tools_emit_tool_completion(const char *tool, const agent_tool_completion_t *outcome);

/* Test seam: fire the installed completion hook with a given outcome, so the
 * bridge's field mapping and the bus->ledger path can be exercised without
 * linking the whole dispatcher. No-op if no hook is installed. */
void agent_tools_fire_tool_completion_for_test(const char *tool,
                                               const agent_tool_completion_t *outcome);

/* Auto-snapshot turn context: call before each tool-call round so that all
 * write_file / edit_file calls in the round share one fsnap snapshot. */
void agent_tools_begin_turn(int turn);
int agent_tools_get_turn(void);
int64_t agent_tools_get_snap_id(void);
void agent_tools_set_snap_id(int64_t id);

/* Delegate parent-worktree write guard.
 * read_only_root remains readable but must not be writable through local tools.
 * write_root is an optional exception, normally the delegate's isolated worktree. */
void agent_tools_parent_write_guard_set(const char *read_only_root, const char *write_root);
void agent_tools_parent_write_guard_clear(void);
const char *agent_tools_parent_write_guard_root(void);
const char *agent_tools_parent_write_guard_write_root(void);
int agent_tools_parent_write_guard_blocks(const char *path, const char *cwd);

/* May this delegate mutate what aimee knows: its memory, code index, notes and
 * docs? The `knowledge_write` permission, resolved once when the delegate was
 * created and set here for the run.
 *
 * Withheld, three things follow: aimee's own knowledge is kept out of the
 * system prompt, the indexed and memory tools are refused, and an `aimee ...`
 * shell command that would mutate that state is refused. The delegate still
 * reads the checkout it was given.
 *
 * DEFAULTS TO ALLOWED, and that is the honest default: an ordinary turn that
 * never had a delegate role behaves as it always did. The withholding is what
 * has to be declared. */
/* May this delegate run commands? The `shell` permission, resolved once when the
 * delegate was created and set here for the run.
 *
 * Withheld, `bash` and `execute_script` are refused at dispatch whatever toolset
 * the delegate was given. That independence is the point: which toolset a role
 * resolves to is a separate map with its own alias list, and a role an operator
 * defined without `shell` still resolves to whatever toolset its NAME implies.
 * The permission is what actually binds.
 *
 * DEFAULTS TO ALLOWED, like knowledge_write and for the same reason: an ordinary
 * turn that never had a delegate role behaves as it always did. Withholding is
 * what has to be declared. */
/* The tools this delegate's permissions withhold, whatever toolset it resolved
 * to. Set once per run from the resolved set; read by the filter that advertises
 * tools AND by dispatch, so what is offered and what is allowed cannot disagree.
 *
 * `denied` is borrowed, not copied: it must outlive the run. Passing NULL (or a
 * count of 0) withholds nothing, which is what an ordinary turn wants. */
void agent_tools_denied_set(const char *const *denied, int count);
int agent_tools_tool_denied(const char *tool);

void agent_tools_shell_set(int allowed);
int agent_tools_shell_allowed(void);

void agent_tools_knowledge_write_set(int allowed);
int agent_tools_knowledge_write_allowed(void);

/* Read-only-delegate gate (backend-agnostic write capability). A delegate that
 * is not write-capable (see the write_capable field, derived once at dispatch
 * from role + write policy) is blocked from ALL file writes on the native tool
 * backend — the same read-only posture the codex sandbox enforces for the CLI
 * backend. Set once per delegation at the write-guard seam; reset by _clear. */
void agent_tools_write_capable_set(int capable);
int agent_tools_readonly_delegate_blocks(void);

/* Session-isolation backstop (Layer 2, default-on via require_session_worktree):
 * returns 1 to BLOCK a server-side agent write whose normalized target is not
 * inside this session's aimee-managed worktree, else 0. No-op (returns 0) only
 * when require_session_worktree is explicitly false. Mirrors the client-side
 * attention-guard isolation policy for aimee's own in-process agent writes. */
int agent_tools_session_isolation_blocks(const char *path, const char *cwd);

#endif /* DEC_AGENT_TOOLS_H */
