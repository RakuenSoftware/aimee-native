/* Native tooling host glue: identity, durable pins and current source guards.
 * Semantic decisions belong to the Go owner; physical dispatch stays in tools. */
#include "native_tooling_host.h"
#include "db1_client/session_state.h"
#include "ingress_preinject.h"
#include "module_commands.h"
#include "request_context.h"
#include <aimee/tools/module_api.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static int native_key_equal(const char *a, const char *b)
{
   if (!a || !b)
      return 0;
   for (; *a && *b; a++, b++)
   {
      unsigned char x = (unsigned char)*a, y = (unsigned char)*b;
      if (x >= 'A' && x <= 'Z')
         x += 'a' - 'A';
      if (y >= 'A' && y <= 'Z')
         y += 'a' - 'A';
      if (x != y)
         return 0;
   }
   return *a == *b;
}
int native_tooling_json_unambiguous(const cJSON *value)
{
   if (!value)
      return 0;
   for (const cJSON *a = value->child; a; a = a->next)
   {
      if (cJSON_IsObject(value))
         for (const cJSON *b = a->next; b; b = b->next)
            if (native_key_equal(a->string, b->string))
               return 0;
      if (!native_tooling_json_unambiguous(a))
         return 0;
   }
   return 1;
}
int native_tooling_pin_argument(const cJSON *request, const char **pin)
{
   if (!pin)
      return -1;
   *pin = NULL;
   if (!cJSON_IsObject(request))
      return -1;
   const cJSON *value = cJSON_GetObjectItemCaseSensitive(request, "native_pin");
   if (!value)
   {
      for (const cJSON *item = request->child; item; item = item->next)
         if (native_key_equal(item->string, "native_pin"))
            return -1; /* A misspelled reserved field cannot select legacy mode. */
      return 0;
   }
   if (!native_tooling_json_unambiguous(request))
      return -1;
   *pin = cJSON_GetStringValue(value);
   return !*pin || !(*pin)[0] || strlen(*pin) > 128 ? -1 : 0;
}
static __thread char native_action_pin[129];
static __thread int native_action_required;
static __thread char native_action_principal[129], native_action_request[129],
    native_action_source[33];
void native_tooling_action_leave(void)
{
   native_action_pin[0] = 0;
   native_action_required = 0;
}
int native_tooling_action_enter(const char *session, const char *pin)
{
   native_tooling_action_leave();
   const request_context_t *ctx = request_context_get();
   if (!ctx || !ctx->memory_source_release[0] || !pin || !pin[0] || strlen(pin) > 128)
      return -1;
   cJSON *request = cJSON_CreateObject();
   cJSON_AddStringToObject(request, "operation", "ready");
   cJSON_AddStringToObject(request, "pin_id", pin);
   cJSON *reply = native_tooling_owner_call(session, request);
   cJSON_Delete(request);
   cJSON *contribution = cJSON_GetObjectItemCaseSensitive(reply, "contribution");
   cJSON *original = cJSON_GetObjectItemCaseSensitive(contribution, "pin");
   cJSON *view = cJSON_GetObjectItemCaseSensitive(original, "view");
   const char *source =
       cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(view, "source_release"));
   int ok = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(reply, "allowed")) &&
            cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(reply, "current_applicable")) && source &&
            !strcmp(source, ctx->memory_source_release);
   cJSON_Delete(reply);
   if (!ok)
      return -1;
   native_action_required = 1;
   snprintf(native_action_pin, sizeof(native_action_pin), "%s", pin);
   snprintf(native_action_principal, sizeof(native_action_principal), "%s", ctx->principal);
   snprintf(native_action_request, sizeof(native_action_request), "%s", ctx->request_id);
   snprintf(native_action_source, sizeof(native_action_source), "%s", ctx->memory_source_release);
   return 0;
}
const char *native_tooling_current_action_pin(void)
{
   if (!native_action_required)
      return "";
   const request_context_t *ctx = request_context_get();
   if (!ctx || ctx->context_refused || strcmp(ctx->principal, native_action_principal) ||
       strcmp(ctx->request_id, native_action_request) ||
       strcmp(ctx->memory_source_release, native_action_source))
      return NULL; /* A changed scope must never fall back to legacy dispatch. */
   return native_action_pin;
}
cJSON *native_tooling_owner_call(const char *session, cJSON *request)
{
   const request_context_t *ctx = request_context_get();
   if (!ctx || ctx->context_refused || !ctx->principal[0] || !ctx->request_id[0] || !session ||
       !session[0] || !request || !native_tooling_json_unambiguous(request))
      return NULL;
   char *wire = cJSON_PrintUnformatted(request), *reply = malloc(262144);
   cJSON *result = NULL;
   if (wire && reply && db1_native_tooling_apply(ctx->principal, session, wire, reply, 262144) == 0)
      result = cJSON_Parse(reply);
   free(wire);
   free(reply);
   return result;
}
cJSON *native_tooling_publish_view(const char *session, const cJSON *view)
{
   const request_context_t *ctx = request_context_get();
   void *guard = NULL;
   if (!ctx || !ctx->memory_source_release[0] || !cJSON_IsObject(view) ||
       !native_tooling_json_unambiguous(view) || ingress_preinject_acquire_send_guard(&guard) != 0)
      return NULL;
   cJSON *copy = cJSON_Duplicate(view, 1);
   cJSON_DeleteItemFromObjectCaseSensitive(copy, "source_release");
   cJSON_AddStringToObject(copy, "source_release", ctx->memory_source_release);
   cJSON *request = cJSON_CreateObject();
   cJSON_AddStringToObject(request, "operation", "publish");
   cJSON_AddItemToObject(request, "view", copy);
   cJSON *result = native_tooling_owner_call(session, request);
   cJSON_Delete(request);
   ingress_preinject_release_send_guard(guard);
   return result;
}
cJSON *native_tooling_interpret_terminal(const char *session, const char *pin,
                                         const char *inference, const char *input_sha,
                                         const char *text, const char *finish)
{
   if (!pin || !inference || !input_sha || !text || !finish)
      return NULL;
   cJSON *request = cJSON_CreateObject();
   cJSON_AddStringToObject(request, "operation", "deliver");
   cJSON_AddStringToObject(request, "pin_id", pin);
   cJSON_AddStringToObject(request, "inference_id", inference);
   cJSON_AddStringToObject(request, "input_sha256", input_sha);
   cJSON_AddStringToObject(request, "text", text);
   cJSON_AddStringToObject(request, "finish", finish);
   cJSON *delivered = native_tooling_owner_call(session, request);
   cJSON_Delete(request);
   if (strcmp(finish, "stop") ||
       !cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(delivered, "allowed")))
      return delivered;
   cJSON *contribution = cJSON_GetObjectItemCaseSensitive(delivered, "contribution");
   if (cJSON_IsObject(cJSON_GetObjectItemCaseSensitive(contribution, "intake")))
      return delivered; /* Durable replay does not rerun semantic inference. */
   cJSON *original_pin = cJSON_GetObjectItemCaseSensitive(contribution, "pin");
   cJSON *view = cJSON_GetObjectItemCaseSensitive(original_pin, "view");
   cJSON *task = cJSON_GetObjectItemCaseSensitive(view, "task");
   const request_context_t *ctx = request_context_get();
   cJSON *args = cJSON_CreateObject(), *caller = cJSON_CreateObject();
   cJSON_AddItemToObject(args, "task", cJSON_Duplicate(task, 1));
   cJSON_AddStringToObject(args, "text", text);
   cJSON_AddBoolToObject(caller, "authenticated", 1);
   cJSON_AddStringToObject(caller, "principal", ctx->principal);
   cJSON *interpreted = aimee_module_command_call_context(AIMEE_NATIVE_TOOLING_INTERPRET_EVENT,
                                                          AIMEE_NATIVE_TOOLING_INTERPRET_STAGE,
                                                          "interpret", args, caller);
   cJSON_Delete(args);
   struct timespec started, now, delay = {0, 100000000};
   clock_gettime(CLOCK_MONOTONIC, &started);
   while (cJSON_IsObject(interpreted))
   {
      const char *status =
          cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(interpreted, "status"));
      if (!status || strcmp(status, "pending"))
         break;
      const char *job = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(interpreted, "job"));
      if (!job || strlen(job) != 64)
         break;
      cJSON *poll = cJSON_CreateObject();
      cJSON_AddStringToObject(poll, "job", job);
      clock_gettime(CLOCK_MONOTONIC, &now);
      const request_context_t *current = request_context_get();
      int expired = now.tv_sec - started.tv_sec >= 180 || !current || current->context_refused;
      cJSON_Delete(interpreted);
      if (!expired)
         nanosleep(&delay, NULL);
      interpreted = aimee_module_command_call_context(AIMEE_NATIVE_TOOLING_INTERPRET_EVENT,
                                                      AIMEE_NATIVE_TOOLING_INTERPRET_STAGE,
                                                      expired ? "cancel" : "poll", poll, caller);
      cJSON_Delete(poll);
      if (expired)
         break;
   }
   cJSON_Delete(caller);
   cJSON_Delete(delivered);
   cJSON *intake = cJSON_GetObjectItemCaseSensitive(interpreted, "intake");
   if (!cJSON_IsObject(intake))
      return interpreted;
   request = cJSON_CreateObject();
   cJSON_AddStringToObject(request, "operation", "resolve");
   cJSON_AddStringToObject(request, "pin_id", pin);
   cJSON_AddItemToObject(request, "intake", cJSON_Duplicate(intake, 1));
   cJSON *result = native_tooling_owner_call(session, request);
   cJSON_Delete(request);
   cJSON_Delete(interpreted);
   return result;
}

/* Called only on the authenticated local host control lane, never advertised
 * as a model tool. Model text cannot supply resolve/action operations. */
cJSON *native_tooling_host_command(const char *session, const cJSON *request)
{
   if (!cJSON_IsObject(request) || !native_tooling_json_unambiguous(request))
      return NULL;
   const char *op = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "operation"));
   if (!op)
      return NULL;
   if (!strcmp(op, "publish"))
      return native_tooling_publish_view(session,
                                         cJSON_GetObjectItemCaseSensitive(request, "view"));
   if (!strcmp(op, "contribute"))
   {
      return native_tooling_interpret_terminal(
          session, cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "pin_id")),
          cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "inference_id")),
          cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "input_sha256")),
          cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "text")),
          cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request, "finish")));
   }
   if (strcmp(op, "pin") && strcmp(op, "withdraw") && strcmp(op, "inspect") && strcmp(op, "ready"))
      return NULL;
   return native_tooling_owner_call(session, (cJSON *)request);
}
