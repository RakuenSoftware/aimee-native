#include "native_tooling_host.h"
#include "request_context.h"
#include "module_commands.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static request_context_t ctx;
static int calls, held, stale;
const request_context_t *request_context_get(void)
{
   return &ctx;
}
int ingress_preinject_acquire_send_guard(void **g)
{
   if (stale)
      return -1;
   held = 1;
   *g = &held;
   return 0;
}
void ingress_preinject_release_send_guard(void *g)
{
   assert(g == &held && held);
   held = 0;
}
int db1_native_tooling_apply(const char *principal, const char *sid, const char *raw, char *out,
                             size_t cap)
{
   assert(!strcmp(principal, "operator") && !strcmp(sid, "session"));
   calls++;
   cJSON *j = cJSON_Parse(raw);
   const char *op = cJSON_GetStringValue(cJSON_GetObjectItem(j, "operation"));
   if (!strcmp(op, "publish"))
   {
      assert(held);
      assert(!strcmp(cJSON_GetStringValue(
                         cJSON_GetObjectItem(cJSON_GetObjectItem(j, "view"), "source_release")),
                     "real-ticket"));
   }
   const char *reply =
       "{\"allowed\":true,\"current_applicable\":true,\"contribution\":{\"pin\":{\"view\":{"
       "\"source_release\":\"real-ticket\",\"task\":{\"id\":\"original-task\"}}}}}";
   snprintf(out, cap, "%s", reply);
   cJSON_Delete(j);
   return 0;
}
cJSON *aimee_module_command_call_context(uint32_t kind, uint32_t stage, const char *verb,
                                         const cJSON *args, const cJSON *caller)
{
   assert(kind == AIMEE_NATIVE_TOOLING_INTERPRET_EVENT &&
          stage == AIMEE_NATIVE_TOOLING_INTERPRET_STAGE);
   assert(cJSON_IsTrue(cJSON_GetObjectItem(caller, "authenticated")));
   if (!strcmp(verb, "poll"))
   {
      assert(strlen(cJSON_GetStringValue(cJSON_GetObjectItem(args, "job"))) == 64);
      return cJSON_Parse("{\"intake\":{\"task_id\":\"original-task\"}}");
   }
   assert(!strcmp(verb, "interpret"));
   assert(
       !strcmp(cJSON_GetStringValue(cJSON_GetObjectItem(cJSON_GetObjectItem(args, "task"), "id")),
               "original-task"));
   return cJSON_Parse("{\"status\":\"pending\",\"job\":"
                      "\"0123456789012345678901234567890123456789012345678901234567890123\"}");
}
int main(void)
{
   strcpy(ctx.principal, "operator");
   strcpy(ctx.request_id, "request");
   strcpy(ctx.memory_source_release, "real-ticket");
   cJSON *view = cJSON_Parse("{\"source_release\":\"caller-forged\"}");
   cJSON *r = native_tooling_publish_view("session", view);
   assert(r && !held && calls == 1);
   cJSON_Delete(r);
   stale = 1;
   r = native_tooling_publish_view("session", view);
   assert(!r && calls == 1);
   stale = 0;
   assert(native_tooling_action_enter("session", "pin") == 0);
   assert(!strcmp(native_tooling_current_action_pin(), "pin"));
   strcpy(ctx.request_id, "changed");
   assert(native_tooling_current_action_pin() == NULL);
   native_tooling_action_leave();
   assert(!strcmp(native_tooling_current_action_pin(), ""));
   strcpy(ctx.request_id, "request");
   r = native_tooling_interpret_terminal("session", "pin", "inference", "sha", "text", "stop");
   assert(r);
   cJSON_Delete(r);
   cJSON *forged = cJSON_Parse("{\"operation\":\"resolve\",\"intake\":{}}");
   assert(native_tooling_host_command("session", forged) == NULL);
   cJSON_Delete(forged);
   const char *candidate_pin = NULL;
   const char *invalid_requests[] = {"{\"native_pin\":false}", "{\"Native_Pin\":\"pin\"}",
                                     "{\"native_pin\":null}", "{\"native_pin\":\"\"}",
                                     "{\"native_pin\":\"pin\",\"native_pin\":\"other\"}"};
   for (size_t i = 0; i < sizeof(invalid_requests) / sizeof(invalid_requests[0]); i++)
   {
      cJSON *bad = cJSON_Parse(invalid_requests[i]);
      assert(native_tooling_pin_argument(bad, &candidate_pin) != 0);
      cJSON_Delete(bad);
   }
   cJSON *literal = cJSON_Parse("{\"body\":\"{\\\"path\\\":1,\\\"path\\\":2}\"}");
   assert(native_tooling_json_unambiguous(literal));
   cJSON_Delete(literal);
   literal = cJSON_Parse("{}");
   assert(native_tooling_pin_argument(literal, &candidate_pin) == 0 && candidate_pin == NULL);
   cJSON_Delete(literal);
   cJSON *ambiguous =
       cJSON_Parse("{\"operation\":\"inspect\",\"Operation\":\"resolve\",\"intake\":{}}");
   assert(native_tooling_host_command("session", ambiguous) == NULL);
   cJSON_Delete(ambiguous);
   ambiguous = cJSON_Parse("{\"path\":\"escape\",\"path\":\"fixed\"}");
   assert(!native_tooling_json_unambiguous(ambiguous));
   cJSON_Delete(ambiguous);
   ambiguous = cJSON_Parse("{\"arguments\":{\"path\":\"escape\",\"PATH\":\"fixed\"}}");
   assert(!native_tooling_json_unambiguous(ambiguous));
   cJSON_Delete(ambiguous);
   ctx.context_refused = 1;
   r = native_tooling_publish_view("session", view);
   assert(!r && !held);
   cJSON_Delete(view);
   puts(
       "native owner host transport: original task, guarded publication, scope change refusal: ok");
   return 0;
}
