package process

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"time"

	"github.com/JBailes/aimee/server-go/bus"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
)

// Request-only identity and EGR1 wire belong to the declared egress contract.
// Serving as Aimee never grants direct network access or egress calling rights.
const nativeEgressPrincipalRef uint32 = 76

func nativeInterpretationTransport(ctx context.Context, socket string) nt.HTTPTransport {
	if ctx == nil || socket == "" || os.Getenv("AIMEE_NATIVE_TOOLING_RESOLVER_ENDPOINT") == "" ||
		os.Getenv("AIMEE_NATIVE_TOOLING_RESOLVER_TOKEN") != "" {
		return nil // Plaintext credential forwarding is deliberately unsupported.
	}
	client, err := bus.ConnectClient(ctx, socket, 1, nativeEgressPrincipalRef)
	if err != nil {
		return nil
	}
	caller, err := bus.NewConcurrentModuleCaller(ctx, client)
	if err != nil {
		client.Detach()
		return nil
	}
	go func() {
		<-ctx.Done()
		caller.CloseAndWait()
		client.Detach()
	}()
	return NativeInterpretationTransport(caller)
}

// NativeInterpretationTransport exchanges only the declared egress wire. Its
// caller must carry the separately provisioned request identity; this constructor
// grants no authority and opens no socket itself.
func NativeInterpretationTransport(caller interface {
	Call(context.Context, uint32, uint32, uint64, time.Duration, []byte) ([]byte, error)
}) nt.HTTPTransport {
	if caller == nil {
		return nil
	}
	return func(callCtx context.Context, endpoint string, payload []byte) (int, []byte, error) {
		// Same request-identity grammar as the network owner's public contract:
		// method NUL target NUL body followed by credential-presence byte.
		digest := sha256.New()
		digest.Write([]byte("POST\x00" + endpoint + "\x00"))
		digest.Write(payload)
		digest.Write([]byte{0})
		request, err := json.Marshal(map[string]any{
			"target_url": endpoint, "purpose": "native-tooling-interpretation", "method": "POST",
			"request_sha256": fmt.Sprintf("%x", digest.Sum(nil)),
			"headers":        map[string]string{"Content-Type": "application/json"}, "body": payload,
			"max_response_bytes": nt.MaxContributionBytes, "timeout_ms": 120000,
		})
		if err != nil {
			return 0, nil, err
		}
		raw, err := caller.Call(callCtx, 12290, 2, 0, 122*time.Second, request)
		if err != nil {
			return 0, nil, err
		}
		return decodeNativeHTTPResponse(raw)
	}
}

func decodeNativeHTTPResponse(raw []byte) (int, []byte, error) {
	if len(raw) < 12 || binary.LittleEndian.Uint32(raw[:4]) != 0x31524745 {
		return 0, nil, errors.New("invalid native resolver egress response")
	}
	location := int(binary.LittleEndian.Uint16(raw[6:8]))
	failure := int(binary.LittleEndian.Uint16(raw[8:10]))
	offset := 12 + location + failure
	if offset > len(raw) || len(raw)-offset > nt.MaxContributionBytes {
		return 0, nil, errors.New("unbounded or truncated native resolver response")
	}
	if failure != 0 {
		return 0, nil, errors.New(string(raw[12+location : offset]))
	}
	return int(binary.LittleEndian.Uint16(raw[4:6])), raw[offset:], nil
}
