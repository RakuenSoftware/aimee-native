package process

import (
	"encoding/binary"
	"testing"

	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
)

func TestNativeEgressFrameIsBoundedAndNeverHidesFailure(t *testing.T) {
	frame := make([]byte, 12)
	binary.LittleEndian.PutUint32(frame, 0x31524745)
	binary.LittleEndian.PutUint16(frame[4:], 200)
	if status, body, err := decodeNativeHTTPResponse(append(frame, []byte("reply")...)); err != nil || status != 200 || string(body) != "reply" {
		t.Fatal(status, string(body), err)
	}
	if _, _, err := decodeNativeHTTPResponse(append(frame, make([]byte, nt.MaxContributionBytes+1)...)); err == nil {
		t.Fatal("oversized owner response accepted")
	}
	binary.LittleEndian.PutUint16(frame[8:], 6)
	if _, _, err := decodeNativeHTTPResponse(append(frame, []byte("denied")...)); err == nil {
		t.Fatal("egress refusal hidden")
	}
	if _, _, err := decodeNativeHTTPResponse(frame); err == nil {
		t.Fatal("truncated frame accepted")
	}
}
