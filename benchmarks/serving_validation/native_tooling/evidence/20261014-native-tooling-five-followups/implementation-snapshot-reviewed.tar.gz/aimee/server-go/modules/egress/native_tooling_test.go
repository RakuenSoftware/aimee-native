package egress

import (
	"net/url"
	"testing"
)

func TestNativeInterpretationEgressHasOneConfiguredDestination(t *testing.T) {
	t.Setenv("AIMEE_NATIVE_TOOLING_RESOLVER_ENDPOINT", "http://127.0.0.1:8437/v1/chat/completions")
	u, _ := url.Parse("http://127.0.0.1:8437/v1/chat/completions")
	r := Request{Purpose: "native-tooling-interpretation", Method: "POST"}
	if !callerPurposeAllowed(NativeToolingClientRef, r, u) {
		t.Fatal("configured native interpretation endpoint refused")
	}
	for _, ref := range []uint32{30, ProvidersClientRef, MemoryClientRef} {
		if callerPurposeAllowed(ref, r, u) {
			t.Fatal("other principal inherited native purpose", ref)
		}
	}
	for _, target := range []string{"http://127.0.0.1:8438/v1/chat/completions", "http://127.0.0.1:8437/v1/models", "https://example.com/v1/chat/completions"} {
		other, _ := url.Parse(target)
		if callerPurposeAllowed(NativeToolingClientRef, r, other) {
			t.Fatal("unconfigured endpoint accepted", target)
		}
	}
	r.CredentialPresent = true
	if callerPurposeAllowed(NativeToolingClientRef, r, u) {
		t.Fatal("undeclared credential accepted")
	}
}
