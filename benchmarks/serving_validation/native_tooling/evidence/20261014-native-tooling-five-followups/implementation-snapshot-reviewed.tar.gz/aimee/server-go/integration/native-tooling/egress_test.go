package nativetoolingintegration

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/JBailes/aimee/server-go/bus"
	nt "github.com/JBailes/aimee/server-go/modules/aimee/nativetooling"
	"github.com/JBailes/aimee/server-go/modules/aimee/process"
	"github.com/JBailes/aimee/server-go/modules/egress"
)

// The bus caller is a fixture, not proof of enrolled process identity. The
// production encoder, network-owner policy/HTTP transport and decoder are real.
type fixtureEgressCaller struct{ handler bus.ModuleHandler }

func (c fixtureEgressCaller) Call(ctx context.Context, event, stage uint32, trace uint64, timeout time.Duration, raw []byte) ([]byte, error) {
	if event != egress.EventHTTP || stage != egress.StageHTTP {
		return nil, fmt.Errorf("wrong egress stage")
	}
	var request egress.HTTPRequest
	if err := json.Unmarshal(raw, &request); err != nil {
		return nil, err
	}
	if request.RequestSHA256 != egress.RequestDigest(request.Method, request.TargetURL, request.Body, false) {
		return nil, fmt.Errorf("request identity differs from egress contract")
	}
	reply, status := c.handler(bus.ModuleInvocation{PrincipalClass: 1, PrincipalRef: egress.NativeToolingClientRef, StageID: stage}, raw)
	if status != bus.ModuleStatusOK {
		return nil, fmt.Errorf("egress refused: %d", status)
	}
	return reply, nil
}

func TestNativeOwnerGovernedEgressInteroperability(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" || r.Header.Get("Authorization") != "" {
			t.Error("unbound request or credential")
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"finish_reason": "stop", "message": map[string]any{"content": `{"kind":"content","capability_id":"record","quotes":{"body":"held delivery"},"reason":"explicit proposed body"}`}}}})
	}))
	defer server.Close()
	t.Setenv("AIMEE_NATIVE_TOOLING_RESOLVER_ENDPOINT", server.URL)
	resolver := &nt.HTTPResolver{Endpoint: server.URL, Model: "fixture-stock-model", Transport: process.NativeInterpretationTransport(fixtureEgressCaller{egress.NewHandler()})}
	task := nt.Task{ID: "egress-wire", Purpose: "record proposed body", Capabilities: []nt.Capability{{ID: "record", Purpose: "authored body", Fields: map[string]nt.Field{"body": {Kind: "text", Required: true}}}}}
	intake, err := nt.Interpret(context.Background(), resolver, task, "Proposed body: held delivery")
	if err != nil || intake.Decision.Kind != "content" || intake.Decision.Quotes["body"] != "held delivery" {
		t.Fatal(intake, err)
	}
	resolver.Endpoint += "/unconfigured"
	if _, err = nt.Interpret(context.Background(), resolver, task, "Proposed body: held delivery"); err == nil {
		t.Fatal("owner used an unconfigured destination")
	}
}
