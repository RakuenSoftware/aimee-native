package nativetooling

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func task() Task {
	return Task{ID: "task-a", Purpose: "prepare a proposed body", Capabilities: []Capability{{ID: "record-body", Purpose: "record a literal proposed body", Fields: map[string]Field{"body": {Kind: "text", Required: true}}}}}
}
func TestIntakePreservesUsefulContentAndUnsupportedClaim(t *testing.T) {
	text := "Proposed body: Café holds delivery. Already sent and approved."
	d := Decision{Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "Café holds delivery."}, UnsupportedClaims: []string{"Already sent and approved."}, Reason: "explicit draft; claim unsupported"}
	r, e := Validate(task(), text, d)
	if e != nil || r.Authority != "untrusted_proposed_content" || r.Original != text || text[r.Spans[0].Start:r.Spans[0].End] != d.Quotes["body"] {
		t.Fatal(r, e)
	}
}
func TestIntakeRejectsInventedAmbiguousOrUnboundContent(t *testing.T) {
	for _, d := range []Decision{{Kind: "content", CapabilityID: "unknown", Reason: "bad"}, {Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "invented"}, Reason: "bad"}, {Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "repeat"}, Reason: "bad"}, {Kind: "refusal", CapabilityID: "record-body", Reason: "bad"}, {Kind: "content", CapabilityID: "record-body", Quotes: map[string]string{"body": "repeat", "path": "/etc"}, Reason: "bad"}} {
		if _, e := Validate(task(), "repeat repeat", d); e == nil {
			t.Fatal(d)
		}
	}
}
func TestResolverJSONRejectsDuplicateUnknownAndTrailing(t *testing.T) {
	for _, s := range []string{`{"kind":"none","kind":"content","reason":"x"}`, `{"kind":"none","reason":"x","authoritative":true}`, `{"kind":"none","reason":"x"} {}`, `null`, `{"quotes":{"body":"a","body":"b"}}`} {
		if _, e := DecodeDecision([]byte(s)); e == nil {
			t.Fatal(s)
		}
	}
}
func TestHTTPResolverIsAutomaticButExtractive(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var body map[string]any
		if json.NewDecoder(r.Body).Decode(&body) != nil || body["model"] != "stock-resolver" {
			t.Fatal(body)
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"finish_reason": "stop", "message": map[string]any{"content": `{"kind":"content","capability_id":"record-body","quotes":{"body":"held delivery"},"reason":"explicit"}`}}}})
	}))
	defer server.Close()
	r := &HTTPResolver{Endpoint: server.URL, Model: "stock-resolver", Transport: func(ctx context.Context, endpoint string, payload []byte) (int, []byte, error) {
		request, err := http.NewRequestWithContext(ctx, "POST", endpoint, bytes.NewReader(payload))
		if err != nil {
			return 0, nil, err
		}
		response, err := server.Client().Do(request)
		if err != nil {
			return 0, nil, err
		}
		defer response.Body.Close()
		raw, err := io.ReadAll(io.LimitReader(response.Body, MaxContributionBytes+1))
		return response.StatusCode, raw, err
	}}
	out, e := Interpret(context.Background(), r, task(), "The body is held delivery")
	if e != nil || out.Decision.Kind != "content" {
		t.Fatal(out, e)
	}
}
