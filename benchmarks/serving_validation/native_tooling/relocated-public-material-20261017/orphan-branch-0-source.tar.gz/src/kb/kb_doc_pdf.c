/* kb_doc_pdf.c: structured-PDF ingestion Phase 1 (first increment). See kb_doc_pdf.h.
 * Pure pipeline over `pdftotext -bbox-layout` XHTML: parse -> normalize -> chunk ->
 * ingest into kb_documents + kb_doc_regions. No subprocess here (the exec wrapper + the
 * upload-route wiring are the next increment); this is exercised by its unit tests only. */
#include "kb_doc_pdf.h"

#include "cJSON.h"
#include "config.h"
#include "db2/kb_payload.h"
#include "db2/pgvec_transport.h"
#include "kb_blob_store.h"
#include "kb_doc_hash.h"
#include "kb_ocr_sidecar.h"
#include "kb_tsr_sidecar.h"
#include "log.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/* Guardrail caps so a pathological document cannot exhaust memory. Parsing stops once
 * hit (partial extraction, logged) rather than erroring. */
#define KB_PDF_MAX_PAGES 20000
#define KB_PDF_MAX_LINES 500000
/* Phase C: cap page crops per document (a runaway page count cannot fill the blob store). */
#define KB_PDF_RENDER_MAX_PAGES 200

/* ---- small XML scanning helpers (poppler's bbox output is regular, not arbitrary XML) ---- */

/* Parse the value of attribute `name` (e.g. "width") found within [s, e) as a double.
 * Returns 1 and writes *out on success, 0 if the attribute is absent/malformed. */
static int attr_double(const char *s, const char *e, const char *name, double *out)
{
   size_t nlen = strlen(name);
   for (const char *p = s; p && p + nlen + 2 < e; p++)
   {
      /* match `name="` with a preceding space/'<' so "xMin" doesn't match inside a word */
      if ((p == s || isspace((unsigned char)p[-1])) && strncmp(p, name, nlen) == 0 &&
          p[nlen] == '=' && p[nlen + 1] == '"')
      {
         const char *v = p + nlen + 2;
         char *endp = NULL;
         double d = strtod(v, &endp);
         if (endp && endp > v)
         {
            *out = d;
            return 1;
         }
         return 0;
      }
   }
   return 0;
}

/* Append decoded text content of an XML range [s,e) (a <word>'s inner text) to `dst`
 * (a growable buffer). Decodes the handful of entities poppler emits. */
static void append_decoded(char **dst, size_t *len, size_t *cap, const char *s, const char *e)
{
   for (const char *p = s; p < e;)
   {
      char ch;
      size_t adv = 1;
      if (*p == '&')
      {
         if (e - p >= 5 && strncmp(p, "&amp;", 5) == 0)
         {
            ch = '&';
            adv = 5;
         }
         else if (e - p >= 4 && strncmp(p, "&lt;", 4) == 0)
         {
            ch = '<';
            adv = 4;
         }
         else if (e - p >= 4 && strncmp(p, "&gt;", 4) == 0)
         {
            ch = '>';
            adv = 4;
         }
         else if (e - p >= 6 && strncmp(p, "&quot;", 6) == 0)
         {
            ch = '"';
            adv = 6;
         }
         else if (e - p >= 6 && strncmp(p, "&apos;", 6) == 0)
         {
            ch = '\'';
            adv = 6;
         }
         else if (e - p >= 5 && strncmp(p, "&#39;", 5) == 0)
         {
            ch = '\'';
            adv = 5;
         }
         else if (e - p >= 5 && strncmp(p, "&#34;", 5) == 0)
         {
            ch = '"';
            adv = 5;
         }
         else
         {
            ch = '&';
            adv = 1;
         }
      }
      else
      {
         ch = *p;
      }
      if (*len + 2 > *cap)
      {
         size_t ncap = *cap ? *cap * 2 : 64;
         char *nb = realloc(*dst, ncap);
         if (!nb)
            return;
         *dst = nb;
         *cap = ncap;
      }
      (*dst)[(*len)++] = ch;
      p += adv;
   }
   if (*dst)
      (*dst)[*len] = '\0';
}

static int page_add_line(kb_pdf_page_t *pg, int page_no, double x0, double y0, double x1, double y1,
                         char *text)
{
   if (pg->n_lines >= pg->cap_lines)
   {
      int ncap = pg->cap_lines ? pg->cap_lines * 2 : 16;
      kb_pdf_line_t *nl = realloc(pg->lines, (size_t)ncap * sizeof(*nl));
      if (!nl)
         return -1;
      pg->lines = nl;
      pg->cap_lines = ncap;
   }
   kb_pdf_line_t *ln = &pg->lines[pg->n_lines++];
   ln->page_no = page_no;
   ln->x0 = x0;
   ln->y0 = y0;
   ln->x1 = x1;
   ln->y1 = y1;
   ln->text = text;
   return 0;
}

/* Collect the words of a <line> (or a bare <word> run) bounded by [s,e) into one text
 * string (space-joined). Returns a malloc'd string (possibly empty), or NULL on OOM. */
static char *collect_words(const char *s, const char *e)
{
   char *buf = NULL;
   size_t len = 0, cap = 0;
   const char *p = s;
   int first = 1;
   while (p < e)
   {
      const char *w = strstr(p, "<word");
      if (!w || w >= e)
         break;
      const char *gt = memchr(w, '>', (size_t)(e - w));
      if (!gt)
         break;
      const char *close = strstr(gt + 1, "</word>");
      if (!close || close > e)
         break;
      if (!first)
      {
         /* word separator */
         if (len + 2 > cap)
         {
            size_t ncap = cap ? cap * 2 : 64;
            char *nb = realloc(buf, ncap);
            if (!nb)
            {
               free(buf);
               return NULL;
            }
            buf = nb;
            cap = ncap;
         }
         buf[len++] = ' ';
      }
      first = 0;
      append_decoded(&buf, &len, &cap, gt + 1, close);
      p = close + 7; /* strlen("</word>") */
   }
   if (!buf)
   {
      buf = malloc(1);
      if (buf)
         buf[0] = '\0';
   }
   return buf;
}

int kb_pdf_parse_bbox_layout(const char *xhtml, kb_pdf_doc_t *out)
{
   if (!out)
      return -1;
   memset(out, 0, sizeof(*out));
   if (!xhtml)
      return 0;

   int total_lines = 0;
   const char *p = xhtml;
   while (1)
   {
      const char *pg_open = strstr(p, "<page");
      if (!pg_open)
         break;
      const char *pg_tag_end = strchr(pg_open, '>');
      if (!pg_tag_end)
         break;
      const char *pg_close = strstr(pg_tag_end, "</page>");
      const char *pg_body_end = pg_close ? pg_close : (xhtml + strlen(xhtml));

      if (out->n_pages >= KB_PDF_MAX_PAGES)
      {
         LOG_WARN("kb_doc_pdf", "page cap (%d) reached; truncating extraction", KB_PDF_MAX_PAGES);
         break;
      }
      if (out->n_pages >= out->cap_pages)
      {
         int ncap = out->cap_pages ? out->cap_pages * 2 : 8;
         kb_pdf_page_t *np = realloc(out->pages, (size_t)ncap * sizeof(*np));
         if (!np)
         {
            kb_pdf_free_doc(out); /* free the partial doc; out left empty/safe */
            return -1;
         }
         out->pages = np;
         out->cap_pages = ncap;
      }
      kb_pdf_page_t *pg = &out->pages[out->n_pages];
      memset(pg, 0, sizeof(*pg));
      int page_no = out->n_pages + 1;
      out->n_pages++;

      if (!attr_double(pg_open, pg_tag_end, "width", &pg->width))
         pg->width = 0;
      if (!attr_double(pg_open, pg_tag_end, "height", &pg->height))
         pg->height = 0;

      /* Lines within the page. */
      const char *lp = pg_tag_end;
      int saw_line = 0;
      while (lp < pg_body_end)
      {
         const char *ln_open = strstr(lp, "<line");
         if (!ln_open || ln_open >= pg_body_end)
            break;
         const char *ln_tag_end = strchr(ln_open, '>');
         if (!ln_tag_end || ln_tag_end >= pg_body_end)
            break;
         const char *ln_close = strstr(ln_tag_end, "</line>");
         const char *ln_body_end = (ln_close && ln_close < pg_body_end) ? ln_close : pg_body_end;
         saw_line = 1;

         double x0 = 0, y0 = 0, x1 = 0, y1 = 0;
         attr_double(ln_open, ln_tag_end, "xMin", &x0);
         attr_double(ln_open, ln_tag_end, "yMin", &y0);
         attr_double(ln_open, ln_tag_end, "xMax", &x1);
         attr_double(ln_open, ln_tag_end, "yMax", &y1);

         char *text = collect_words(ln_tag_end + 1, ln_body_end);
         if (text && text[0] && total_lines < KB_PDF_MAX_LINES)
         {
            if (page_add_line(pg, page_no, x0, y0, x1, y1, text) != 0)
            {
               free(text);
               kb_pdf_free_doc(out);
               return -1;
            }
            total_lines++;
         }
         else
         {
            free(text);
         }
         lp = ln_close ? ln_close + 7 : pg_body_end;
      }

      /* Degraded structure (no <line> wrappers): treat each <word> as its own line so
       * no text is lost. */
      if (!saw_line)
      {
         const char *wp = pg_tag_end;
         while (wp < pg_body_end && total_lines < KB_PDF_MAX_LINES)
         {
            const char *w = strstr(wp, "<word");
            if (!w || w >= pg_body_end)
               break;
            const char *gt = memchr(w, '>', (size_t)(pg_body_end - w));
            if (!gt)
               break;
            const char *close = strstr(gt + 1, "</word>");
            if (!close || close > pg_body_end)
               break;
            double x0 = 0, y0 = 0, x1 = 0, y1 = 0;
            attr_double(w, gt, "xMin", &x0);
            attr_double(w, gt, "yMin", &y0);
            attr_double(w, gt, "xMax", &x1);
            attr_double(w, gt, "yMax", &y1);
            char *text = NULL;
            size_t tl = 0, tc = 0;
            append_decoded(&text, &tl, &tc, gt + 1, close);
            if (text && text[0])
            {
               if (page_add_line(pg, page_no, x0, y0, x1, y1, text) != 0)
               {
                  free(text);
                  kb_pdf_free_doc(out);
                  return -1;
               }
               total_lines++;
            }
            else
            {
               free(text);
            }
            wp = close + 7;
         }
      }

      if (!pg_close)
         break;
      p = pg_close + 7; /* strlen("</page>") */
   }
   return 0;
}

static double clamp01(double v)
{
   if (v < 0)
      return 0;
   if (v > 1)
      return 1;
   return v;
}

void kb_pdf_normalize(kb_pdf_doc_t *doc)
{
   if (!doc || doc->normalized)
      return;
   for (int i = 0; i < doc->n_pages; i++)
   {
      kb_pdf_page_t *pg = &doc->pages[i];
      double w = pg->width, h = pg->height;
      for (int j = 0; j < pg->n_lines; j++)
      {
         kb_pdf_line_t *ln = &pg->lines[j];
         if (w > 0 && h > 0)
         {
            ln->x0 = clamp01(ln->x0 / w);
            ln->y0 = clamp01(ln->y0 / h);
            ln->x1 = clamp01(ln->x1 / w);
            ln->y1 = clamp01(ln->y1 / h);
         }
         else
         {
            ln->x0 = ln->y0 = ln->x1 = ln->y1 = 0;
         }
      }
   }
   doc->normalized = 1;
}

static int count_tokens(const char *s)
{
   int n = 0, in = 0;
   for (; s && *s; s++)
   {
      if (isspace((unsigned char)*s))
         in = 0;
      else if (!in)
      {
         in = 1;
         n++;
      }
   }
   return n;
}

/* Finalize one accumulated chunk: join its line texts with '\n' into content. */
static int finalize_chunk(kb_pdf_chunk_t *c)
{
   size_t total = 1;
   for (int i = 0; i < c->n_lines; i++)
      total += strlen(c->lines[i]->text) + 1;
   c->content = malloc(total);
   if (!c->content)
      return -1;
   size_t off = 0;
   for (int i = 0; i < c->n_lines; i++)
   {
      if (i)
         c->content[off++] = '\n';
      size_t l = strlen(c->lines[i]->text);
      memcpy(c->content + off, c->lines[i]->text, l);
      off += l;
   }
   c->content[off] = '\0';
   c->token_count = count_tokens(c->content);
   return 0;
}

int kb_pdf_chunk(const kb_pdf_doc_t *doc, kb_pdf_chunk_t **chunks_out, int *n_chunks_out)
{
   if (!doc || !chunks_out || !n_chunks_out)
      return -1;
   *chunks_out = NULL;
   *n_chunks_out = 0;

   kb_pdf_chunk_t *chunks = NULL;
   int n = 0, cap = 0;
   kb_pdf_chunk_t cur;
   memset(&cur, 0, sizeof(cur));
   int have_cur = 0;
   int global_idx = 0; /* 0-based ordinal across the whole doc */
   int cur_page = -1;

   for (int pi = 0; pi < doc->n_pages; pi++)
   {
      const kb_pdf_page_t *pg = &doc->pages[pi];
      for (int li = 0; li < pg->n_lines; li++)
      {
         const kb_pdf_line_t *ln = &pg->lines[li];
         /* Break on page change or line cap. */
         if (have_cur && (ln->page_no != cur_page || cur.n_lines >= KB_PDF_MAX_CHUNK_LINES))
         {
            if (finalize_chunk(&cur) != 0)
               goto oom;
            if (n >= cap)
            {
               int ncap = cap ? cap * 2 : 8;
               kb_pdf_chunk_t *nc = realloc(chunks, (size_t)ncap * sizeof(*nc));
               if (!nc)
                  goto oom;
               chunks = nc;
               cap = ncap;
            }
            chunks[n++] = cur;
            memset(&cur, 0, sizeof(cur));
            have_cur = 0;
         }
         if (!have_cur)
         {
            have_cur = 1;
            cur_page = ln->page_no;
            cur.line_start = global_idx;
            cur.page_start = ln->page_no;
            cur.page_end = ln->page_no;
         }
         /* append line pointer */
         {
            const kb_pdf_line_t **nl =
                realloc((void *)cur.lines, (size_t)(cur.n_lines + 1) * sizeof(*cur.lines));
            if (!nl)
               goto oom;
            cur.lines = nl;
            cur.lines[cur.n_lines++] = ln;
         }
         cur.line_end = global_idx;
         if (ln->page_no < cur.page_start)
            cur.page_start = ln->page_no;
         if (ln->page_no > cur.page_end)
            cur.page_end = ln->page_no;
         global_idx++;
      }
   }
   if (have_cur)
   {
      if (finalize_chunk(&cur) != 0)
         goto oom;
      if (n >= cap)
      {
         int ncap = cap ? cap * 2 : 8;
         kb_pdf_chunk_t *nc = realloc(chunks, (size_t)ncap * sizeof(*nc));
         if (!nc)
            goto oom;
         chunks = nc;
         cap = ncap;
      }
      chunks[n++] = cur;
      memset(&cur, 0, sizeof(cur));
   }

   *chunks_out = chunks;
   *n_chunks_out = n;
   return n;

oom:
   free(cur.content);
   free((void *)cur.lines);
   kb_pdf_free_chunks(chunks, n);
   return -1;
}

void kb_pdf_free_chunks(kb_pdf_chunk_t *chunks, int n_chunks)
{
   if (!chunks)
      return;
   for (int i = 0; i < n_chunks; i++)
   {
      free(chunks[i].content);
      free((void *)chunks[i].lines);
   }
   free(chunks);
}

void kb_pdf_free_doc(kb_pdf_doc_t *doc)
{
   if (!doc)
      return;
   for (int i = 0; i < doc->n_pages; i++)
   {
      for (int j = 0; j < doc->pages[i].n_lines; j++)
         free(doc->pages[i].lines[j].text);
      free(doc->pages[i].lines);
   }
   free(doc->pages);
   memset(doc, 0, sizeof(*doc));
}

/* Child resource caps (defense-in-depth against a crafted PDF that makes pdftotext spin or
 * balloon). The wall-clock deadline below is the primary bound; these are belt-and-braces. */
#define KB_PDF_CHILD_CPU_SECS    30
#define KB_PDF_CHILD_AS_BYTES    (1024UL * 1024UL * 1024UL) /* 1 GiB address space */
#define KB_PDF_CHILD_FSIZE_BYTES (256UL * 1024UL * 1024UL)

static long ms_since(const struct timespec *start)
{
   struct timespec now;
   clock_gettime(CLOCK_MONOTONIC, &now);
   return (now.tv_sec - start->tv_sec) * 1000L + (now.tv_nsec - start->tv_nsec) / 1000000L;
}

int kb_pdf_exec_bbox_layout(const unsigned char *bytes, int n, char *out, int out_cap,
                            int timeout_ms)
{
   if (!bytes || n <= 0 || !out || out_cap <= 1)
      return -1;
   out[0] = '\0';

   char tmppath[] = "/tmp/aimee_pdf_XXXXXX";
   int tfd = mkstemp(tmppath);
   if (tfd < 0)
   {
      LOG_WARN("kb_doc_pdf", "mkstemp failed for pdftotext input");
      return -1;
   }
   (void)fchmod(tfd, 0600);
   int rc = -1;
   {
      int off = 0;
      while (off < n)
      {
         ssize_t w = write(tfd, bytes + off, (size_t)(n - off));
         if (w < 0)
         {
            if (errno == EINTR)
               continue; /* retry — a signal must not corrupt valid input */
            break;
         }
         if (w == 0)
            break;
         off += (int)w;
      }
      close(tfd);
      if (off != n)
      {
         unlink(tmppath);
         return -1;
      }
   }

   int pfd[2];
   if (pipe(pfd) != 0)
   {
      unlink(tmppath);
      return -1;
   }

   pid_t pid = fork();
   if (pid < 0)
   {
      close(pfd[0]);
      close(pfd[1]);
      unlink(tmppath);
      return -1;
   }
   if (pid == 0)
   {
      /* child */
      setsid(); /* own session/group: isolates it from the server's signals and lets the
                 * parent kill the whole group (defense-in-depth if pdftotext ever forks) */
      close(pfd[0]);
      dup2(pfd[1], STDOUT_FILENO);
      close(pfd[1]);
      int devnull = open("/dev/null", O_WRONLY);
      if (devnull >= 0)
      {
         dup2(devnull, STDERR_FILENO);
         close(devnull);
      }
      struct rlimit rl;
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_CPU_SECS;
      setrlimit(RLIMIT_CPU, &rl);
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_AS_BYTES;
      setrlimit(RLIMIT_AS, &rl);
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_FSIZE_BYTES;
      setrlimit(RLIMIT_FSIZE, &rl);
      execlp("pdftotext", "pdftotext", "-bbox-layout", tmppath, "-", (char *)NULL);
      _exit(127);
   }

   /* parent */
   close(pfd[1]);
   fcntl(pfd[0], F_SETFL, O_NONBLOCK);

   struct timespec start;
   clock_gettime(CLOCK_MONOTONIC, &start);
   int total = 0, timed_out = 0, over_cap = 0;
   for (;;)
   {
      long elapsed = ms_since(&start);
      long remaining = (long)timeout_ms - elapsed;
      if (remaining <= 0)
      {
         timed_out = 1;
         break;
      }
      struct pollfd p = {pfd[0], POLLIN, 0};
      int pr = poll(&p, 1, (int)remaining);
      if (pr == 0)
      {
         timed_out = 1;
         break;
      }
      if (pr < 0)
      {
         if (errno == EINTR)
            continue;
         break;
      }
      ssize_t r = read(pfd[0], out + total, (size_t)(out_cap - 1 - total));
      if (r == 0)
         break; /* EOF — child closed stdout */
      if (r < 0)
      {
         if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
            continue;
         break;
      }
      total += (int)r;
      if (total >= out_cap - 1)
      {
         over_cap = 1;
         break;
      }
   }
   out[total < 0 ? 0 : total] = '\0';
   close(pfd[0]);

   if (timed_out || over_cap)
   {
      kill(pid, SIGKILL);  /* the child directly … */
      kill(-pid, SIGKILL); /* … and its process group (post-setsid; ESRCH no-op otherwise) */
   }

   /* Bounded reap: poll waitpid until a short grace deadline, then SIGKILL + block. */
   int status = 0, reaped = 0;
   struct timespec reap_start;
   clock_gettime(CLOCK_MONOTONIC, &reap_start);
   for (;;)
   {
      pid_t w = waitpid(pid, &status, WNOHANG);
      if (w == pid)
      {
         reaped = 1;
         break;
      }
      if (w < 0 && errno != EINTR)
         break;
      if (ms_since(&reap_start) > 2000)
      {
         kill(pid, SIGKILL);
         kill(-pid, SIGKILL);
         /* blocking reap, EINTR-safe — never leave a zombie */
         while (waitpid(pid, &status, 0) < 0 && errno == EINTR)
            ;
         reaped = 1;
         break;
      }
      struct timespec ts = {0, 5 * 1000 * 1000}; /* 5ms */
      nanosleep(&ts, NULL);
   }

   unlink(tmppath);

   if (timed_out)
      LOG_WARN("kb_doc_pdf", "pdftotext timed out after %dms", timeout_ms);
   else if (over_cap)
      LOG_WARN("kb_doc_pdf", "pdftotext output exceeded %d-byte cap", out_cap);
   else if (reaped && WIFEXITED(status) && WEXITSTATUS(status) == 0)
      rc = 0;
   else
      LOG_WARN("kb_doc_pdf", "pdftotext failed (exit status %d)", status);

   return rc;
}

int kb_pdf_sensitivity_valid(const char *s)
{
   return s &&
          (strcmp(s, "public") == 0 || strcmp(s, "internal") == 0 || strcmp(s, "restricted") == 0);
}

/* Remove the per-render private scratch: the input PDF, pdftoppm's output PNG, and the 0700
 * directory itself. Best-effort + idempotent (a missing file/dir is fine). */
static void render_dir_cleanup(const char *inpath, const char *outpng, const char *dir)
{
   unlink(inpath);
   unlink(outpng);
   rmdir(dir);
}

/* Phase C: render one PDF page to a PNG via pdftoppm, over the SAME hardened-exec harness as
 * pdftotext — pdftoppm is a DIFFERENT untrusted byte-consuming parser (it decodes the page's
 * images), so it gets its own scratch + the same RLIMIT_CPU/AS/FSIZE (RLIMIT_AS bounds in-
 * memory image decompression before output is written), wall-clock deadline, setsid +
 * process-group kill, and 0600 mkstemp scratch unlinked on every exit. On success *png_out/
 * *png_len receive a heap buffer (caller frees). Returns 0 on success, -1 on error/absent
 * binary/timeout, 1 if the page does not exist (pdftoppm produced no file). */
static int kb_pdf_exec_render(const unsigned char *bytes, int n, int page_no,
                              unsigned char **png_out, int *png_len, int timeout_ms)
{
   if (png_out)
      *png_out = NULL;
   if (png_len)
      *png_len = 0;
   if (!bytes || n <= 0 || page_no < 1 || !png_out || !png_len)
      return -1;

   /* Render inside a PRIVATE 0700 directory (mkdtemp), not bare /tmp files: pdftoppm creates
    * <outbase>.png itself, and a 0700 dir we own closes the /tmp symlink/TOCTOU race where an
    * attacker could pre-create that path to redirect the output or inject bytes. Both the input
    * and the output live in this dir; render_dir_cleanup() removes them + the dir on EVERY exit
    * path below. */
   char scratch[] = "/tmp/aimee_pdf_render_XXXXXX";
   if (!mkdtemp(scratch))
      return -1;
   char inpath[sizeof(scratch) + 8], outbase[sizeof(scratch) + 8], outpng[sizeof(scratch) + 12];
   snprintf(inpath, sizeof(inpath), "%s/in.pdf", scratch);
   snprintf(outbase, sizeof(outbase), "%s/page", scratch);
   snprintf(outpng, sizeof(outpng), "%s/page.png", scratch);

   int ifd = open(inpath, O_WRONLY | O_CREAT | O_EXCL, 0600);
   if (ifd < 0)
   {
      rmdir(scratch);
      return -1;
   }
   {
      size_t off = 0;
      int ok = 1;
      while (off < (size_t)n)
      {
         ssize_t w = write(ifd, bytes + off, (size_t)n - off);
         if (w < 0)
         {
            if (errno == EINTR)
               continue;
            ok = 0;
            break;
         }
         off += (size_t)w;
      }
      close(ifd);
      if (!ok)
      {
         render_dir_cleanup(inpath, outpng, scratch);
         return -1;
      }
   }

   char page_arg[16];
   snprintf(page_arg, sizeof(page_arg), "%d", page_no);

   pid_t pid = fork();
   if (pid < 0)
   {
      render_dir_cleanup(inpath, outpng, scratch);
      return -1;
   }
   if (pid == 0)
   {
      setsid();
      int devnull = open("/dev/null", O_WRONLY);
      if (devnull >= 0)
      {
         dup2(devnull, STDOUT_FILENO);
         dup2(devnull, STDERR_FILENO);
         close(devnull);
      }
      struct rlimit rl;
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_CPU_SECS;
      setrlimit(RLIMIT_CPU, &rl);
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_AS_BYTES;
      setrlimit(RLIMIT_AS, &rl);
      rl.rlim_cur = rl.rlim_max = KB_PDF_CHILD_FSIZE_BYTES;
      setrlimit(RLIMIT_FSIZE, &rl);
      execlp("pdftoppm", "pdftoppm", "-png", "-r", "100", "-f", page_arg, "-l", page_arg,
             "-singlefile", inpath, outbase, (char *)NULL);
      _exit(127);
   }

   struct timespec start;
   clock_gettime(CLOCK_MONOTONIC, &start);
   int status = 0, timed_out = 0, reaped = 0;
   for (;;)
   {
      pid_t w = waitpid(pid, &status, WNOHANG);
      if (w == pid)
      {
         reaped = 1;
         break;
      }
      if (w < 0 && errno != EINTR)
      {
         /* Unexpected waitpid error (not ECHILD/EINTR): make sure the child cannot linger as a
          * zombie or a runaway — kill its group and do one best-effort blocking reap. */
         if (errno != ECHILD)
         {
            kill(pid, SIGKILL);
            kill(-pid, SIGKILL);
            while (waitpid(pid, &status, 0) < 0 && errno == EINTR)
               ;
         }
         break;
      }
      if (ms_since(&start) > timeout_ms)
      {
         kill(pid, SIGKILL);
         kill(-pid, SIGKILL);
         timed_out = 1;
         /* blocking reap to avoid a zombie */
         while (waitpid(pid, &status, 0) < 0 && errno == EINTR)
            ;
         break;
      }
      struct timespec ts = {0, 5 * 1000 * 1000};
      nanosleep(&ts, NULL);
   }

   int rc = -1;
   if (!timed_out && reaped && WIFEXITED(status) && WEXITSTATUS(status) == 0)
   {
      int rfd = open(outpng, O_RDONLY);
      if (rfd < 0)
      {
         /* exit 0 but no file → the page does not exist (past the last page). */
         rc = 1;
      }
      else
      {
         struct stat stt;
         if (fstat(rfd, &stt) == 0 && stt.st_size > 0 &&
             (unsigned long)stt.st_size <= KB_PDF_CHILD_FSIZE_BYTES)
         {
            size_t sz = (size_t)stt.st_size;
            unsigned char *buf = malloc(sz);
            if (buf)
            {
               size_t off = 0;
               int ok = 1;
               while (off < sz)
               {
                  ssize_t r = read(rfd, buf + off, sz - off);
                  if (r < 0)
                  {
                     if (errno == EINTR)
                        continue;
                     ok = 0;
                     break;
                  }
                  if (r == 0)
                     break;
                  off += (size_t)r;
               }
               if (ok && off == sz)
               {
                  *png_out = buf;
                  *png_len = (int)sz;
                  rc = 0;
               }
               else
                  free(buf);
            }
         }
         close(rfd);
      }
   }
   else if (timed_out)
      LOG_WARN("kb_doc_pdf", "pdftoppm timed out rendering page %d", page_no);
   else
      LOG_WARN("kb_doc_pdf", "pdftoppm failed for page %d (exit status %d)", page_no, status);
   render_dir_cleanup(inpath, outpng, scratch);
   return rc;
}

int kb_doc_pdf_render_assets(const char *project, const char *file_path,
                             const char *sensitivity_class, const unsigned char *pdf_bytes, int n)
{
   if (!project || !*project || !file_path || !*file_path || !pdf_bytes || n <= 0)
      return 0;
   int created = 0;
   for (int page = 1; page <= KB_PDF_RENDER_MAX_PAGES; page++)
   {
      unsigned char *png = NULL;
      int png_len = 0;
      int rc = kb_pdf_exec_render(pdf_bytes, n, page, &png, &png_len, 30000);
      if (rc == 1)
         break; /* no more pages */
      if (rc != 0 || !png)
      {
         /* render error for this page (pdftoppm absent / decode failure): best-effort, skip. */
         free(png);
         if (page == 1)
            break; /* binary absent or doc unrenderable → no assets at all */
         continue;
      }
      /* Blob is written + fsync-durable BEFORE the row is inserted, so a crash can only leave a
       * harmless orphan blob (reclaimed by reconciliation), never a row pointing at no blob. */
      char sha[KB_DOC_HASH_HEX_LEN + 1] = "";
      if (kb_blob_store_put(png, (size_t)png_len, sha, sizeof(sha)) == 0)
      {
         /* Full-page crop: bbox is the whole page [0,1]. kind='page'. */
         if (db2_kb_doc_asset_insert(file_path, page, 0.0, 0.0, 1.0, 1.0, "page", "", "image/png",
                                     sha, sensitivity_class) > 0)
            created++;
      }
      free(png);
   }
   if (created)
      LOG_INFO("kb_doc_pdf", "rendered %d page asset(s) for %s", created, file_path);
   return created;
}

/* Phase D: OCR a scanned PDF (no extractable text layer). Renders each page to a PNG (the same
 * hardened pdftoppm harness), sends it to the OCR sidecar, and builds a kb_pdf_doc_t from the
 * returned text + per-line geometry — already normalized to [0,1] — so it flows through the
 * EXACT same kb_doc_pdf_ingest path as native text (citations work identically). Returns the
 * ingested chunk count (>0), 0 if no text was recognised on any page (caller falls back to
 * asset-only), or -1 on a DB error. */
int kb_doc_pdf_ingest_ocr_version(
    const char *project, const char *file_path, const char *file_hash,
    const char *sensitivity_class, const unsigned char *pdf_bytes, int n,
    const char *ocr_endpoint, int64_t original_version_id, kb_pdf_ingest_stats_t *stats)
{
   if (stats)
      memset(stats, 0, sizeof(*stats));
   if (!project || !*project || !file_path || !*file_path || !pdf_bytes || n <= 0 ||
       !ocr_endpoint || !ocr_endpoint[0])
      return 0;

   kb_pdf_doc_t doc;
   memset(&doc, 0, sizeof(doc));
   doc.normalized = 1; /* OCR geometry is already [0,1] — do NOT re-normalize. */

   for (int page = 1; page <= KB_PDF_RENDER_MAX_PAGES; page++)
   {
      unsigned char *png = NULL;
      int png_len = 0;
      int rc = kb_pdf_exec_render(pdf_bytes, n, page, &png, &png_len, 30000);
      if (rc == 1)
      {
         free(png);
         break; /* no more pages */
      }
      if (rc != 0 || !png)
      {
         free(png);
         if (page == 1)
            break; /* pdftoppm absent / unrenderable → nothing to OCR */
         continue;
      }
      kb_ocr_line_t *lines = NULL;
      int nlines = 0;
      int orc = kb_ocr_recognize(ocr_endpoint, page, png, png_len, &lines, &nlines);
      free(png);
      if (orc <= 0 || nlines == 0)
      {
         kb_ocr_free_lines(lines, nlines); /* no text on this page (or sidecar gone) */
         continue;
      }
      /* One doc-page per OCR'd page; each line carries the real page_no so citations + the
       * page-boundary chunker resolve to the correct page. */
      if (doc.n_pages >= doc.cap_pages)
      {
         int ncap = doc.cap_pages ? doc.cap_pages * 2 : 8;
         kb_pdf_page_t *np = realloc(doc.pages, (size_t)ncap * sizeof(*np));
         if (!np)
         {
            kb_ocr_free_lines(lines, nlines);
            kb_pdf_free_doc(&doc);
            return -1;
         }
         doc.pages = np;
         doc.cap_pages = ncap;
      }
      kb_pdf_page_t *pg = &doc.pages[doc.n_pages++];
      memset(pg, 0, sizeof(*pg));
      pg->width = 1.0;
      pg->height = 1.0;
      for (int i = 0; i < nlines; i++)
      {
         char *txt = strdup(lines[i].text);
         if (!txt)
            continue;
         if (page_add_line(pg, page, lines[i].x0, lines[i].y0, lines[i].x1, lines[i].y1, txt) != 0)
            free(txt); /* OOM growing the page's line array — drop this line, keep going */
      }
      kb_ocr_free_lines(lines, nlines);
   }

   int rc = 0;
   if (doc.n_pages > 0)
      rc = kb_doc_pdf_ingest_version(project, file_path, file_hash, &doc, sensitivity_class,
                                     original_version_id, "pdf-ocr-text", "ocr-sidecar-v1",
                                     stats);
   if (rc > 0)
      LOG_INFO("kb_doc_pdf", "OCR ingested %d page(s) for %s", doc.n_pages, file_path);
   kb_pdf_free_doc(&doc);
   return rc;
}

int kb_doc_pdf_ingest_ocr(const char *project, const char *file_path, const char *file_hash,
                          const char *sensitivity_class, const unsigned char *pdf_bytes, int n,
                          const char *ocr_endpoint, kb_pdf_ingest_stats_t *stats)
{
   return kb_doc_pdf_ingest_ocr_version(project, file_path, file_hash, sensitivity_class,
                                        pdf_bytes, n, ocr_endpoint, 0, stats);
}

/* Phase B: run the TSR sidecar over one chunk's (page's) regions and persist any recognised
 * cells, linking each cell to its source kb_doc_regions row via line_index (falling back to
 * the page's first region so every cell carries provenance). Best-effort: a sidecar failure
 * returns 0 and never aborts the ingest — the page stays text-only. Returns 1 if a table was
 * recognised + cells stored, else 0. */
static int kb_pdf_tsr_chunk(const char *file_path, const kb_pdf_chunk_t *c,
                            const int64_t *region_ids, int n_region_ids, const char *endpoint,
                            const char *sensitivity_class)
{
   if (!endpoint || !endpoint[0] || c->n_lines <= 0 || n_region_ids <= 0)
      return 0;
   int page_no = c->lines[0] ? c->lines[0]->page_no : c->page_start;

   cJSON *regions = cJSON_CreateArray();
   if (!regions)
      return 0;
   for (int j = 0; j < c->n_lines; j++)
   {
      const kb_pdf_line_t *ln = c->lines[j];
      cJSON *r = cJSON_CreateObject();
      cJSON_AddStringToObject(r, "text", ln->text ? ln->text : "");
      cJSON_AddNumberToObject(r, "x0", ln->x0);
      cJSON_AddNumberToObject(r, "y0", ln->y0);
      cJSON_AddNumberToObject(r, "x1", ln->x1);
      cJSON_AddNumberToObject(r, "y1", ln->y1);
      cJSON_AddNumberToObject(r, "line_index", j);
      cJSON_AddItemToArray(regions, r);
   }
   char *page_json = cJSON_PrintUnformatted(regions);
   cJSON_Delete(regions);
   if (!page_json)
      return 0;

   kb_tsr_cell_t *cells = NULL;
   int n_cells = 0;
   int rc = kb_tsr_recognize(endpoint, page_no, page_json, &cells, &n_cells);
   free(page_json);
   if (rc <= 0)
   {
      kb_tsr_free_cells(cells, n_cells);
      return 0;
   }
   for (int k = 0; k < n_cells; k++)
   {
      int li = cells[k].line_index;
      int64_t rid;
      if (li < 0)
         rid = region_ids[0]; /* sidecar gave no source line → honest page-level provenance */
      else if (li < n_region_ids)
         rid = region_ids[li]; /* mapped to the exact source line */
      else
         continue; /* out-of-range line_index from an untrusted sidecar → skip, not false-attribute
                    */
      if (rid <= 0)
         continue;
      if (db2_kb_table_cell_insert(rid, file_path, page_no, cells[k].row, cells[k].col,
                                   cells[k].text, cells[k].subject, cells[k].relation,
                                   cells[k].object, cells[k].confidence, sensitivity_class) < 0)
         LOG_WARN("kb_tsr", "table cell insert failed (%s p%d r%d c%d)", file_path, page_no,
                  cells[k].row, cells[k].col);
   }
   kb_tsr_free_cells(cells, n_cells);
   return 1;
}

int kb_doc_pdf_ingest_version(const char *project, const char *file_path, const char *file_hash,
                              const kb_pdf_doc_t *doc, const char *sensitivity_class,
                              int64_t original_version_id, const char *rendition_id,
                              const char *parser_version, kb_pdf_ingest_stats_t *stats)
{
   if (stats)
      memset(stats, 0, sizeof(*stats));
   if (!project || !file_path || !file_hash || !doc)
      return -1;
   /* The upload surface validates the class before reaching here; refuse to ingest under
    * an invalid/empty class so a row can never be written un-tagged. */
   if (!kb_pdf_sensitivity_valid(sensitivity_class))
      return -1;
   const char *quarantine = strcmp(sensitivity_class, "restricted") == 0 ? "pending" : "";

   /* Phase A1: when the PDF-vector capability is on, enqueue an embed_pdf job per
    * chunk so it lands in the isolated kb_pdf_embeddings relation. We do NOT embed
    * quarantined-pending (restricted) docs — they are withheld until an owner
    * confirms, at which point the confirm path enqueues their embed_pdf jobs. */
   config_t pdf_cfg;
   int cfg_ok = (config_load(&pdf_cfg) == 0);
   int vector_enabled = cfg_ok && pdf_cfg.kb_pdf_vector_enabled;
   int embed_pdf_vec = vector_enabled && quarantine[0] == '\0';

   /* Phase B: resolve the TSR sidecar endpoint when the capability is on. Unlike embed_pdf,
    * TSR runs even for a withheld (pending/restricted) doc: its cells are gated at READ time
    * by lookup_table's join to kb_documents.quarantine_state, so they stay invisible until an
    * owner confirms — at which point they (and tsr_status='ran') become visible with no
    * re-ingest needed. The TSR HTTP call + cell inserts run AFTER the ingest txn commits, so
    * a slow/failing sidecar never holds the txn open or poisons it (best-effort, the page
    * stays text-only on failure). tsr_attempted drives the per-document tsr_state marker
    * (ran | no_table | '' when off/absent). */
   const char *tsr_ep = (cfg_ok && pdf_cfg.kb_pdf_tsr_enabled) ? kb_tsr_endpoint(&pdf_cfg) : "";
   int tsr_attempted = (tsr_ep[0] != '\0');
   int tsr_found_table = 0;

   kb_pdf_chunk_t *chunks = NULL;
   int n_chunks = 0;
   if (kb_pdf_chunk(doc, &chunks, &n_chunks) < 0)
      return -1;

   /* Nothing extracted (empty / zero-line PDF): do NOT touch the DB. In particular do
    * not run the destructive delete below — a re-ingest whose extraction came back empty
    * must never silently wipe a document's prior rows. */
   if (n_chunks == 0)
   {
      kb_pdf_free_chunks(chunks, n_chunks);
      return 0;
   }

   /* Materialize prior vector ids before the atomic row replacement. Their
    * vectors are deleted only after commit, so a rollback leaves the prior
    * published version completely usable. */
   int64_t *prior_chunk_ids = calloc(KB_PDF_MAX_PAGES, sizeof(*prior_chunk_ids));
   int n_prior_chunk_ids = prior_chunk_ids
                               ? db2_kb_documents_list_chunk_ids_for_file(
                                     project, file_path, prior_chunk_ids, KB_PDF_MAX_PAGES)
                               : 0;

   /* Per-chunk source-region ids, retained across commit so the post-commit TSR pass can link
    * cells back to their kb_doc_regions rows without re-querying. */
   int64_t **chunk_rids = NULL;
   int *chunk_nrids = NULL;
   if (tsr_attempted)
   {
      chunk_rids = calloc((size_t)n_chunks, sizeof(*chunk_rids));
      chunk_nrids = calloc((size_t)n_chunks, sizeof(*chunk_nrids));
      if (!chunk_rids || !chunk_nrids)
      {
         free(chunk_rids);
         free(chunk_nrids);
         chunk_rids = NULL;
         chunk_nrids = NULL;
         tsr_attempted = 0; /* OOM on the retention arrays → degrade to text-only */
      }
   }

   /* The whole re-ingest is one transaction: the delete (regions cascade via the
    * kb_doc_regions FK ON DELETE CASCADE), every chunk + region insert, the neighbour
    * links, and the embed enqueues are all-or-nothing — a mid-loop failure rolls back so
    * the KB is never left with prior rows gone and only partial new rows. The borrowed
    * line pointers in `chunks` stay valid throughout: `doc` is owned by the caller and is
    * never freed here, and `chunks` is built, consumed, and freed inside this function. */
   if (db2_kb_txn_begin() != 0)
   {
      free(prior_chunk_ids);
      kb_pdf_free_chunks(chunks, n_chunks);
      return -1;
   }

   /* Phase C: a re-ingest drops this document's prior visual asset rows too (they are NOT a
    * relational cascade off kb_documents — document_key is logical). Done BEFORE the
    * kb_documents delete because the asset-scope check joins on the still-present kb_documents
    * file_path. The now-unreferenced blobs are reclaimed by the periodic reconciliation sweep,
    * so a shared/deduped blob survives until its last referrer is gone. New crops are rendered +
    * inserted by the upload route after this. */
   (void)db2_kb_doc_assets_delete_for_doc(project, file_path);
   (void)db2_curator_invalidate_doc(project, file_path);
   db2_kb_documents_delete_for_file(project, file_path); /* void; covered by the txn */

   int n_regions = 0;
   int64_t prev_id = 0; /* per-call local; the first chunk links with 0 (a no-op in
                         * db2_kb_documents_link_neighbours), and nothing carries across calls */
   for (int i = 0; i < n_chunks; i++)
   {
      kb_pdf_chunk_t *c = &chunks[i];
      char chunk_hash[KB_DOC_HASH_HEX_LEN + 1];
      kb_doc_content_hash(c->content ? c->content : "",
                          c->content ? (int)strlen(c->content) : 0, chunk_hash);
      char source_anchors[160];
      snprintf(source_anchors, sizeof(source_anchors),
               "[{\"kind\":\"page_range\",\"page_start\":%d,\"page_end\":%d}]",
               c->page_start, c->page_end);
      int64_t id = db2_kb_documents_insert_chunk_pdf_evidence(
          project, file_path, file_hash, i, "" /* heading_path: Phase-1 page chunking */,
          c->line_start, c->line_end, c->content ? c->content : "", c->token_count,
          "page" /* chunk_strategy */, c->page_start, c->page_end, sensitivity_class, quarantine,
          original_version_id, rendition_id, parser_version, chunk_hash, source_anchors);
      if (id <= 0)
         goto fail;
      db2_kb_documents_link_neighbours(id, prev_id); /* void; covered by the txn */

      int64_t region_ids[KB_PDF_MAX_CHUNK_LINES];
      int n_region_ids = 0;
      for (int j = 0; j < c->n_lines; j++)
      {
         const kb_pdf_line_t *ln = c->lines[j];
         int64_t rid =
             db2_kb_doc_regions_insert(id, file_path, ln->page_no, ln->x0, ln->y0, ln->x1, ln->y1,
                                       ln->text ? ln->text : "", j, "text", sensitivity_class);
         if (rid <= 0)
            goto fail;
         if (j < KB_PDF_MAX_CHUNK_LINES)
            region_ids[n_region_ids++] = rid;
         n_regions++;
      }

      /* Phase B: retain this page's region ids for the post-commit TSR pass (the TSR HTTP call
       * is deliberately NOT made inside this transaction). */
      if (tsr_attempted && chunk_rids)
      {
         chunk_rids[i] = malloc((size_t)n_region_ids * sizeof(int64_t));
         if (chunk_rids[i])
         {
            memcpy(chunk_rids[i], region_ids, (size_t)n_region_ids * sizeof(int64_t));
            chunk_nrids[i] = n_region_ids;
         }
      }

      /* Phase A1: enqueue the embed into the ISOLATED kb_pdf_embeddings relation
       * (kind='embed_pdf'), inside this same ingest transaction. Because the job
       * row only becomes visible to the drainer at commit — by which point this
       * chunk's kb_doc_regions are committed too — a vector-retrievable PDF chunk
       * always has its citations (the §A2 LEFT JOIN is the backstop if that ever
       * races). When the capability is off the chunk stays lexical-only, exactly
       * as Phase 2 behaved, and is invisible to the vector-only /v1/search by
       * construction (PDF vectors never enter kb_embeddings). */
      if (embed_pdf_vec && db2_kb_async_enqueue("embed_pdf", id, project) != 0)
         LOG_WARN("kb_pdf", "ingest: embed_pdf enqueue failed for chunk %lld (%s)", (long long)id,
                  file_path); /* best-effort; the chunk stays lexical-only + cited */
      prev_id = id;
   }

   /* The head moves only after every new chunk, region, lineage row and job has
    * been installed. This shares the surrounding transaction with the row
    * replacement, so partial extraction never supersedes a good prior version. */
   if (original_version_id > 0 && db2_kb_original_version_publish(original_version_id) != 1)
      goto fail;

   if (db2_kb_txn_commit() != 0)
      goto fail;

   for (int i = 0; i < n_prior_chunk_ids; i++)
      (void)pgvec_kbpdf_delete(prior_chunk_ids[i]);
   free(prior_chunk_ids);
   prior_chunk_ids = NULL;

   /* Phase B: TSR runs HERE — after the text/regions are durably committed — so the sidecar
    * HTTP call never holds the ingest txn open, and a per-cell insert failure cannot roll back
    * the document's text (cells are best-effort derived data; a crash before this leaves the
    * doc text-indexed and re-ingest re-derives the cells). Each cell insert is its own
    * autocommit statement, so a sidecar/SQL error here never poisons a transaction. */
   if (tsr_attempted && chunk_rids)
   {
      for (int i = 0; i < n_chunks; i++)
      {
         if (chunk_rids[i] && kb_pdf_tsr_chunk(file_path, &chunks[i], chunk_rids[i], chunk_nrids[i],
                                               tsr_ep, sensitivity_class))
            tsr_found_table = 1;
      }
      /* Record the per-document TSR outcome so lookup_table can report tsr_status
       * (ran | no_table); left '' when the capability is off/absent → 'unavailable'. */
      db2_kb_documents_set_tsr_state(project, file_path, tsr_found_table ? "ran" : "no_table");
   }
   if (chunk_rids)
      for (int i = 0; i < n_chunks; i++)
         free(chunk_rids[i]);
   free(chunk_rids);
   free(chunk_nrids);

   if (stats)
   {
      stats->chunks = n_chunks;
      stats->regions = n_regions;
   }
   kb_pdf_free_chunks(chunks, n_chunks);
   return n_chunks;

fail:
   db2_kb_txn_rollback();
   free(prior_chunk_ids);
   if (chunk_rids)
      for (int i = 0; i < n_chunks; i++)
         free(chunk_rids[i]);
   free(chunk_rids);
   free(chunk_nrids);
   kb_pdf_free_chunks(chunks, n_chunks);
   return -1;
}

int kb_doc_pdf_ingest(const char *project, const char *file_path, const char *file_hash,
                      const kb_pdf_doc_t *doc, const char *sensitivity_class,
                      kb_pdf_ingest_stats_t *stats)
{
   return kb_doc_pdf_ingest_version(project, file_path, file_hash, doc, sensitivity_class, 0,
                                    "pdf-text", "legacy", stats);
}

int kb_doc_pdf_ingest_xhtml(const char *project, const char *file_path, const char *file_hash,
                            const char *xhtml, const char *sensitivity_class,
                            kb_pdf_ingest_stats_t *stats)
{
   kb_pdf_doc_t doc;
   if (kb_pdf_parse_bbox_layout(xhtml, &doc) != 0)
      return -1;
   kb_pdf_normalize(&doc);
   int rc = kb_doc_pdf_ingest(project, file_path, file_hash, &doc, sensitivity_class, stats);
   kb_pdf_free_doc(&doc);
   return rc;
}

int kb_doc_pdf_ingest_xhtml_version(
    const char *project, const char *file_path, const char *file_hash, const char *xhtml,
    const char *sensitivity_class, int64_t original_version_id, kb_pdf_ingest_stats_t *stats)
{
   kb_pdf_doc_t doc;
   if (kb_pdf_parse_bbox_layout(xhtml, &doc) != 0)
      return -1;
   kb_pdf_normalize(&doc);
   int rc = kb_doc_pdf_ingest_version(project, file_path, file_hash, &doc, sensitivity_class,
                                      original_version_id, "pdf-native-text",
                                      "poppler-bbox-v1", stats);
   kb_pdf_free_doc(&doc);
   return rc;
}
