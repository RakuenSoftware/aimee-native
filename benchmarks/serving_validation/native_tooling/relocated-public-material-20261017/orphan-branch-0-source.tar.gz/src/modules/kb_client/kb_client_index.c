/* kb_client_index.c: thin client wrappers for the aimee-kb /v1 code-index API */
#include "kb_client.h"
#include "kb_client_internal.h"
#include "code_collect.h"
#include "cJSON.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Scan timeout is generous because canonical scans of large monorepos can take
 * tens of seconds. The shared v1 helpers choose remote HTTP when configured and
 * otherwise tunnel the same /v1 route over the local UDS transport. */
#define KB_CLIENT_INDEX_SCAN_TIMEOUT_MS (5 * 60 * 1000)
#define KB_CLIENT_INDEX_READ_TIMEOUT_MS (5 * 1000)

static int kb_index_find_parse(cJSON *resp, term_hit_t *out, int max)
{
   if (!resp)
      return 0;
   int count = 0;
   cJSON *hits = cJSON_GetObjectItemCaseSensitive(resp, "hits");
   if (cJSON_IsArray(hits))
   {
      cJSON *h;
      cJSON_ArrayForEach(h, hits)
      {
         if (count >= max)
            break;
         cJSON *p = cJSON_GetObjectItemCaseSensitive(h, "project");
         cJSON *f = cJSON_GetObjectItemCaseSensitive(h, "file_path");
         cJSON *l = cJSON_GetObjectItemCaseSensitive(h, "line");
         cJSON *k = cJSON_GetObjectItemCaseSensitive(h, "kind");
         if (cJSON_IsString(p))
            snprintf(out[count].project, sizeof(out[count].project), "%s", p->valuestring);
         if (cJSON_IsString(f))
            snprintf(out[count].file_path, sizeof(out[count].file_path), "%s", f->valuestring);
         out[count].line = cJSON_IsNumber(l) ? (int)l->valuedouble : 0;
         cJSON *le = cJSON_GetObjectItemCaseSensitive(h, "line_end");
         out[count].line_end = cJSON_IsNumber(le) ? (int)le->valuedouble : 0;
         if (cJSON_IsString(k))
            snprintf(out[count].kind, sizeof(out[count].kind), "%s", k->valuestring);
         count++;
      }
   }
   return count;
}

static int kb_index_project_list_parse(cJSON *resp, project_info_t *out, int max)
{
   if (!resp)
      return 0;
   int count = 0;
   cJSON *projects = cJSON_GetObjectItemCaseSensitive(resp, "projects");
   if (cJSON_IsArray(projects))
   {
      cJSON *p;
      cJSON_ArrayForEach(p, projects)
      {
         if (count >= max)
            break;
         cJSON *n = cJSON_GetObjectItemCaseSensitive(p, "name");
         cJSON *r = cJSON_GetObjectItemCaseSensitive(p, "root");
         cJSON *s = cJSON_GetObjectItemCaseSensitive(p, "scanned_at");
         if (cJSON_IsString(n))
            snprintf(out[count].name, sizeof(out[count].name), "%s", n->valuestring);
         if (cJSON_IsString(r))
            snprintf(out[count].root, sizeof(out[count].root), "%s", r->valuestring);
         if (cJSON_IsString(s))
            snprintf(out[count].scanned_at, sizeof(out[count].scanned_at), "%s", s->valuestring);
         count++;
      }
   }
   return count;
}

static int kb_index_code_search_parse(cJSON *resp, code_search_hit_t *out, int max)
{
   if (!resp)
      return 0;
   int count = 0;
   cJSON *hits = cJSON_GetObjectItemCaseSensitive(resp, "hits");
   if (cJSON_IsArray(hits))
   {
      cJSON *h;
      cJSON_ArrayForEach(h, hits)
      {
         if (count >= max)
            break;
         cJSON *p = cJSON_GetObjectItemCaseSensitive(h, "project");
         cJSON *f = cJSON_GetObjectItemCaseSensitive(h, "file_path");
         cJSON *s = cJSON_GetObjectItemCaseSensitive(h, "snippet");
         cJSON *r = cJSON_GetObjectItemCaseSensitive(h, "rank");
         cJSON *ln = cJSON_GetObjectItemCaseSensitive(h, "line");
         if (cJSON_IsString(p))
            snprintf(out[count].project, sizeof(out[count].project), "%s", p->valuestring);
         if (cJSON_IsString(f))
            snprintf(out[count].file_path, sizeof(out[count].file_path), "%s", f->valuestring);
         if (cJSON_IsString(s))
            snprintf(out[count].snippet, sizeof(out[count].snippet), "%s", s->valuestring);
         out[count].rank = cJSON_IsNumber(r) ? r->valuedouble : 0.0;
         /* P1b span enrichment: matched line, present only when the search
          * enriched (absent -> 0). */
         out[count].line = (cJSON_IsNumber(ln) && ln->valueint > 0) ? ln->valueint : 0;
         count++;
      }
   }
   return count;
}

static int kb_index_find_callers_parse(cJSON *resp, caller_hit_t *out, int max)
{
   if (!resp)
      return 0;
   int count = 0;
   cJSON *hits = cJSON_GetObjectItemCaseSensitive(resp, "hits");
   if (cJSON_IsArray(hits))
   {
      cJSON *h;
      cJSON_ArrayForEach(h, hits)
      {
         if (count >= max)
            break;
         cJSON *p = cJSON_GetObjectItemCaseSensitive(h, "project");
         cJSON *f = cJSON_GetObjectItemCaseSensitive(h, "file_path");
         cJSON *cf = cJSON_GetObjectItemCaseSensitive(h, "caller");
         cJSON *l = cJSON_GetObjectItemCaseSensitive(h, "line");
         if (cJSON_IsString(p))
            snprintf(out[count].project, sizeof(out[count].project), "%s", p->valuestring);
         if (cJSON_IsString(f))
            snprintf(out[count].file_path, sizeof(out[count].file_path), "%s", f->valuestring);
         if (cJSON_IsString(cf))
            snprintf(out[count].caller, sizeof(out[count].caller), "%s", cf->valuestring);
         out[count].line = cJSON_IsNumber(l) ? (int)l->valuedouble : 0;
         count++;
      }
   }
   return count;
}

int kb_client_code_scan_push(const char *name, const char *root, int force, void *files_arr_v,
                             kb_client_index_scan_result_t *out)
{
   cJSON *files_arr = (cJSON *)files_arr_v;

   if (!name || !name[0] || !root || !root[0])
   {
      if (files_arr)
         cJSON_Delete(files_arr);
      if (out)
      {
         out->skipped = 1;
         snprintf(out->reason, sizeof(out->reason), "missing_project_root");
         snprintf(out->message, sizeof(out->message),
                  "code index scan requires explicit project and root");
      }
      return -1;
   }

   cJSON *req = cJSON_CreateObject();
   if (!req)
   {
      if (files_arr)
         cJSON_Delete(files_arr);
      return kb_client_index_scan_apply_response(NULL, out);
   }
   cJSON_AddStringToObject(req, "project", name);
   cJSON_AddStringToObject(req, "root_path", root);
   if (force)
      cJSON_AddBoolToObject(req, "force", 1);
   /* Caller-supplied {"rel_path","content"} entries (adopted) let the kb index
    * without filesystem access — used both for a remote kb and for files the
    * thin client pushes for a workspace the server cannot see. */
   if (files_arr)
      cJSON_AddItemToObject(req, "files", files_arr);

   char *json = kb_client_v1_post_json("/v1/code/scan", req, KB_CLIENT_INDEX_SCAN_TIMEOUT_MS, NULL);
   cJSON_Delete(req);
   if (!json)
      return kb_client_index_scan_apply_response(NULL, out);

   cJSON *resp = cJSON_Parse(json);
   free(json);
   int rc = kb_client_index_scan_apply_response(resp, out);
   if (rc == 0 && out && out->projects == 0)
      out->projects = 1;
   if (resp)
      cJSON_Delete(resp);
   return rc;
}

static int kb_client_generation_post(cJSON *req, kb_client_index_scan_result_t *out)
{
   if (!req)
      return kb_client_index_scan_apply_response(NULL, out);
   char *json =
       kb_client_v1_post_json("/v1/code/scan", req, KB_CLIENT_INDEX_SCAN_TIMEOUT_MS, NULL);
   cJSON_Delete(req);
   if (!json)
      return kb_client_index_scan_apply_response(NULL, out);
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int rc = kb_client_index_scan_apply_response(resp, out);
   cJSON_Delete(resp);
   return rc;
}

static int kb_client_generation_begin(const char *name, const char *root,
                                      const code_source_snapshot_t *snapshot, int force,
                                      kb_client_index_scan_result_t *out)
{
   cJSON *req = cJSON_CreateObject();
   if (!req)
      return kb_client_index_scan_apply_response(NULL, out);
   cJSON_AddStringToObject(req, "action", "begin_generation");
   cJSON_AddStringToObject(req, "repository_key", name);
   cJSON_AddStringToObject(req, "source_ref", snapshot->ref);
   cJSON_AddStringToObject(req, "commit_sha", snapshot->commit_sha);
   cJSON_AddStringToObject(req, "tree_sha", snapshot->tree_sha);
   cJSON_AddStringToObject(req, "root_path", root);
   cJSON_AddBoolToObject(req, "is_default", snapshot->is_default);
   if (force)
      cJSON_AddBoolToObject(req, "force", 1);
   return kb_client_generation_post(req, out);
}

static int kb_client_generation_append(int64_t generation_id, cJSON *files_arr,
                                       kb_client_index_scan_result_t *out)
{
   cJSON *req = cJSON_CreateObject();
   if (!req)
   {
      cJSON_Delete(files_arr);
      return kb_client_index_scan_apply_response(NULL, out);
   }
   cJSON_AddStringToObject(req, "action", "append_generation");
   cJSON_AddNumberToObject(req, "generation_id", (double)generation_id);
   cJSON_AddItemToObject(req, "files", files_arr ? files_arr : cJSON_CreateArray());
   return kb_client_generation_post(req, out);
}

static int kb_client_generation_finish(int64_t generation_id, const char *tree_sha,
                                       int expected_files, kb_client_index_scan_result_t *out)
{
   cJSON *req = cJSON_CreateObject();
   if (!req)
      return kb_client_index_scan_apply_response(NULL, out);
   cJSON_AddStringToObject(req, "action", "finish_generation");
   cJSON_AddNumberToObject(req, "generation_id", (double)generation_id);
   cJSON_AddStringToObject(req, "source_manifest_hash", tree_sha);
   cJSON_AddNumberToObject(req, "expected_file_count", expected_files);
   return kb_client_generation_post(req, out);
}

#ifdef AIMEE_POSIX
/* Per-batch content budget for pushed-file scans. Batching keeps client
 * memory to ~one batch regardless of tree size, gives per-batch progress
 * against the scan timeout, and stays under the 1 MB request-body cap of
 * pre-KB_HTTP_BODY_MAX aimee-kb images (which silently truncated bigger
 * bodies into 400 "invalid json"). The kb scan upserts per project+path, so
 * batches accumulate — the same contract the thin client's /v1/index/ingest
 * streamer relies on. */
#define KB_CLIENT_SCAN_BATCH_BYTES (600 * 1024)

/* Streaming scan-push state: code_collect_files_cb hands over one file at a
 * time; we accumulate byte-bounded batches and POST each the moment it fills,
 * keeping memory to ~one batch regardless of tree size. */
typedef struct
{
   const char *name;
   const char *root;
   int force;
   int generation_mode;
   int64_t generation_id;
   int total_files;
   cJSON *batch; /* current open batch, or NULL */
   size_t batch_bytes;
   int batches;   /* batches pushed */
   int failed_rc; /* rc of the first failed batch push; 0 while all succeed */
   kb_client_index_scan_result_t fail_res; /* result of that failed push */
   kb_client_index_scan_result_t agg;      /* aggregate of successful pushes */
} kb_scan_push_ctx_t;

/* Push the current batch (kb_client_code_scan_push adopts/frees it) and fold
 * the per-batch result into the aggregate. */
static void kb_scan_push_flush(kb_scan_push_ctx_t *s)
{
   if (!s->batch)
      return;
   if (cJSON_GetArraySize(s->batch) == 0 || s->failed_rc != 0)
   {
      cJSON_Delete(s->batch);
      s->batch = NULL;
      s->batch_bytes = 0;
      return;
   }
   kb_client_index_scan_result_t res;
   memset(&res, 0, sizeof(res));
   int rc = s->generation_mode
                ? kb_client_generation_append(s->generation_id, s->batch, &res)
                : kb_client_code_scan_push(s->name, s->root, s->force, s->batch, &res);
   s->batch = NULL;
   s->batch_bytes = 0;
   s->batches++;
   if (rc == 0 && !res.skipped)
   {
      s->agg.projects = 1;
      s->agg.files += res.files;
      s->agg.inspected += res.inspected;
      s->agg.generation_id = s->generation_id;
   }
   else
   {
      s->failed_rc = rc != 0 ? rc : -1;
      s->fail_res = res;
   }
}

static int kb_scan_push_collect_cb(const char *rel_path, const char *content, void *ctx)
{
   kb_scan_push_ctx_t *s = (kb_scan_push_ctx_t *)ctx;
   size_t flen = strlen(content) + strlen(rel_path) + 64;

   if (s->batch && cJSON_GetArraySize(s->batch) > 0 &&
       s->batch_bytes + flen > KB_CLIENT_SCAN_BATCH_BYTES)
      kb_scan_push_flush(s);
   if (s->failed_rc != 0)
      return 1; /* a batch failed — stop the walk, report the failure */

   if (!s->batch)
   {
      s->batch = cJSON_CreateArray();
      if (!s->batch)
         return 1; /* OOM — stop; the batches so far are already indexed */
   }
   cJSON *entry = cJSON_CreateObject();
   if (!entry)
      return 0; /* skip this file, keep walking */
   cJSON_AddStringToObject(entry, "rel_path", rel_path);
   cJSON_AddStringToObject(entry, "content", content);
   cJSON_AddItemToArray(s->batch, entry);
   s->batch_bytes += flen;
   s->total_files++;
   return 0;
}
#endif

static int kb_client_index_scan_generation(const char *name, const char *root,
                                           const code_source_snapshot_t *snapshot, int force,
                                           kb_client_index_scan_result_t *out)
{
#ifdef AIMEE_POSIX
   kb_client_index_scan_result_t begin;
   memset(&begin, 0, sizeof(begin));
   int rc = kb_client_generation_begin(name, root, snapshot, force, &begin);
   if (rc != 0)
   {
      if (out)
         *out = begin;
      return rc;
   }
   if (begin.already_current)
   {
      begin.projects = 1;
      begin.skipped = 1;
      snprintf(begin.reason, sizeof(begin.reason), "unchanged");
      if (out)
         *out = begin;
      return 0;
   }

   kb_scan_push_ctx_t s;
   memset(&s, 0, sizeof(s));
   s.name = name;
   s.root = root;
   s.force = force;
   s.generation_mode = 1;
   s.generation_id = begin.generation_id;
   code_source_snapshot_t captured;
   int collected = code_collect_files_at_ref_cb(root, snapshot->commit_sha,
                                                kb_scan_push_collect_cb, &s, &captured);
   kb_scan_push_flush(&s);
   if (s.failed_rc != 0)
   {
      if (out)
         *out = s.fail_res;
      return s.failed_rc;
   }
   if (collected != s.total_files || strcmp(captured.commit_sha, snapshot->commit_sha) != 0 ||
       strcmp(captured.tree_sha, snapshot->tree_sha) != 0)
   {
      if (out)
      {
         *out = begin;
         out->skipped = 1;
         snprintf(out->reason, sizeof(out->reason), "error");
         snprintf(out->message, sizeof(out->message),
                  "exact committed source snapshot could not be collected");
      }
      return -1;
   }

   kb_client_index_scan_result_t finished;
   memset(&finished, 0, sizeof(finished));
   rc = kb_client_generation_finish(begin.generation_id, snapshot->tree_sha, collected, &finished);
   if (rc == 0)
   {
      finished.projects = 1;
      finished.inspected = collected;
   }
   if (out)
      *out = finished;
   return rc;
#else
   (void)name;
   (void)root;
   (void)snapshot;
   (void)force;
   return kb_client_index_scan_apply_response(NULL, out);
#endif
}

static int kb_client_index_scan_v1(const char *name, const char *root, int force,
                                   kb_client_index_scan_result_t *out)
{
#ifdef AIMEE_POSIX
   /* When aimee-kb is remote (AIMEE_KB_API_URL set), the container cannot reach
    * the host filesystem via root_path.  Enumerate and push file contents so
    * the handler can index without filesystem access — in byte-bounded batches,
    * since the kb caps request bodies at 1 MB. */
   if (name && name[0] && root && root[0] && kb_client_v1_base_url())
   {
      kb_scan_push_ctx_t s;
      memset(&s, 0, sizeof(s));
      s.name = name;
      s.root = root;
      s.force = force;
      code_collect_files_cb(root, kb_scan_push_collect_cb, &s);
      kb_scan_push_flush(&s); /* flush the trailing partial batch */
      if (s.failed_rc != 0)
      {
         if (out)
            *out = s.fail_res;
         return s.failed_rc;
      }
      if (s.batches > 0)
      {
         if (out)
            *out = s.agg;
         return 0;
      }
      /* No indexable files collected: push an empty files array so the kb
       * still registers the project + queues curation (prior behavior),
       * rather than falling back to a root_path scan of a filesystem the kb
       * cannot see. */
      return kb_client_code_scan_push(name, root, force, cJSON_CreateArray(), out);
   }
#endif
   return kb_client_code_scan_push(name, root, force, NULL, out);
}

int kb_client_index_scan_ref(const char *name, const char *root, const char *source_ref, int force,
                             kb_client_index_scan_result_t *out)
{
   if (out)
      memset(out, 0, sizeof(*out));

#ifdef AIMEE_POSIX
   if (name && name[0] && root && root[0] &&
       (!code_index_source_is_worktree() || (source_ref && source_ref[0])))
   {
      code_source_snapshot_t snapshot;
      if (code_resolve_source_snapshot(root, source_ref, &snapshot) == 0)
      {
         /* Never retire the branch the caller is standing on. A freshly created
          * branch and a fast-forward-merged one both have the default's tip, so
          * "merged" alone would retire live work: the ref loses its generation
          * and publication then refuses it ("ref retired before publication"),
          * stranding the checkout with no source context and no way to rebuild
          * one. An actively checked-out branch stays valid even when its tip is
          * reachable from the default. */
         if (source_ref && source_ref[0] && code_source_ref_is_merged(root, source_ref) == 1 &&
             !code_source_ref_is_current_checkout(root, source_ref))
         {
            int rc = kb_client_index_retire_ref(name, snapshot.ref, "merged", -1, out);
            if (rc == 0 && out)
            {
               out->skipped = 1;
               snprintf(out->reason, sizeof(out->reason), "merged");
               snprintf(out->message, sizeof(out->message),
                        "source ref is merged into the default branch and was retired");
            }
            return rc;
         }
         return kb_client_index_scan_generation(name, root, &snapshot, force, out);
      }
      if (source_ref && source_ref[0])
      {
         kb_client_index_scan_result_t retired;
         if (kb_client_index_retire_ref(name, source_ref, "deleted", -1, &retired) == 0)
         {
            if (out)
            {
               *out = retired;
               out->skipped = 1;
               snprintf(out->reason, sizeof(out->reason), "deleted");
               snprintf(out->message, sizeof(out->message),
                        "source ref is unavailable and was retired");
            }
            return 0;
         }
         if (out)
         {
            out->skipped = 1;
            snprintf(out->reason, sizeof(out->reason), "error");
            snprintf(out->message, sizeof(out->message), "requested source ref is unavailable");
         }
         return -1;
      }
   }
#else
   (void)source_ref;
#endif

   return kb_client_index_scan_v1(name, root, force, out);
}

int kb_client_index_scan(const char *name, const char *root, int force,
                         kb_client_index_scan_result_t *out)
{
   return kb_client_index_scan_ref(name, root, NULL, force, out);
}

int kb_client_index_scan_current(const char *name, const char *root, int force,
                                 kb_client_index_scan_result_t *out)
{
   if (out)
      memset(out, 0, sizeof(*out));
#ifdef AIMEE_POSIX
   code_source_snapshot_t snapshot;
   if (name && name[0] && root && root[0] &&
       code_resolve_current_snapshot(root, &snapshot) == 0)
      return kb_client_index_scan_generation(name, root, &snapshot, force, out);
#else
   (void)name;
   (void)root;
   (void)force;
#endif
   if (out)
   {
      out->skipped = 1;
      snprintf(out->reason, sizeof(out->reason), "error");
      snprintf(out->message, sizeof(out->message),
               "current checkout is not an attached Git branch");
   }
   return -1;
}

int kb_client_index_retire_ref(const char *repository_key, const char *source_ref,
                               const char *reason, int grace_seconds,
                               kb_client_index_scan_result_t *out)
{
   if (out)
      memset(out, 0, sizeof(*out));
   if (!repository_key || !repository_key[0] || !source_ref || !source_ref[0] || !reason ||
       (strcmp(reason, "merged") != 0 && strcmp(reason, "deleted") != 0) ||
       grace_seconds < -1)
      return kb_client_index_scan_apply_response(NULL, out);
   cJSON *req = cJSON_CreateObject();
   if (!req)
      return kb_client_index_scan_apply_response(NULL, out);
   cJSON_AddStringToObject(req, "action", "retire_ref");
   cJSON_AddStringToObject(req, "repository_key", repository_key);
   cJSON_AddStringToObject(req, "source_ref", source_ref);
   cJSON_AddStringToObject(req, "reason", reason);
   if (grace_seconds >= 0)
      cJSON_AddNumberToObject(req, "grace_seconds", grace_seconds);
   return kb_client_generation_post(req, out);
}

int kb_client_index_find(const char *identifier, term_hit_t *out, int max)
{
   if (!identifier || !identifier[0] || !out || max <= 0)
      return 0;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *encoded = kb_client_query_escape(identifier);
   if (!encoded)
      return 0;
   char path[512];
   snprintf(path, sizeof(path), "/v1/code/find?identifier=%s&max_results=%d", encoded, max);
   free(encoded);
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   if (!json)
      return 0;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_find_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_find_ref(const char *repository_key, const char *source_ref,
                             const char *source_commit, const char *identifier,
                             term_hit_t *out, int max)
{
   if (!repository_key || !repository_key[0] || !source_ref || !source_ref[0] ||
       !source_commit || !source_commit[0] || !identifier || !identifier[0] || !out || max <= 0)
      return -1;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *encoded_identifier = kb_client_query_escape(identifier);
   char *encoded_repository = kb_client_query_escape(repository_key);
   char *encoded_ref = kb_client_query_escape(source_ref);
   char *encoded_commit = kb_client_query_escape(source_commit);
   if (!encoded_identifier || !encoded_repository || !encoded_ref || !encoded_commit)
   {
      free(encoded_identifier);
      free(encoded_repository);
      free(encoded_ref);
      free(encoded_commit);
      return -1;
   }

   char path[8192];
   int path_len = snprintf(path, sizeof(path),
                           "/v1/code/find?identifier=%s&max_results=%d&repository_key=%s"
                           "&source_ref=%s&source_commit=%s",
                           encoded_identifier, max, encoded_repository, encoded_ref,
                           encoded_commit);
   free(encoded_identifier);
   free(encoded_repository);
   free(encoded_ref);
   free(encoded_commit);
   if (path_len < 0 || (size_t)path_len >= sizeof(path))
      return -1;

   int http_status = -1;
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, &http_status);
   if (!json)
      return http_status == 409 ? -2 : -1;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_find_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_find_current(const char *repository_key, const char *root,
                                 const char *identifier, term_hit_t *out, int max)
{
#ifdef AIMEE_POSIX
   code_source_snapshot_t snapshot;
   if (!repository_key || !repository_key[0] || !root || !root[0] ||
       code_resolve_current_snapshot(root, &snapshot) != 0)
      return -1;

   int found = kb_client_index_find_ref(repository_key, snapshot.ref, snapshot.commit_sha,
                                        identifier, out, max);
   if (found != -2)
      return found;

   /* A hook normally keeps this cheap path current. This synchronous repair is
    * the correctness backstop for a newly checked-out/committed branch. */
   kb_client_index_scan_result_t scan;
   if (kb_client_index_scan_current(repository_key, root, 0, &scan) != 0)
      return -1;
   return kb_client_index_find_ref(repository_key, snapshot.ref, snapshot.commit_sha,
                                   identifier, out, max);
#else
   (void)repository_key;
   (void)root;
   (void)identifier;
   (void)out;
   (void)max;
   return -1;
#endif
}

int kb_client_index_list(project_info_t *out, int max)
{
   if (!out || max <= 0)
      return 0;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char path[64];
   snprintf(path, sizeof(path), "/v1/code/projects?max_results=%d", max);
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   if (!json)
      return -1; /* service unavailable — caller can distinguish from empty (0) */
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_project_list_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_blast_radius(const char *project, const char *file_path, blast_radius_t *out)
{
   if (!project || !file_path || !out)
      return -1;
   memset(out, 0, sizeof(*out));
   snprintf(out->file, sizeof(out->file), "%s", file_path);

   char *project_q = kb_client_query_escape(project);
   char *file_q = kb_client_query_escape(file_path);
   if (!project_q || !file_q)
   {
      free(project_q);
      free(file_q);
      return -1;
   }
   char path[MAX_PATH_LEN + 512];
   snprintf(path, sizeof(path), "/v1/code/blast-radius?project=%s&file_path=%s", project_q, file_q);
   free(project_q);
   free(file_q);
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   if (!json)
      return -1;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   if (!resp)
      return -1;

   cJSON *file = cJSON_GetObjectItemCaseSensitive(resp, "file");
   if (cJSON_IsString(file))
      snprintf(out->file, sizeof(out->file), "%s", file->valuestring);

   cJSON *deps = cJSON_GetObjectItemCaseSensitive(resp, "dependencies");
   if (cJSON_IsArray(deps))
   {
      cJSON *d;
      cJSON_ArrayForEach(d, deps)
      {
         if (out->dependency_count >= 64)
            break;
         if (cJSON_IsString(d))
            snprintf(out->dependencies[out->dependency_count++], MAX_PATH_LEN, "%s",
                     d->valuestring);
      }
   }
   cJSON *depts = cJSON_GetObjectItemCaseSensitive(resp, "dependents");
   if (cJSON_IsArray(depts))
   {
      cJSON *d;
      cJSON_ArrayForEach(d, depts)
      {
         if (out->dependent_count >= 64)
            break;
         if (cJSON_IsString(d))
            snprintf(out->dependents[out->dependent_count++], MAX_PATH_LEN, "%s", d->valuestring);
      }
   }
   cJSON_Delete(resp);
   return 0;
}

static const char *kb_index_preview_severity(int dependent_count)
{
   if (dependent_count >= 10)
      return "red";
   if (dependent_count >= 3)
      return "yellow";
   return "green";
}

static int kb_index_preview_severity_rank(const char *severity)
{
   if (severity && strcmp(severity, "red") == 0)
      return 2;
   if (severity && strcmp(severity, "yellow") == 0)
      return 1;
   return 0;
}

static char *kb_client_index_blast_radius_preview_v1(const char *project, char **paths,
                                                     int path_count)
{
   cJSON *root = cJSON_CreateObject();
   if (!root)
      return NULL;
   cJSON *files = cJSON_AddArrayToObject(root, "files");
   cJSON *warnings = cJSON_CreateArray();
   if (!files || !warnings)
   {
      cJSON_Delete(root);
      cJSON_Delete(warnings);
      return NULL;
   }

   int total_dependents = 0;
   int max_severity = 0;
   int red_count = 0;
   char dirs[20][64];
   int dir_count = 0;

   for (int i = 0; i < path_count; i++)
   {
      const char *path = paths[i] ? paths[i] : "";
      blast_radius_t br;
      int rc = kb_client_index_blast_radius(project, path, &br);

      cJSON *file = cJSON_CreateObject();
      cJSON_AddStringToObject(file, "path", path);
      cJSON *deps = cJSON_AddArrayToObject(file, "dependents");
      int dependent_count = 0;
      if (rc == 0)
      {
         dependent_count = br.dependent_count;
         for (int j = 0; j < br.dependent_count; j++)
            cJSON_AddItemToArray(deps, cJSON_CreateString(br.dependents[j]));
      }
      cJSON_AddNumberToObject(file, "dependent_count", dependent_count);
      const char *severity = kb_index_preview_severity(dependent_count);
      cJSON_AddStringToObject(file, "severity", severity);
      cJSON_AddItemToArray(files, file);

      total_dependents += dependent_count;
      int rank = kb_index_preview_severity_rank(severity);
      if (rank > max_severity)
         max_severity = rank;
      if (rank == 2)
         red_count++;
      if (dependent_count > 10)
      {
         char warn[256];
         snprintf(warn, sizeof(warn), "%s has %d dependents, consider splitting the change", path,
                  dependent_count);
         cJSON_AddItemToArray(warnings, cJSON_CreateString(warn));
      }

      const char *slash = strrchr(path, '/');
      if (slash && dir_count < 20)
      {
         char prefix[64];
         int len = (int)(slash - path);
         if (len > 63)
            len = 63;
         snprintf(prefix, sizeof(prefix), "%.*s", len, path);
         int found = 0;
         for (int d = 0; d < dir_count; d++)
            if (strcmp(dirs[d], prefix) == 0)
               found = 1;
         if (!found)
            snprintf(dirs[dir_count++], sizeof(dirs[0]), "%s", prefix);
      }
   }

   if (red_count > 1)
      cJSON_AddItemToArray(warnings,
                           cJSON_CreateString("Multiple high-impact files in this change set"));
   if (dir_count > 2)
      cJSON_AddItemToArray(
          warnings, cJSON_CreateString("Changes span multiple subsystems, consider separate PRs"));
   cJSON_AddNumberToObject(root, "total_dependents", total_dependents);
   cJSON_AddStringToObject(root, "severity",
                           max_severity == 2   ? "red"
                           : max_severity == 1 ? "yellow"
                                               : "green");
   cJSON_AddItemToObject(root, "warnings", warnings);
   char *json = cJSON_PrintUnformatted(root);
   cJSON_Delete(root);
   return json ? json : strdup("{}");
}

char *kb_client_index_blast_radius_preview_json(const char *project, char **paths, int path_count)
{
   if (!project || !paths || path_count < 1)
      return NULL;

   return kb_client_index_blast_radius_preview_v1(project, paths, path_count);
}

int kb_client_index_structure(const char *project, const char *file_path, definition_t *out,
                              int max)
{
   if (!project || !file_path || !out || max <= 0)
      return 0;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *project_q = kb_client_query_escape(project);
   char *file_q = kb_client_query_escape(file_path);
   if (!project_q || !file_q)
   {
      free(project_q);
      free(file_q);
      return 0;
   }
   char path[MAX_PATH_LEN + 512];
   snprintf(path, sizeof(path), "/v1/code/structure?project=%s&file_path=%s&max_results=%d",
            project_q, file_q, max);
   free(project_q);
   free(file_q);
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   if (!json)
      return 0;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   if (!resp)
      return 0;

   int count = 0;
   cJSON *defs = cJSON_GetObjectItemCaseSensitive(resp, "definitions");
   if (cJSON_IsArray(defs))
   {
      cJSON *d;
      cJSON_ArrayForEach(d, defs)
      {
         if (count >= max)
            break;
         cJSON *name = cJSON_GetObjectItemCaseSensitive(d, "name");
         cJSON *kind = cJSON_GetObjectItemCaseSensitive(d, "kind");
         cJSON *line = cJSON_GetObjectItemCaseSensitive(d, "line");
         if (cJSON_IsString(name))
            snprintf(out[count].name, sizeof(out[count].name), "%s", name->valuestring);
         if (cJSON_IsString(kind))
            snprintf(out[count].kind, sizeof(out[count].kind), "%s", kind->valuestring);
         out[count].line = cJSON_IsNumber(line) ? (int)line->valuedouble : 0;
         cJSON *line_end = cJSON_GetObjectItemCaseSensitive(d, "line_end");
         out[count].line_end = cJSON_IsNumber(line_end) ? (int)line_end->valuedouble : 0;
         count++;
      }
   }
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_project_stats(const char *project, int *files_out, int *defs_out)
{
   if (files_out)
      *files_out = 0;
   if (defs_out)
      *defs_out = 0;
   if (!project || !project[0])
      return -1;

   {
      char *project_q = kb_client_query_escape(project);
      if (!project_q)
         return -1;
      char path[512];
      snprintf(path, sizeof(path), "/v1/code/project-stats?project=%s", project_q);
      free(project_q);
      char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
      if (!json)
         return -1;
      cJSON *resp = cJSON_Parse(json);
      free(json);
      if (!resp)
         return -1;

      cJSON *status = cJSON_GetObjectItemCaseSensitive(resp, "status");
      int rc = -1;
      if (cJSON_IsString(status) && strcmp(status->valuestring, "ok") == 0)
      {
         cJSON *f = cJSON_GetObjectItemCaseSensitive(resp, "files");
         cJSON *d = cJSON_GetObjectItemCaseSensitive(resp, "definitions");
         if (files_out && cJSON_IsNumber(f))
            *files_out = (int)f->valuedouble;
         if (defs_out && cJSON_IsNumber(d))
            *defs_out = (int)d->valuedouble;
         rc = 0;
      }
      cJSON_Delete(resp);
      return rc;
   }
}

int kb_client_index_project_lang(const char *project, char *buf, size_t bufsz)
{
   if (!buf || bufsz < 3)
      return -1;
   buf[0] = '[';
   buf[1] = ']';
   buf[2] = '\0';
   if (!project || !project[0])
      return -1;

   {
      char *project_q = kb_client_query_escape(project);
      if (!project_q)
         return -1;
      char path[512];
      snprintf(path, sizeof(path), "/v1/code/project-stats?project=%s", project_q);
      free(project_q);
      char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
      if (!json)
         return -1;
      cJSON *resp = cJSON_Parse(json);
      free(json);
      if (!resp)
         return -1;

      cJSON *status = cJSON_GetObjectItemCaseSensitive(resp, "status");
      int rc = -1;
      if (cJSON_IsString(status) && strcmp(status->valuestring, "ok") == 0)
      {
         cJSON *langs = cJSON_GetObjectItemCaseSensitive(resp, "langs");
         if (cJSON_IsArray(langs))
         {
            char *printed = cJSON_PrintUnformatted(langs);
            if (printed)
            {
               snprintf(buf, bufsz, "%s", printed);
               free(printed);
            }
         }
         rc = 0;
      }
      cJSON_Delete(resp);
      return rc;
   }
}

int kb_client_index_code_search(const char *query, const char *project, code_search_hit_t *out,
                                int max)
{
   if (!query || !query[0] || !out || max <= 0)
      return 0;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *query_q = kb_client_query_escape(query);
   char *project_q = (project && project[0]) ? kb_client_query_escape(project) : NULL;
   if (!query_q || ((project && project[0]) && !project_q))
   {
      free(query_q);
      free(project_q);
      return 0;
   }
   size_t path_len = strlen("/v1/code/search?query=&max_results=&project=") + strlen(query_q) +
                     (project_q ? strlen(project_q) : 0) + 32;
   char *path = malloc(path_len);
   if (!path)
   {
      free(query_q);
      free(project_q);
      return 0;
   }
   snprintf(path, path_len, "/v1/code/search?query=%s&max_results=%d%s%s", query_q, max,
            project_q ? "&project=" : "", project_q ? project_q : "");
   free(query_q);
   free(project_q);

   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   free(path);
   if (!json)
      return 0;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_code_search_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_code_search_ref(const char *repository_key, const char *source_ref,
                                    const char *source_commit, const char *query,
                                    code_search_hit_t *out, int max)
{
   if (!repository_key || !repository_key[0] || !source_ref || !source_ref[0] ||
       !source_commit || !source_commit[0] || !query || !query[0] || !out || max <= 0)
      return -1;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *query_q = kb_client_query_escape(query);
   char *repo_q = kb_client_query_escape(repository_key);
   char *ref_q = kb_client_query_escape(source_ref);
   char *commit_q = kb_client_query_escape(source_commit);
   if (!query_q || !repo_q || !ref_q || !commit_q)
   {
      free(query_q);
      free(repo_q);
      free(ref_q);
      free(commit_q);
      return -1;
   }
   size_t path_len = strlen(query_q) + strlen(repo_q) + strlen(ref_q) + strlen(commit_q) + 160;
   char *path = malloc(path_len);
   if (!path)
   {
      free(query_q);
      free(repo_q);
      free(ref_q);
      free(commit_q);
      return -1;
   }
   snprintf(path, path_len,
            "/v1/code/search?query=%s&max_results=%d&repository_key=%s&source_ref=%s"
            "&source_commit=%s",
            query_q, max, repo_q, ref_q, commit_q);
   free(query_q);
   free(repo_q);
   free(ref_q);
   free(commit_q);

   int http_status = -1;
   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, &http_status);
   free(path);
   if (!json)
      return http_status == 409 ? -2 : -1;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_code_search_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

int kb_client_index_code_search_current(const char *repository_key, const char *root,
                                        const char *query, code_search_hit_t *out, int max)
{
#ifdef AIMEE_POSIX
   code_source_snapshot_t snapshot;
   if (!repository_key || !repository_key[0] || !root || !root[0] ||
       code_resolve_current_snapshot(root, &snapshot) != 0)
      return -1;
   int found = kb_client_index_code_search_ref(repository_key, snapshot.ref, snapshot.commit_sha,
                                               query, out, max);
   if (found != -2)
      return found;
   kb_client_index_scan_result_t scan;
   if (kb_client_index_scan_current(repository_key, root, 0, &scan) != 0)
      return -1;
   return kb_client_index_code_search_ref(repository_key, snapshot.ref, snapshot.commit_sha,
                                          query, out, max);
#else
   (void)repository_key;
   (void)root;
   (void)query;
   (void)out;
   (void)max;
   return -1;
#endif
}

int kb_client_index_find_callers(const char *project, const char *symbol, caller_hit_t *out,
                                 int max)
{
   if (!symbol || !symbol[0] || !out || max <= 0)
      return 0;
   memset(out, 0, sizeof(*out) * (size_t)max);

   char *symbol_q = kb_client_query_escape(symbol);
   char *project_q = (project && project[0]) ? kb_client_query_escape(project) : NULL;
   if (!symbol_q || ((project && project[0]) && !project_q))
   {
      free(symbol_q);
      free(project_q);
      return 0;
   }
   size_t path_len = strlen("/v1/code/callers?symbol=&max_results=&project=") + strlen(symbol_q) +
                     (project_q ? strlen(project_q) : 0) + 32;
   char *path = malloc(path_len);
   if (!path)
   {
      free(symbol_q);
      free(project_q);
      return 0;
   }
   snprintf(path, path_len, "/v1/code/callers?symbol=%s&max_results=%d%s%s", symbol_q, max,
            project_q ? "&project=" : "", project_q ? project_q : "");
   free(symbol_q);
   free(project_q);

   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   free(path);
   if (!json)
      return 0;
   cJSON *resp = cJSON_Parse(json);
   free(json);
   int count = kb_index_find_callers_parse(resp, out, max);
   cJSON_Delete(resp);
   return count;
}

/* S6: cross-repo dependency proxy. The kb response is rich (per-edge evidence +
 * version stamp, or a separate AMBIGUOUS review-queue shape when status=ambiguous)
 * so we forward the raw kb body verbatim rather than flatten it into a struct —
 * same passthrough idiom as kb_client_index_blast_radius_preview_json. Caller frees
 * the returned string; NULL means the kb was unreachable or returned no body. */
char *kb_client_index_cross_repo_deps_json(const char *project, const char *direction,
                                           const char *min_tier, int status_ambiguous, int dry_run)
{
   if (!project || !project[0])
      return NULL;

   char *project_q = kb_client_query_escape(project);
   char *direction_q = (direction && direction[0]) ? kb_client_query_escape(direction) : NULL;
   char *min_tier_q = (min_tier && min_tier[0]) ? kb_client_query_escape(min_tier) : NULL;
   if (!project_q || ((direction && direction[0]) && !direction_q) ||
       ((min_tier && min_tier[0]) && !min_tier_q))
   {
      free(project_q);
      free(direction_q);
      free(min_tier_q);
      return NULL;
   }

   size_t path_len =
       strlen("/v1/code/cross-repo-deps?project=&direction=&min_tier=&status=ambiguous&dry_run=1") +
       strlen(project_q) + (direction_q ? strlen(direction_q) : 0) +
       (min_tier_q ? strlen(min_tier_q) : 0) + 8;
   char *path = malloc(path_len);
   if (!path)
   {
      free(project_q);
      free(direction_q);
      free(min_tier_q);
      return NULL;
   }
   snprintf(path, path_len, "/v1/code/cross-repo-deps?project=%s%s%s%s%s%s%s", project_q,
            direction_q ? "&direction=" : "", direction_q ? direction_q : "",
            min_tier_q ? "&min_tier=" : "", min_tier_q ? min_tier_q : "",
            status_ambiguous ? "&status=ambiguous" : "", dry_run ? "&dry_run=1" : "");
   free(project_q);
   free(direction_q);
   free(min_tier_q);

   char *json = kb_client_v1_get_json(path, KB_CLIENT_INDEX_READ_TIMEOUT_MS, NULL);
   free(path);
   return json;
}

/* S7: POST the cross-repo trust write to the kb. Returns the raw kb JSON body on
 * 2xx (caller frees); NULL on any non-2xx or transport failure with *http_status
 * (optional) set to the kb HTTP status (so the proxy can map 404/403/400 to a
 * precise client error instead of a blanket 502). */
char *kb_client_repo_trust_json(const char *project, const char *trust, const char *actor,
                                const char *request_id, int *http_status)
{
   if (http_status)
      *http_status = -1;
   if (!project || !project[0] || !trust || !trust[0])
      return NULL;
   cJSON *body = cJSON_CreateObject();
   if (!body)
      return NULL;
   cJSON_AddStringToObject(body, "project", project);
   cJSON_AddStringToObject(body, "trust", trust);
   if (actor && actor[0])
      cJSON_AddStringToObject(body, "actor", actor);
   if (request_id && request_id[0])
      cJSON_AddStringToObject(body, "request_id", request_id);
   char *json = kb_client_v1_post_json("/v1/code/repo-trust", body, KB_CLIENT_INDEX_READ_TIMEOUT_MS,
                                       http_status);
   cJSON_Delete(body);
   return json;
}
