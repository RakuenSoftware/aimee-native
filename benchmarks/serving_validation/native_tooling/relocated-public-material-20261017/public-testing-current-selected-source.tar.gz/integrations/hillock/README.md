# Hillock retrieval proof of concept

Hillock is a selectable memory backend alongside native and Cognee. Selecting Cognee or Hillock starts an independent durable compatibility catalog under `$AIMEE_HOME/memory-backends/<engine>/<placement>` (override the root with `AIMEE_MEMORY_BACKEND_DIR`). The external memory owner does not construct a native PostgreSQL record store. Canonical content, scope, authorship, revisions, history and retry receipts persist in this catalog; the selected engine supplies retrieval. This is adapter-owned storage, not Hillock upstream's SQLite graph.

The sidecar uses the actual upstream `HyperdimensionalReservoir` subword encoder and HYDRA scorer at revision `1edd166ead75b85a9ab95cd6ba4faf7011ad567c`. It does not use upstream chat, TALON, graph or Hebbian learning. Each query supplies an eligible snapshot and receives IDs, revision hashes and scores, followed by canonical revalidation. The sidecar retains no records, vectors or conversation state.

The compatibility catalog uses locked atomic writes and retained erasure metadata. Corrections preserve prior versions; deletes retire records; subject erasure removes content/history/retry payloads and prevents restoration when its retained `erasures.json` is preserved. Back up the complete catalog directory and preserve current erasure control metadata when restoring older record files. Startup replays these controls and verifies provider cleanup before readiness.

The [external conversation contract](../memory/CONTRACT.md) is implemented through Aimee's adapter: public CRUD/list/history, recall/composition/briefing, authenticated export, source revalidation/send barriers, and fresh admission after erasure. Portable catalog snapshots preserve IDs, revisions, history, authorship and erasure controls; the maintenance tool bridges native record snapshots. Optional native graph/learning/views remain outside this profile. [Current validation](../../docs/validation/external-memory-support-2026-10-08.md) and [pending quality/scale work](../../docs/proposals/pending/external-memory-engine-scale-and-quality.md) state the practical limits.

## Run

From this directory, supply a mode-0600 token file owned by container UID 10001 (a narrowly readable container secret mount can also be used), then:

```sh
HILLOCK_TOKEN_FILE=/absolute/path/to/token docker compose up -d --build
```

The compose example exposes only loopback port 8097, runs as UID 10001 with a read-only filesystem, and sets resource limits and an authenticated health check. For another container, attach it to the owner's private service network and use its service address; do not use the owner's loopback address to reach a different container.

Configure the existing Aimee memory owner:

```sh
AIMEE_MEMORY_BACKEND=hillock
AIMEE_MEMORY_BACKEND_URL=http://127.0.0.1:8097
AIMEE_MEMORY_BACKEND_AUTH=bearer
```

Put the matching bearer token in the existing Vault key `AIMEE_MEMORY_BACKEND_TOKEN`; do not put it in these configuration values. `AIMEE_HILLOCK_URL` is a fallback for the URL. `AIMEE_MEMORY_BACKEND_AUTH=none` and sidecar `HILLOCK_AUTH=none` are explicit alternatives for an isolated test network. Startup verifies the exact profile/revision and stateless contract before readiness. Unknown backends, unsupported profiles, outages and capacity failures do not silently select native retrieval. Native remains the default when the backend setting is empty.

## Implemented API and limits

- `GET /v1/health`: protocol version, upstream revision, `hdc-subword` profile and `stateless=true`.
- `POST /v1/rank`: JSON `{query, candidates:[{id, revision, text}], limit}` → `{hits:[{id, revision, score}]}`. Higher scores rank first, equal scores use ascending record ID. The fixed 0.20 match threshold is a POC retrieval setting, not confidence that a claim is true.
- Maximum 256 candidate records per rank request, 1 MiB request/response, 16 KiB query, 64 query tokens, 256 tokens per record and 4096 distinct snapshot/query tokens, with at most 128 UTF-8 bytes per token. Exceeding a bound returns a capacity error (HTTP 413); Aimee scans the eligible catalog and selects a bounded lexical candidate pool; capabilities advertise non-exhaustive retrieval. This is not a 256-record catalog limit.
- CPU work is limited to 10 seconds per request; a compute deadline returns HTTP 504. The service processes one ranking request at a time with a bounded socket backlog.
- Errors: 400 malformed input, 401 missing/wrong bearer, 404 unsupported route, 413 capacity. Aimee treats other failures as unavailable. Empty canonical searches list directly from the selected catalog without invoking Hillock.

Subword similarity is lexical/morphological retrieval, not a claim of semantic equivalence, independent corroboration or graph reasoning. Aimee must still apply its evidence/authority and answer composition rules.

## Verify against real upstream code

```sh
python3 -m venv /tmp/hillock-poc-venv
/tmp/hillock-poc-venv/bin/pip install -r integrations/hillock/requirements.txt
/tmp/hillock-poc-venv/bin/python scripts/validation/memory/run-hillock-contract.py \
  --artifacts /tmp/hillock-poc-evidence-new-run
```

Run those verification commands from the repository root. The runner checks out the pinned upstream, rejects modified tracked source, starts an authenticated service on an ephemeral loopback port, requires the live Go test to execute, verifies corrections/deletion/capacity and no cross-request retained retrieval, then repeats after a process restart. It retains fixture-only logs and a summary. Unit/race tests also reject malformed identities, changed revisions, outages and cancellation. CI runs the real contract with pinned NumPy. These checks establish POC behavior, not production-scale quality or measured conversational improvement. The Docker deployment recipe is supplied; the local evidence does not claim a Docker build or live Discord rollout.

[Current .253 support validation](../../docs/validation/external-memory-support-2026-10-08.md) records the completed integration checks and remaining quality limits.

## First-start backend selection

Aimee-server's setup wizard includes **Memory backend**, with Aimee native memory,
Cognee and Hillock choices. Native remains the default for existing installations.
For an external backend, start its service, enter the HTTP(S) origin reachable
from the server and select authentication. Cognee also supports API-key auth.
The wizard seals the credential through the existing Vault key
`AIMEE_MEMORY_BACKEND_TOKEN` before saving the selection; public config reads expose
only credential presence. Backend changes require the appliance administrator.

The choice is saved atomically as non-secret `memory.backend` configuration:

```yaml
memory:
  backend:
    engine: hillock
    endpoint: http://hillock:8097
    auth: bearer
```

Restart the appliance after saving. Memory and egress read the same config-owner
snapshot at process startup; host reset/erasure routing retains its startup choice
until restart. Existing deployment environment settings take precedence; an explicit
`AIMEE_MEMORY_BACKEND` selects the environment configuration instead of the saved
object. No service is installed and no existing memories are migrated by this step.
The shared KB is configured independently. Unavailable, unknown or incompatible
external services fail readiness without switching to native memory.

[Expanded owner/setup qualification evidence](../../docs/validation/hillock-scenarios-memory-setup-2026-10-11.md) records the scenario and first-start checks.

## Release-candidate CI

[Hillock prerelease qualification](../../.github/workflows/hillock-prereleases.yml) scans upstream branches matching `rc/v<major>.<minor>.<patch>` hourly (at minute 17). It discovers every matching branch, including new branches and updated tips; `rc/v0.10.0` is one example. Scheduled scans begin when the workflow is on Aimee's default branch. GitHub schedules can be delayed. Manual dispatch can select one branch or force a repeat of a previously successful qualification. Aimee pushes, pull requests and releases do not trigger this workflow. Normal Aimee CI runs the discovery/runner regression tests and the pinned production contract.

Each branch tip is snapshotted to an immutable commit SHA and fetched by that SHA. Qualification runs memory owner/adapter race tests, the real upstream HDC lifecycle and Aimee owner/recall scenarios twice across a service restart, authenticated protocol/capacity checks, and cold/concurrent warm retrieval at 100, 1,000 and 10,000 records with a 30-second operation deadline. Candidate jobs run independently; a failure retains evidence and fails that job. Discovery/network failures fail the scan instead of reporting no candidates.

The required live scenarios use the fetched engine with Aimee's production external
catalog, memory handler and public command boundary. They verify attributed writes,
idempotent retries, catalog reopen, correction/history/version conflicts, public
search and scoped fact lookup returning current content, authority refusal, export
and import, retirement, subject erasure and suppression of restored erased records.
Recall scenarios verify project isolation, personal preference precedence, briefing
composition and refusal to release a stale source collection. Adapter scenarios
also cover Unicode content, scope/kind/tier filters, concurrent queries, empty
scopes, cancellation, refused authentication and no cross-request retention.
Governed transport scenarios execute real health/ranking requests through the shipping
egress policy and HTTP executor with a fixture credential resolver, checking caller
isolation, route admission and credential rotation/revocation.
The runner requires all four named live tests to pass; absent or skipped scenarios
fail qualification. The receipt schema is `v3`, so older successful receipts do
not skip these stronger checks.

A successful receipt is cached for the exact upstream branch and Hillock commit. A changed upstream tip or new branch must qualify; an Aimee commit alone does not invalidate the receipt. Candidates without successful receipts retry on the next scan. Use manual forced qualification to explicitly retest an unchanged upstream revision against newer Aimee code. The receipt records the Aimee revision actually tested. Cache eviction safely causes requalification. The cache holds only the success summary; fixture logs and scale results are retained as workflow artifacts for 30 days. Run/workflow summaries identify the branch and both revisions. Upstream code runs in disposable jobs without repository write permission or deployment secrets.

The runner makes temporary copies of the sidecar and a Go build overlay changing only their expected revision constants. All actual ranking code comes from the discovered upstream commit. Production source, Docker revision and startup pin remain unchanged: passing CI supplies compatibility evidence, and promotion still requires a reviewed pin update. This gate covers the HDC/subword profile, not upstream chat, graph, learning or Aimee's remaining model/gateway qualification work.

To reproduce a candidate locally (use an empty artifact directory):

```sh
/tmp/hillock-poc-venv/bin/python scripts/validation/memory/run-hillock-contract.py \
  --branch rc/v0.10.0 --revision <full-40-character-commit-sha> --scale \
  --artifacts /tmp/hillock-candidate-evidence-new-run
```
