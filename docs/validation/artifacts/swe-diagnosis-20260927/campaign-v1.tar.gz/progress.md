# SWE-bench native-learning progress

Repeated-task, native-memory experience study. Partial results and infrastructure failures remain explicit. Not unseen-task generalization or changed model weights.

Completed attempt records: 180/900.

| Arm | Finished | Resolved | Scored incl. empty | Infrastructure | With native memory |
|---|---:|---:|---:|---:|---:|
| control | 32 | 2 | 30 | 2 | 0 |
| learn-1 | 32 | 3 | 32 | 0 | 0 |
| learn-2 | 32 | 2 | 32 | 0 | 32 |
| learn-3 | 28 | 0 | 28 | 0 | 28 |
| learn-4 | 28 | 0 | 28 | 0 | 28 |
| learn-5 | 28 | 1 | 28 | 0 | 28 |

Paired transitions are in summary.json. Do not divide by 150 until the scheduled arm is complete, or hide incomplete tasks behind a partial percentage.
