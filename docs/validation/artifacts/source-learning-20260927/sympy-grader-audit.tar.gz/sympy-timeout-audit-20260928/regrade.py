import pathlib,json,time,os,sys,docker
from swebench.harness.run_evaluation import make_test_spec,run_instance
case=sys.argv[1];assert case in ('base','submitted')
root=pathlib.Path('/opt/swe-native/sympy-timeout-audit-20260928');work=root/('grader900-'+case);work.mkdir(exist_ok=False);os.chdir(work)
iid='sympy__sympy-11870'
patch=json.loads((root/'base-official-grader.json').read_text())['patch'] if case=='base' else json.loads(pathlib.Path('/opt/swe-native/source-learning-20260927/results/source-control/sympy__sympy-11870/result.json').read_text())['model_patch']
full=next(t for t in json.loads(pathlib.Path('/opt/swe-native/selected-grader-only.json').read_text()) if t['instance_id']==iid)
pred={'instance_id':iid,'model_name_or_path':'grader-budget-'+case,'model_patch':patch};start=time.monotonic()
result=run_instance(make_test_spec(full,namespace='swebench'),pred,False,False,docker.from_env(),'native-grader900-'+case+'-20260928',timeout=900)
report={'scope':'Grader-only diagnostic; submitted patch unchanged; base uses only a blank .gitignore line','case':case,'timeout_seconds':900,'seconds':time.monotonic()-start,'result':result,'patch':patch}
(work/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='patch'}),flush=True)
