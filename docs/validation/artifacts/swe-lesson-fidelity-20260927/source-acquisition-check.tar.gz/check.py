import os,sys,pathlib,json,subprocess
os.environ['SWE_RUN_ROOT']='/opt/swe-native/source-acquisition-check-20260927'
sys.path.insert(0,'/opt/swe-native/source-learning-20260927')
import source_learning as study
base=pathlib.Path('/opt/swe-native');tasks=json.loads((base/'tasks.json').read_text());report=[]
for iid in ['pallets__flask-5014','matplotlib__matplotlib-25340']:
 task=next(t for t in tasks if t['instance_id']==iid);source=base/'calibration-20260927';row=json.loads((source/'results/learn-1'/iid/'result.json').read_text())
 if subprocess.run(['docker','image','inspect',study.run.image(task)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:subprocess.run(['docker','pull',study.run.image(task)],check=True,timeout=600)
 experience=study.capture(task,row,None,source)
 report.append({'instance_id':iid,'kind':experience['kind'],'command':experience['command'],'patch_sha256':experience['patch_sha256'],'replay_trials':len(experience['replay_trials']),'matched':experience['replay_trials'][-1]['matches_successful_patch']})
 (study.ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
