package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/JBailes/aimee/server-go/modules/memory/sparse"
)

func TestBuildPublishImportAndPersistentReader(t *testing.T) {
	root := t.TempDir()
	input := filepath.Join(t.TempDir(), "source.json")
	c := sparse.ChangeSet{Namespace: "general", Kind: "general", Generation: 1, Source: "test", Coverage: []string{"facts"}, Records: []sparse.Record{{Ref: sparse.Ref{Namespace: "general", ID: "1", Revision: "v1"}, Scope: sparse.Scope{Type: "global", Value: "_global"}, Key: "beacon", Content: "beacon teal", Confidence: 1, Lifecycle: "active"}}}
	b, _ := json.Marshal(c)
	if err := os.WriteFile(input, b, 0600); err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	if err := run([]string{"build", "--root", root, "--input", input}, nil, &out); err != nil {
		t.Fatal(err)
	}
	var result map[string]string
	if err := json.Unmarshal(out.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	id := result["view"]
	if err := run([]string{"publish", "--root", root, "--view", id}, nil, &out); err != nil {
		t.Fatal(err)
	}
	out.Reset()
	if err := run([]string{"serve", "--unsafe-research", "--root", root}, strings.NewReader("{\"op\":\"pin\"}\n{\"op\":\"search\",\"query\":\"beacon\",\"limit\":4}\n"), &out); err != nil {
		t.Fatal(err)
	}
	lines := strings.Split(strings.TrimSpace(out.String()), "\n")
	if len(lines) != 2 || !strings.Contains(lines[1], "beacon teal") {
		t.Fatalf("serve: %s", out.String())
	}
	out.Reset()
	if err := run([]string{"export", "--internal-backup", "--root", root}, nil, &out); err != nil {
		t.Fatal(err)
	}
	archive := filepath.Join(t.TempDir(), "image.tar")
	if err := os.WriteFile(archive, out.Bytes(), 0600); err != nil {
		t.Fatal(err)
	}
	other := t.TempDir()
	out.Reset()
	if err := run([]string{"import", "--internal-backup", "--root", other, "--input", archive}, nil, &out); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out.String(), id) {
		t.Fatal("import changed identity")
	}
	if _, err := os.Stat(filepath.Join(other, "CURRENT")); !os.IsNotExist(err) {
		t.Fatal("import implicitly published")
	}
	out.Reset()
	if err := run([]string{"query", "--root", other, "--view", id, "--query", "beacon"}, nil, &out); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out.String(), "beacon teal") {
		t.Fatal("imported query failed")
	}
}

func TestUnboundModelServingAndRawTransferFailClosed(t *testing.T) {
	for _, command := range []string{"import", "export-postgres"} {
		var out bytes.Buffer
		if err := run([]string{command, "--root", t.TempDir()}, nil, &out); err == nil || out.Len() != 0 {
			t.Fatalf("unapproved %s accepted", command)
		}
	}
	root := t.TempDir()
	store := sparse.Store{Root: root}
	view, err := store.Build(sparse.ChangeSet{Namespace: "general", Kind: "general", Generation: 1, Source: "test", Coverage: []string{"facts"}})
	if err != nil {
		t.Fatal(err)
	}
	if err = store.Publish(view, ""); err != nil {
		t.Fatal(err)
	}
	for _, command := range []string{"serve", "export"} {
		var out bytes.Buffer
		if err = run([]string{command, "--root", root}, strings.NewReader("{\"op\":\"pin\"}\n"), &out); err == nil || out.Len() != 0 {
			t.Fatalf("unapproved %s accepted", command)
		}
	}
}
