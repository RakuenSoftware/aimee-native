package sparse

import (
	"encoding/json"
	"fmt"
	"time"
)

// ServingConfig contains compiled routing context, not local access rules.
// Authorization must be resolved BEFORE any bytes enter the recipient's store.
// RecallScopes preserve the keys of existing publisher-produced read contracts.
type ServingConfig struct {
	ReferenceCues    []ReferenceCue          `json:"reference_cues,omitempty"`
	Version          int                     `json:"version"`
	RecallScopes     []string                `json:"recall_scopes,omitempty"`
	ReferenceLookups []ReferenceLookupPolicy `json:"reference_lookups,omitempty"`
}

// PublishedReader consumes a physically filtered snapshot. It holds no signing
// key, grant file, identity verifier or RPC connection. It cannot protect bytes
// that have already been delivered. Publication/withdrawal belongs to Aimee.
type PublishedReader struct {
	View        *View
	Publication string
	lookup      *ReferenceLookup
	context     Authorization
	byID        map[string][]AuthorizedRecord
}

func (s Store) OpenPublished(id string) (_ *PublishedReader, err error) {
	v, err := s.Open(id)
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			v.Close()
		}
	}()
	tip := v.Layers[len(v.Layers)-1]
	if tip.Serving == nil || tip.Serving.Version != 1 || tip.Authorization == "" {
		return nil, fmt.Errorf("expected a compiled recipient snapshot")
	}
	// Integrity validation, not authorization. Never accept a raw source graph
	// accidentally as a delivery snapshot. Only the publisher can ensure that
	// the directory was populated with appropriate data in the first place.
	for _, m := range v.Layers {
		if m.Previous != "" || m.Source != "authorized knowledge snapshot" || m.Authorization != tip.Authorization {
			return nil, fmt.Errorf("expected a compiled recipient snapshot")
		}
	}
	if err = v.Verify(); err != nil {
		return nil, err
	}
	p := &PublishedReader{View: v, Publication: tip.Authorization, byID: map[string][]AuthorizedRecord{}}
	p.context.Grants = tip.Serving.RecallScopes
	p.context.ReferenceLookups = tip.Serving.ReferenceLookups
	p.context.ReferenceCues = tip.Serving.ReferenceCues
	for _, loc := range v.records {
		r, e := v.read(loc)
		if e != nil {
			return nil, e
		}
		entry := AuthorizeRecord(r) // canonical fingerprint, computed once
		p.context.Records = append(p.context.Records, entry)
		p.byID[r.ID] = append(p.byID[r.ID], entry)
	}
	p.lookup, err = NewReferenceLookup(v, p.context)
	if err != nil {
		return nil, err
	}
	return p, nil
}

func (p *PublishedReader) Close() { p.View.Close() }

// Recall preserves compiled retrieval and temporal semantics. All stored rows
// have already been admitted by the publisher. It never reauthorizes a read.
func (p *PublishedReader) Recall(query string, limit int, authority string, now time.Time) (RecallResult, error) {
	r := p.View.Recall(query, limit, authority, grantMap(p.context), now)
	if r.Outcome == "uncovered" {
		r = p.lookup.Recall(query, limit, authority, now)
	}
	if r.Outcome != "hit" {
		return r, nil
	}
	var body struct {
		Facts []map[string]json.RawMessage `json:"facts"`
	}
	if err := json.Unmarshal(r.Response, &body); err != nil {
		return r, err
	}
	// Resolve only returned IDs, avoiding a corpus scan and preserving collision
	// detection across namespaces. This binds payloads to canonical identities.
	context := p.context
	context.Records = nil
	seen := map[Ref]bool{}
	for _, f := range body.Facts {
		var id string
		if json.Unmarshal(f["id"], &id) != nil {
			id = string(f["id"])
		}
		for _, entry := range p.byID[id] {
			if !seen[entry.Ref] {
				context.Records = append(context.Records, entry)
				seen[entry.Ref] = true
			}
		}
	}
	refs, err := p.View.ResolveResponse(r.Response, context, now)
	if err != nil {
		return r, err
	}
	var response map[string]any
	if err := json.Unmarshal(r.Response, &response); err != nil {
		return r, err
	}
	for i, f := range response["facts"].([]any) {
		f.(map[string]any)["memory_ref"] = refs[i]
		canonical, e := p.View.Get(refs[i], grantMap(p.context), now)
		if e != nil {
			return r, e
		}
		f.(map[string]any)["memory_hash"] = AuthorizeRecord(canonical).SHA256
	}
	r.Response, err = json.Marshal(response)
	return r, err
}

// RetentionProof binds a disposable encoding to an exact current canonical object.
// The local directory has already been authorized; this is cache coherency only.
type RetentionProof struct {
	Ref  Ref    `json:"memory_ref"`
	Hash string `json:"memory_hash"`
}

func (p *PublishedReader) Retain(proofs []RetentionProof, now time.Time) []bool {
	result := make([]bool, len(proofs))
	for i, proof := range proofs {
		if !digestPattern.MatchString(proof.Hash) {
			continue
		}
		r, e := p.View.Get(proof.Ref, grantMap(p.context), now)
		result[i] = e == nil && r.Ref == proof.Ref && AuthorizeRecord(r).SHA256 == proof.Hash
	}
	return result
}

// RestrictRemote narrows an already authenticated Aimee read to the records
// released into this snapshot. It grants no upstream access by itself.
func (p *PublishedReader) remoteContext(namespace string) Authorization {
	a := Authorization{Grants: p.context.Grants}
	for _, r := range p.context.Records {
		if r.Namespace == namespace {
			a.Records = append(a.Records, r)
		}
	}
	return a
}
func (p *PublishedReader) RestrictRemote(namespace string) (SearchRestriction, error) {
	return RestrictSearch(p.remoteContext(namespace), namespace)
}
func (p *PublishedReader) ResolveRemote(raw json.RawMessage, now time.Time) ([]Ref, error) {
	var body struct {
		Restriction *SearchRestriction `json:"restriction"`
	}
	if json.Unmarshal(raw, &body) != nil || body.Restriction.Validate() != nil {
		return nil, fmt.Errorf("restricted upstream receipt required")
	}
	return p.View.ResolveResponse(raw, p.remoteContext(body.Restriction.Namespace), now)
}
