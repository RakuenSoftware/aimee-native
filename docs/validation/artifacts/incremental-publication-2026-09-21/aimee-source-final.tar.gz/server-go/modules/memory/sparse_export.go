package memory

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	store "github.com/JBailes/aimee/server-go/modules/aimee"
	"github.com/JBailes/aimee/server-go/modules/memory/sparse"
)

// ExportSparseRecords is a control-plane source export, not an authorization
// decision. Scope normalization selects storage; it does not prove caller access.
// Never distribute this raw output to a model. CompileAuthorized must apply an
// independently issued, exact-object release before distribution. The caller
// supplies a read-only repeatable-read transaction. This initial exporter covers
// memory rows, not the entire KB ontology/episode/vector corpus; coverage must
// be declared in the image manifest. Original row fields remain in Metadata.
func ExportSparseRecords(ctx context.Context, db store.Queryer, placement Placement, scope Scope, namespace string) ([]sparse.Record, error) {
	return exportSparseRecords(ctx, db, placement, scope, namespace, nil)
}

// ExportSparseRecordsSelected reads only IDs admitted by the publication policy.
// A nil/empty selection never means an unrestricted export.
func ExportSparseRecordsSelected(ctx context.Context, db store.Queryer, placement Placement, scope Scope, namespace string, ids []string) ([]sparse.Record, error) {
	if len(ids) == 0 {
		return []sparse.Record{}, nil
	}
	for _, id := range ids {
		n, e := strconv.ParseInt(id, 10, 64)
		if e != nil || n <= 0 {
			return nil, fmt.Errorf("invalid selected record ID")
		}
	}
	return exportSparseRecords(ctx, db, placement, scope, namespace, ids)
}
func exportSparseRecords(ctx context.Context, db store.Queryer, placement Placement, scope Scope, namespace string, ids []string) ([]sparse.Record, error) {
	scope, err := normalizeScope(placement, scope)
	if err != nil {
		return nil, err
	}
	query := `SELECT to_jsonb(m) FROM memories m WHERE scope_type=$1 AND scope_value=$2 ORDER BY id`
	args := []any{scope.Type, scope.Value}
	if placement == PlacementServer {
		query = `SELECT to_jsonb(m) FROM user_memories m ORDER BY id`
		args = nil
	}
	if ids != nil {
		encoded, _ := json.Marshal(ids)
		query = strings.TrimSuffix(query, " ORDER BY id")
		if placement == PlacementServer {
			query += " WHERE"
		} else {
			query += " AND"
		}
		query += fmt.Sprintf(" id IN (SELECT jsonb_array_elements_text($%d::jsonb)::bigint) ORDER BY id", len(args)+1)
		args = append(args, string(encoded))
	}
	rows, err := db.Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []sparse.Record{}
	for rows.Next() {
		var raw []byte
		if err = rows.Scan(&raw); err != nil {
			return nil, err
		}
		r, err := SparseRecordFromRow(raw, scope, namespace)
		if err != nil {
			return nil, err
		}
		result = append(result, r)
	}
	return result, rows.Err()
}

// SparseRecordFromRow preserves source metadata and hashes the canonical row as
// its revision. It accepts the normalized scope from the owning memory module.
func SparseRecordFromRow(raw []byte, scope Scope, namespace string) (sparse.Record, error) {
	var row map[string]json.RawMessage
	if err := json.Unmarshal(raw, &row); err != nil {
		return sparse.Record{}, err
	}
	canonical, err := json.Marshal(row)
	if err != nil {
		return sparse.Record{}, err
	}
	sum := sha256.Sum256(canonical)
	str := func(key string) string { var value string; _ = json.Unmarshal(row[key], &value); return value }
	var id int64
	if err = json.Unmarshal(row["id"], &id); err != nil || id <= 0 {
		return sparse.Record{}, fmt.Errorf("memory export requires positive source id")
	}
	var confidence float64
	if err = json.Unmarshal(row["confidence"], &confidence); err != nil {
		return sparse.Record{}, fmt.Errorf("memory export requires confidence")
	}
	r := sparse.Record{Ref: sparse.Ref{Namespace: namespace, ID: strconv.FormatInt(id, 10), Revision: hex.EncodeToString(sum[:])}, Scope: sparse.Scope{Type: scope.Type, Value: scope.Value}, Key: str("key"), Content: str("content"), Kind: str("kind"), Tier: str("tier"), Confidence: confidence, Lifecycle: str("lifecycle_state"), Metadata: canonical}
	var suppressed int
	_ = json.Unmarshal(row["activation_suppressed"], &suppressed)
	r.Suppressed = suppressed != 0
	for field, dst := range map[string]*string{"valid_from": &r.ValidFrom, "valid_until": &r.ValidUntil} {
		if value := strings.TrimSpace(str(field)); value != "" {
			t, err := parseMemoryTime(value)
			if err != nil {
				return r, err
			}
			*dst = t.UTC().Format(time.RFC3339Nano)
		}
	}
	return r, nil
}
