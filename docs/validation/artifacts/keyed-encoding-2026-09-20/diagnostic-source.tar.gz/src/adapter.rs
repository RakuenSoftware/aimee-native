//! The proven connection: native attention request -> Aimee -> separately
//! encoded frozen-Qwen K/V -> requesting attention. No trained adapter values.
use crate::{
    model::{Bank, Cache, Model, scores},
    tokens::Tokens,
    transport::MemorySource,
};
use anyhow::{Context, Result, ensure};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::{HashMap, VecDeque};
use tch::{Device, Tensor};

pub struct State {
    pub diagnostic_steps: usize,
    pub position_shift: i64,
    pub before_prompt: bool,
    pub attention_trace: Vec<Value>,
    pub encoding_format: String,
    pub binding: String,
    pub sequence: Vec<u32>,
    pub memory_ids: Vec<u32>,
    pub facts: Vec<Value>,
    pub banks: HashMap<usize, Bank>,
    pub events: Vec<Value>,
    pub native_reads: usize,
    pub encodings: usize,
    pub step: usize,
    pub decode_recall: bool,
    pub reuse: bool,
}
struct Cached {
    key: String,
    banks: HashMap<usize, Bank>,
    bytes: usize,
}

#[cfg(test)]
mod publication_tests {
    use super::*;

    struct Source(VecDeque<Option<String>>);
    impl MemorySource for Source {
        fn begin(&mut self) -> Result<String> {
            self.0
                .pop_front()
                .flatten()
                .context("publication withdrawn")
        }
        fn search(&mut self, _: &str, _: usize) -> Result<Value> {
            anyhow::bail!("unexpected search")
        }
        fn native_search(&mut self, _: &str, _: usize) -> Result<Value> {
            anyhow::bail!("unexpected search")
        }
    }

    #[test]
    fn replacement_and_withdrawal_discard_cached_native_states() {
        let source = Source(VecDeque::from([
            Some("first".into()),
            Some("first".into()),
            Some("next".into()),
            None,
        ]));
        let mut adapter = Adapter::new(Box::new(source), 4, 1024, 4096);
        adapter.begin(false, true).unwrap();
        adapter.cache.push_back(Cached {
            key: "old-bank".into(),
            banks: HashMap::new(),
            bytes: 0,
        });
        adapter.begin(false, true).unwrap();
        assert_eq!(adapter.cache.len(), 1);
        adapter.begin(false, true).unwrap();
        assert!(adapter.cache.is_empty());
        adapter.cache.push_back(Cached {
            key: "new-bank".into(),
            banks: HashMap::new(),
            bytes: 0,
        });
        assert!(adapter.begin(false, true).is_err());
        assert!(adapter.cache.is_empty());
        assert!(adapter.generation.is_none());
    }
}
pub struct Adapter {
    pub source: Box<dyn MemorySource>,
    pub limit: usize,
    pub max_tokens: usize,
    pub cache_budget: usize,
    cache: VecDeque<Cached>,
    generation: Option<String>,
}
impl Adapter {
    pub fn new(
        source: Box<dyn MemorySource>,
        limit: usize,
        max_tokens: usize,
        cache_budget: usize,
    ) -> Self {
        Self {
            source,
            limit,
            max_tokens,
            cache_budget,
            cache: VecDeque::new(),
            generation: None,
        }
    }
    pub fn begin(&mut self, decode_recall: bool, reuse: bool) -> Result<State> {
        let binding = match self.source.begin() {
            Ok(binding) => binding,
            Err(error) => {
                self.cache.clear();
                self.generation = None;
                return Err(error);
            }
        };
        if self.generation.as_ref() != Some(&binding) {
            self.cache.clear();
            self.generation = Some(binding.clone());
        }
        Ok(State {
            diagnostic_steps: 0,
            position_shift: 0,
            before_prompt: false,
            attention_trace: vec![],
            encoding_format: "content".into(),
            binding,
            sequence: vec![],
            memory_ids: vec![],
            facts: vec![],
            banks: HashMap::new(),
            events: vec![],
            native_reads: 0,
            encodings: 0,
            step: 0,
            decode_recall,
            reuse,
        })
    }
    pub fn recall(
        &mut self,
        m: &Model,
        t: &Tokens,
        s: &mut State,
        query: &str,
        origin: &str,
        spans: Vec<Value>,
    ) -> Result<()> {
        let reply = match self.source.native_search(query, self.limit) {
            Ok(reply) => reply,
            Err(error) => {
                s.events.push(json!({"origin":origin,"query":query,"limit":self.limit,"step":s.step,"status":"read_failed","addressed_spans":spans}));
                return Err(error);
            }
        };
        ensure!(
            reply
                .get("windows")
                .and_then(Value::as_array)
                .is_none_or(Vec::is_empty),
            "episode codec unsupported"
        );
        ensure!(
            reply.get("active_context_missing") != Some(&Value::Bool(true)),
            "authority context incomplete"
        );
        let facts = reply["facts"].as_array().context("invalid fact response")?;
        let next = crate::knowledge::merge(&s.facts, facts)?;
        let mut event = json!({"origin":origin,"query":query,"limit":self.limit,"aimee_response":reply,"addressed_spans":spans,"step":s.step,"phase":if origin=="prompt_preload"{"preload"}else if s.step==0{"prefill"}else{"decode"}});
        if next.is_empty() {
            event["status"] = json!("empty");
            s.events.push(event);
            return Ok(());
        }
        let (ids, encoding) = crate::memory_encoding::encode(t, &next, &s.encoding_format)?;
        event["encoding_format"] = json!(s.encoding_format);
        if s.diagnostic_steps > 0 {
            event["encoding"] = encoding;
        }
        ensure!(
            ids.len() <= self.max_tokens,
            "memory exceeds capacity; refusing truncation"
        );
        event["memory_encoding_tokens"] = json!(ids.len());
        event["bank_memory_ids"] = json!(next.iter().map(|f| &f["memory_ref"]).collect::<Vec<_>>());
        if ids == s.memory_ids {
            event["status"] = json!("bank_unchanged");
            s.facts = next;
            s.events.push(event);
            return Ok(());
        }
        let key = format!(
            "{:x}",
            Sha256::digest(serde_json::to_vec(&json!([
                s.binding,
                ids,
                next.iter().map(|f| &f["memory_ref"]).collect::<Vec<_>>()
            ]))?)
        );
        let banks = if let Some(i) = self.cache.iter().position(|c| s.reuse && c.key == key) {
            let c = self.cache.remove(i).unwrap();
            let banks = copy_banks(&c.banks);
            self.cache.push_back(c);
            event["status"] = json!("bank_reused");
            banks
        } else {
            let banks = m.encode(&ids)?;
            s.encodings += 1;
            event["status"] = json!("bank_updated");
            let bytes = banks
                .values()
                .map(|b| (b.keys.numel() + b.values.numel()) * b.keys.kind().elt_size_in_bytes())
                .sum();
            if s.reuse && bytes <= self.cache_budget {
                while self.cache.iter().map(|c| c.bytes).sum::<usize>() + bytes > self.cache_budget
                {
                    self.cache.pop_front();
                }
                self.cache.push_back(Cached {
                    key,
                    banks: copy_banks(&banks),
                    bytes,
                });
            }
            banks
        };
        s.banks = banks;
        s.facts = next;
        s.memory_ids = ids;
        s.events.push(event);
        Ok(())
    }
    pub fn forward(
        &mut self,
        m: &Model,
        t: &Tokens,
        ids: &[u32],
        cache: &mut Cache,
        s: &mut State,
    ) -> Result<Tensor> {
        s.sequence.extend_from_slice(ids);
        let request_layer = m
            .config
            .layer_types
            .iter()
            .position(|x| x == "full_attention")
            .context("no full attention layer")?;
        let result = m.forward(
            ids,
            cache,
            Some(&mut |model, index, q, k, _v, mask| {
                if index == request_layer && (s.step == 0 || s.decode_recall) {
                    let groups =
                        model.config.num_attention_heads / model.config.num_key_value_heads;
                    let scale = (model.config.head_dim as f64).powf(-0.5);
                    let mut sources = vec![("sequence", s.sequence.as_slice())];
                    let score = if let Some(bank) = s.banks.get(&index) {
                        let offset = if s.before_prompt { -(s.memory_ids.len() as i64) } else { s.position_shift };
                        let mk = model.shift_memory_keys(&bank.keys.to_device(k.device()), offset);
                        let zeros = Tensor::zeros(
                            [1, 1, mask.size()[2], mk.size()[2]],
                            (mask.kind(), mask.device()),
                        );
                        sources.insert(0, ("aimee", s.memory_ids.as_slice()));
                        scores(
                            q,
                            &Tensor::cat(&[mk, k.shallow_clone()], -2),
                            &Tensor::cat(&[zeros, mask.shallow_clone()], -1),
                            groups,
                            scale,
                        )?
                    } else {
                        scores(q, k, mask, groups, scale)?
                    };
                    let (query, spans) = t.addressed(&sources, &score, 12)?;
                    if !query.is_empty() {
                        self.recall(model, t, s, &query, "qwen_attention_query", spans)?;
                    }
                }
                let offset = if s.before_prompt { -(s.memory_ids.len() as i64) } else { s.position_shift };
                let bank = s.banks.get(&index).map(|b| Bank {
                    keys: model.shift_memory_keys(&b.keys.to_device(k.device()), offset),
                    values: b.values.shallow_clone(),
                });
                if s.step < s.diagnostic_steps {
                    if let Some(b) = &bank {
                        let groups = model.config.num_attention_heads / model.config.num_key_value_heads;
                        let weights = crate::model::native_attention_weights(q,k,&b.keys,mask,groups,(model.config.head_dim as f64).powf(-0.5))?;
                        s.attention_trace.push(json!({"step":s.step,"layer":index,"position_shift":offset,"memory_tokens":s.memory_ids.len(),"weights":weights}));
                    }
                }
                if bank.is_some() {
                    s.native_reads += 1;
                }
                Ok(bank)
            }),
        );
        if result.is_err() {
            s.banks.clear();
            s.memory_ids.clear();
            s.facts.clear();
        }
        s.step += 1;
        result
    }
}
fn copy_banks(b: &HashMap<usize, Bank>) -> HashMap<usize, Bank> {
    b.iter().map(|(i, b)| (*i, b.copy())).collect()
}
pub fn tensor_values(t: &Tensor) -> Result<Vec<f32>> {
    Ok(Vec::<f32>::try_from(
        t.to_kind(tch::Kind::Float)
            .to_device(Device::Cpu)
            .reshape([-1]),
    )?)
}
