import pathlib,subprocess,os,json,shutil,hashlib
r=pathlib.Path(__file__).parent
identity=json.loads(pathlib.Path('/opt/aimee-native-release/identity.json').read_text())
env=dict(os.environ,AIMEE_RELEASE_PUBLIC_KEY=identity['release_public_key'],AIMEE_RELEASE_URL=identity['origin'],AIMEE_RELEASE_CA_PEM=pathlib.Path('/opt/aimee-native-release/ca.pem').read_text(),AIMEE_LAB_CA_FILE='/opt/aimee-native-release/ca.pem',CARGO_TARGET_DIR='/opt/aimee-memory-lab/vllm-native-build/distribution/launcher/target')
cargo='/root/.cargo/bin/cargo';manifest=str(r/'distribution/launcher/Cargo.toml')
subprocess.run([cargo,'test','--locked','--manifest-path',manifest,'--lib'],env=env,check=True)
for name,features in [('aimee-native',[]),('aimee-native-candidate-test',['--features','lab-release'])]:
 subprocess.run([cargo,'build','--locked','--release','--manifest-path',manifest]+features,env=env,check=True)
 shutil.copy2(pathlib.Path(env['CARGO_TARGET_DIR'])/'release/aimee-native',r/name)
(r/'launcher-build-result.json').write_text(json.dumps({'status':'built','sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ['aimee-native','aimee-native-candidate-test']}},indent=2))