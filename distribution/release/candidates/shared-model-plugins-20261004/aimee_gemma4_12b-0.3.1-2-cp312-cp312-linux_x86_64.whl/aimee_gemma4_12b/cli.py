"""Bind this plugin, then delegate to the shared serving CLI."""
import os
from pathlib import Path


def main():
    os.environ['AIMEE_NATIVE_PLUGIN_CONTRACT'] = str(Path(__file__).parent / 'native/adapter.json')
    from aimee_native_runtime.cli import main as shared_main
    shared_main()
