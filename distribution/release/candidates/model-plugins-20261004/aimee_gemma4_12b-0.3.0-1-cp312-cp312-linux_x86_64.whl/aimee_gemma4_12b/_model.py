BOUND_ADAPTER = 'gemma4-12b'
PLUGIN_NAME = 'aimee_gemma4_12b'
