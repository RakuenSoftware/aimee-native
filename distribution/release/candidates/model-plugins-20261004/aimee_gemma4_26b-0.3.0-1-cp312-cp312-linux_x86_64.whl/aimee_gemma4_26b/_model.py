BOUND_ADAPTER = 'gemma4-26b'
PLUGIN_NAME = 'aimee_gemma4_26b'
