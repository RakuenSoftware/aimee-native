BOUND_ADAPTER = 'qwen3-8-27b'
PLUGIN_NAME = 'aimee_qwen3_8_27b'
